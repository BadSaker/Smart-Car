# IPS200屏幕与逐飞助手图传

更新：2026-10-03。用户要求屏幕和Wi-Fi回退到实测稳定的14:33版本，舵机不变，并明确后续不再修改屏幕与Wi-Fi。当前使用该版的同步图传、有限重试与自动重连，不再使用后续异步队列或6笔/16ms发送调度。

## 屏幕与Wi-Fi冻结约束

**接手新窗口必须先遵守本节。** 用户已批准本次回退与冻结；历史上“离线实时预览、后台建链、吞吐优化”的授权不再作为继续改动的依据。不得以优化帧率、保持屏幕实时、改善舵机响应或整理代码为由，再改写屏幕和Wi-Fi。需要改变时，先列出具体范围，取得用户新的明确授权。

- 基准是日志 **2026-10-03 14:32:41 +08:00** 的交付版本，即用户所称14:33版。
- 基准源码和固件保存在 [历史备份](../outputs/backups/car_before-screen-servo_20261003_155838.zip)。旧BIN的SHA256为 `48bfcdf148a78e1d88153aa2537f3d30243209f86caf8e48f0043a77a50a225a`。
- 本次回退前的应用与固件保存在 [回退前备份](../outputs/backups/car_before-display-wifi-rollback_20261003_191930.zip)。
- `camera_debug.c`、`camera_debug.h`、`camera_debug_config.h`的有效C代码与历史版一致，只保留中文说明性注释要求。屏幕图像、网络状态、统计逻辑与历史版一致，额外保留当前舵机状态行。
- 冻结范围包括上述图传模块、`camera_display.c/.h`、`main.c`中的摄像头显示/图传/重连调用顺序，以及对应屏幕、Wi-Fi引脚、SPI时钟、图像尺寸、传输参数和供应商接口。其他任务不得顺带修改这些内容。
- 后续新增的`wifi_spi_async.c/.h`、`wifi_spi_async_config.h`及其测试和工程引用已移除，不应重新引入。
- 舵机模块、配置、按键测试以及1ms时钟保留当前版本，没有恢复旧主循环的循迹打角。最终固件因此不是历史BIN的逐字节复制，而是历史屏幕/Wi-Fi与现有舵机的组合。

约30FPS是用户对旧版的历史实测描述；本次组合固件已通过软件验证，实际帧率仍需用户下载后观察。

## 硬件与接口

当前硬件为RT1064 V3.0主板、MIMXRT1064DVL6B核心板、MT9V034总钻风、普通IPS200 SPI屏和逐飞官方Wi-Fi SPI模块。

| 模块 | 接口与引脚 | 供电 |
| --- | --- | --- |
| MT9V034 | P2 CSI，使用逐飞摄像头接口 | CSI 3.3V |
| 普通IPS200 SPI | P6上排对应8针，SPI3：B0/SCL、B1/SDA、B2/RST、C19/DC、B3/CS、C18/BL | 3.3V与GND |
| Wi-Fi SPI | P7，SPI1：D12/SCK、D14/MOSI、D15/MISO、D13/CS、B17/INT、B16/RST | 5V_EXT与GND |

普通SPI屏与Wi-Fi SPI没有上述引脚冲突，不能套用并口IPS200、IPS200 Pro或Wi-Fi UART例程。接线与供电主记录见 [硬件与引脚](hardware-and-pins.md)。用户已确认只用电池、全部模块接回时电源灯全亮；沿用烧录后完全断电、移除DAP排线、再用电池运行的方式。DAP用于SWD下载，不承担图传。

## 当前代码流程

初始化屏幕与舵机安全上电状态，启动现有PIT计时，初始化摄像头，然后由`camera_debug_init`同步初始化Wi-Fi并连接电脑。

每圈主循环执行：

1. 处理舵机按键；调用`camera_debug_poll(app_uptime_ms)`更新统计或执行到期重连；返回后再处理按键。
2. 有新相机帧时，清完成标志并复制188×120原始灰度到应用缓冲。
3. `camera_debug_capture_frame`先显示原始灰度，并在网络就绪时保存同帧图传副本。
4. 处理直方图、Otsu二值化和左右/中边线，再由`camera_debug_send_frame`同步调用真实逐飞协议发送。
5. 网络发送返回后再次处理舵机按键。

屏幕为320×240横屏，原始灰度按282×180显示在(19,40)，保留宽高比。Wi-Fi发送188×120灰度和实际计算的三条边线，默认每个处理帧都尝试发送。库内部使用其原有的4088字节分块及INT就绪握手。

供应商发送函数返回未发送后缀长度；应用只重试该后缀，默认额外2次、间隔20ms。非法长度或重试耗尽后停止本帧后续块，记录失败阶段和剩余字节。

失败调用返回后，从首次poll开始等待5000ms再尝试重连。发送失败时先尝试关闭旧socket，随后硬件复位模块、重新入网和建立TCP；即使关闭失败也继续复位。新连接必须重新采集图像，不发送旧半帧。累计TX/E/R不因自动重连清零，配置错误不反复重试。

**保留历史同步等待行为：** 网络失败或禁用本身不会禁止本地预览，但首次联网、同步发送和重连期间主循环会等待，屏幕可能暂停，舵机按键和步进也会延后。供应商入网/TCP等待参数分别为10秒/50秒，函数可能多次等待，不能把它们当作整次恢复的严格时限。当前不保证断网时屏幕全程实时，也不为改变这一行为重新引入异步模块。

舵机配置、按键测试与保持特性见 [舵机指南](servo-debugging.md)。PIT1提供1ms时间基准，不代表S3响应时间为1ms；S3仍是主循环中的软件停止键。

## 参数入口

[camera_debug_config.h](../car/config/camera_debug_config.h)含本机热点密码，不得将密码写入日志、共享报告或聊天输出。网络凭据及目标地址与回退前一致。

| 宏 | 当前值或用途 |
| --- | --- |
| `CAMERA_DEBUG_ENABLED` | 1，启用Wi-Fi图传 |
| `CAMERA_DEBUG_IMAGE_MODE` | `CAMERA_DEBUG_GRAY`，原始灰度 |
| `CAMERA_DEBUG_FRAME_DIVIDER` | 1，按处理帧发送 |
| `CAMERA_DEBUG_WIFI_SSID` / `PASSWORD` | 已配置本机2.4GHz热点 |
| `CAMERA_DEBUG_WIFI_SERVER_IP` / `SERVER_PORT` | `192.168.137.1` / `8080` |
| `CAMERA_DEBUG_WIFI_LOCAL_PORT` | `0`，模块自动分配源端口 |
| `CAMERA_DEBUG_SEND_RETRY_LIMIT` | 2，额外重试次数 |
| `CAMERA_DEBUG_SEND_RETRY_DELAY_MS` | 20，重试间隔 |
| `CAMERA_DEBUG_RECONNECT_INTERVAL_MS` | 5000，失败返回后的回退间隔 |

上表用于识别冻结配置；调整也属于本页规定的修改边界。

## 逐飞助手1.2.7操作

1. 开启电脑已配置的2.4GHz移动热点，确认热点网卡地址为`192.168.137.1`。
2. 助手右侧选 **图像传输**，左侧选 **实时图像**。
3. 通信方式选 **网络 → TCP Server**，本机地址选`192.168.137.1`；列表没有时可选`0.0.0.0`监听所有本机地址。它仅是服务器绑定地址，不是固件目标地址。
4. 端口填`8080`，点击 **侦听**。
5. 关闭并重新打开 [car/autocar.uvprojx](../car/autocar.uvprojx)，**Rebuild后再下载**。本次删除了异步模块工程引用，不能直接下载旧临时目录中的AXF。
6. 完全断电并移除DAP排线，再仅用电池启动，等待旧版同步联网过程完成。
7. 助手出现模块客户端后，应显示188×120图像，FPS和接收字节率随实际传输更新。若没有图像，记录屏幕底部文字与TX/E/R。

不选择COM7，也不设置串口波特率。宽高、灰度类型和边线参数由逐飞协议携带。本任务不自动下载固件、操作助手或更改电脑网络。

## 屏幕状态

顶部`TX/E/R`分别是驱动接受的完整帧数、网络失败事件数和自动重连次数。TX不是电脑确认收图数量。第二行保留`S:...`、命令脉宽及`S2:run S3:stop`舵机提示。

| 底部状态 | 含义 |
| --- | --- |
| `Wi-Fi initializing / reconnecting` | 正在执行同步初始化或重连 |
| `TCP connecting to PC...` | 正在连接电脑TCP服务器 |
| `Wi-Fi TCP ready` | 固件已建立TCP连接，收图仍以电脑为准 |
| `Wi-Fi: check network config` | 网络参数格式或长度错误 |
| `Wi-Fi failed; waiting to reconnect` | 初始化或加入热点失败，等待下一次尝试 |
| `TCP failed; waiting to reconnect` | TCP连接失败，核对热点、电脑地址和侦听状态 |
| `TX ... rem:...; reconnect` | 某协议块发送失败，记录阶段及剩余字节后重连 |

失败阶段`head/image/b-head/left/middle/right`对应图像头、像素、边线头和三条边线。恢复历史版后不再使用异步模块的`receive`阶段提示。

## 软件验证与来源

- 图传适配、接口和配置的有效C代码与历史备份逐项一致；中文注释与换行整理未改变逻辑。屏幕除保留舵机状态行外与旧版一致。
- 历史图传24个场景、舵机6种配置、真实Wi-Fi SPI边界、4项构建脚本检查及19项算法检查通过；测试使用真实应用与协议，硬件I/O为主机桩。
- Keil MDK5.39 / Arm Compiler6.21全量构建0错误0警告。记录见 [回退测试](../logs/display-wifi-rollback-tests.log)、[算法测试](../logs/display-wifi-rollback-algorithms.log)、[回退构建](../logs/display-wifi-rollback-build.log) 和 [当日日志](../logs/2026-10-03.log)。
- 舵机、ISR、板级配置及519个供应商文件本轮保持不变。未测量实际FPS、SPI波形、PWM波形或DMA撕裂情况，不把主机测试当作实车验收。
- 接口依据 [RT1064 V3.0主板硬件说明](<../参考/RT1064 V3.0主板硬件说明 V1.0.pdf>)、[逐飞助手说明书V1.4](<D:/seekfree_assistant-V1.2.7/【文档】说明书/逐飞助手说明书 V1.4.pdf>)、[Wi-Fi SPI总钻风例程](../SeekFree/RT1064_Library/Example/Motherboard_Demo/E6_wireless/E6_09_wifi_spi_mt9v03x_demo/user/src/main.c) 和 [IPS200总钻风例程](../SeekFree/RT1064_Library/Example/Motherboard_Demo/E8_camera/E8_14_mt9v03x_ips200_display_demo/user/src/main.c)。
