#include "main.h"

/* 屏幕与Wi-Fi保留14:32:41版同步流程，仅增加获准的C13软件开关。
 * 网络调用前后服务舵机按键；同步连接、发送或重连期间主循环会等待。
 * 舵机1由servo_control独占；本测试不运行图像循迹打角，电机输出默认关闭。 */
uint8_t image[MT9V03X_H][MT9V03X_W];
short hist_gram[256];
uint8_t left_line[MT9V03X_H];
uint8_t mid_line[MT9V03X_H];
uint8_t right_line[MT9V03X_H];

static void app_init(void)
{
    camera_display_init();
    /* 上电只把舵机信号置低；S2启动小幅测试，S3停止新PWM指令。 */
    servo_control_init(app_uptime_ms);
    encoder_quad_init(ENCODER_1, ENCODER_1_A, ENCODER_1_B);
    encoder_quad_init(ENCODER_2, ENCODER_2_A, ENCODER_2_B);
    pwm_init(MOTOR1_PWM, 17000, 0);
    gpio_init(MOTOR1_DIR, GPO, GPIO_HIGH, GPO_PUSH_PULL);
    pwm_init(MOTOR2_PWM, 17000, 0);
    gpio_init(MOTOR2_DIR, GPO, GPIO_HIGH, GPO_PUSH_PULL);
    My_Pid_Init();
    /* 编码器控制仍为10ms；网络与舵机状态机使用独立1ms时钟。 */
    pit_ms_init(PIT_CH0, APP_CONTROL_PERIOD_MS);
    pit_ms_init(PIT_CH1, APP_SYSTEM_TICK_MS);
    interrupt_global_enable(0);

    while (mt9v03x_init())
    {
        camera_display_message("Camera init failed; check CSI/power");
        system_delay_ms(1000);
    }
    camera_display_message("Camera ready");
    /* 默认Wi-Fi关闭，仅初始化本地按键；按C13后才走原版同步建链。 */
    (void)camera_debug_init(left_line, mid_line, right_line);
    camera_display_message("PC " CAMERA_DEBUG_WIFI_SERVER_IP ":" CAMERA_DEBUG_WIFI_SERVER_PORT);
}

int main(void)
{
    clock_init(SYSTEM_CLOCK_600M);
    debug_init();
    system_delay_ms(300); // 启动时等待板上外设供电稳定，不用于运行期Wi-Fi等待。
    app_init();

    while (1)
    {
        servo_control_poll(app_uptime_ms);
        camera_debug_poll(app_uptime_ms);
        servo_control_poll(app_uptime_ms);
        if (mt9v03x_finish_flag)
        {
            /* 先确认完成标志，再短时间复制供应商完成缓冲；后续模块只读应用副本。 */
            mt9v03x_finish_flag = 0;
            memcpy(image[0], mt9v03x_image[0], sizeof(image));
            camera_debug_capture_frame(image[0]); // 无论Wi-Fi状态如何，先显示当前灰度。
            servo_control_poll(app_uptime_ms);  // 完成一次刷屏后及时处理停止键。

            get_hist_g-0ram(image[0], MT9V03X_H, MT9V03X_W, hist_gram);
            unsigned char threshold = get_threshold_otsu(hist_gram);
            binaryzation_process(image[0], MT9V03X_H, MT9V03X_W, threshold);
            auxiliary_process(image[0], MT9V03X_H, MT9V03X_W, 127, left_line, mid_line, right_line);
            camera_debug_send_frame(image[0]); // 沿用历史版同步发送及未发送后缀有限重试。
        }
        /* 发送返回后再次检查按键；没有新图像时也逐圈处理按键和网络恢复。 */
        servo_control_poll(app_uptime_ms);
    }
}
