/* 使用真实舵机模块验证手动中位校准，只替换GPIO/PWM硬件。 */
#include <stdio.h>
#include <stdlib.h>
#include "servo_control.h"
#include "servo_config.h"
#include "zf_driver_gpio.h"
#include "zf_driver_pwm.h"

static unsigned checks, pwm_starts, pwm_writes, key_initializations;
static uint8_t plus_key, minus_key, stop_key, signal_low;
static uint32_t duty;
#define CHECK(x, msg) do { ++checks; if (!(x)) { printf("FAIL line %d: %s\n", __LINE__, msg); exit(1); } } while (0)

void gpio_init(gpio_pin_enum pin, gpio_dir_enum direction, uint8_t level, uint32_t mode)
{
    if (pin == C30) {
        CHECK(direction == GPO && level == GPIO_LOW && mode == GPO_PUSH_PULL, "signal must stop as GPIO low");
        signal_low = 1;
    } else {
        CHECK((pin == C12 || pin == C14 || pin == C15) && direction == GPI &&
              level == GPIO_HIGH && mode == GPI_PULL_UP, "only calibration and stop keys may be initialized");
        ++key_initializations;
    }
}
uint8_t gpio_get_level(gpio_pin_enum pin)
{
    CHECK(pin == C12 || pin == C14 || pin == C15, "C13 Wi-Fi key must not be read by servo");
    return pin == C12 ? minus_key : pin == C14 ? stop_key : plus_key;
}
void pwm_init(pwm_channel_enum channel, uint32_t frequency, uint32_t value)
{
    CHECK(channel == PWM4_MODULE2_CHA_C30 && frequency == 50, "connector 1 at 50Hz");
    signal_low = 0; duty = value; ++pwm_starts;
}
void pwm_set_duty(pwm_channel_enum channel, uint32_t value)
{
    CHECK(channel == PWM4_MODULE2_CHA_C30 && value <= PWM_DUTY_MAX, "valid channel and duty scale");
    duty = value; ++pwm_writes;
}
static const servo_control_status_t *status(void) { return servo_control_get_status(); }
#if SERVO_SUPPLY_MV >= 6000 && SERVO_SUPPLY_MV <= 7400
static void check_pulse(uint16_t pulse)
{
    uint32_t expected = (uint32_t)(((uint64_t)pulse * 50U * PWM_DUTY_MAX + 500000U) / 1000000U);
    CHECK(status()->output_enabled && !signal_low, "calibration output enabled");
    CHECK(status()->current_pulse_us == pulse && status()->target_pulse_us == pulse, "expected manual pulse");
    CHECK(duty == expected, "pulse uses actual library duty scale");
    CHECK(pulse >= 1480 && pulse <= 1560, "absolute calibration bounds");
}
#endif
static void reset(uint32_t now, uint8_t plus, uint8_t minus)
{
    plus_key = plus; minus_key = minus; stop_key = GPIO_HIGH;
    pwm_starts = 0; pwm_writes = 0; key_initializations = 0; signal_low = 0; duty = 0;
    servo_control_init(now);
    CHECK(signal_low && !status()->output_enabled && pwm_starts == 0, "no automatic PWM at boot");
    CHECK(key_initializations == 3, "initialize C15/C12 adjust and C14 stop");
}
static uint32_t press(uint32_t now, uint8_t increase)
{
    plus_key = minus_key = GPIO_HIGH;
    servo_control_poll(now); servo_control_poll(now + 30U);
    if (increase) plus_key = GPIO_LOW; else minus_key = GPIO_LOW;
    servo_control_poll(now + 31U); servo_control_poll(now + 61U);
    return now + 62U;
}
#if SERVO_SUPPLY_MV >= 6000 && SERVO_SUPPLY_MV <= 7400
static void test_manual_only(void)
{
    uint32_t now;
    reset(0, GPIO_HIGH, GPIO_HIGH);
    servo_control_poll(10000);
    CHECK(pwm_starts == 0, "time alone cannot start output");
    CHECK(servo_control_start_test(10001) == SERVO_CONTROL_START_NOT_ARMED, "API cannot bypass physical press");
    now = press(10010, 0);
    CHECK(pwm_starts == 0, "minus cannot start output");
    now = press(now, 1); check_pulse(1520);
    servo_control_poll(now + 10000); servo_control_poll(now + 20000); check_pulse(1520);
    CHECK(pwm_starts == 1, "held plus cannot restart or sweep");
    now = press(now + 20010, 1); check_pulse(1522);
    now = press(now, 0); check_pulse(1520);
    (void)press(now, 0); check_pulse(1518);
}
static void test_limits(void)
{
    uint32_t now; unsigned i;
    reset(0, GPIO_HIGH, GPIO_HIGH); now = press(0, 1);
    for (i = 0; i < 60; ++i) {
        uint16_t previous = status()->current_pulse_us;
        now = press(now, 1);
        CHECK(status()->current_pulse_us - previous <= 2, "plus step no more than 2us");
    }
    check_pulse(1560);
    for (i = 0; i < 100; ++i) {
        uint16_t previous = status()->current_pulse_us;
        now = press(now, 0);
        CHECK(previous - status()->current_pulse_us <= 2, "minus step no more than 2us");
    }
    check_pulse(1480);
}
static void test_stop_and_resume(void)
{
    uint32_t now;
    reset(0, GPIO_HIGH, GPIO_HIGH); now = press(0, 1); now = press(now, 1); check_pulse(1522);
    plus_key = GPIO_HIGH; minus_key = GPIO_HIGH;
    servo_control_poll(now); servo_control_poll(now + 30);
    minus_key = GPIO_LOW; servo_control_poll(now + 31);
    stop_key = GPIO_LOW; servo_control_poll(now + 61);
    CHECK(signal_low && !status()->output_enabled && duty == 0, "stop wins over pending decrement");
    CHECK(status()->current_pulse_us == 0 && status()->target_pulse_us == 0, "stopped command fields are zero");
    CHECK(servo_control_start_test(now + 62) == SERVO_CONTROL_START_STOP_HELD, "held stop cannot be bypassed");
    stop_key = GPIO_HIGH; servo_control_poll(now + 70); servo_control_poll(now + 1000);
    CHECK(pwm_starts == 1 && !status()->output_enabled, "releasing stop never auto resumes");
    now = press(now + 1010, 1); check_pulse(1522);
    CHECK(pwm_starts == 2, "first plus after stop resumes retained candidate, no extra step");
    plus_key = GPIO_HIGH; servo_control_poll(now); servo_control_poll(now + 30);
    plus_key = GPIO_LOW; servo_control_poll(now + 31);
    servo_control_stop(); servo_control_poll(now + 61);
    CHECK(!status()->output_enabled && pwm_starts == 2, "explicit stop cancels pending plus");
    (void)press(now + 100, 1); check_pulse(1522);
}
static void test_conflicting_keys(void)
{
    uint32_t now;
    reset(0, GPIO_HIGH, GPIO_HIGH); servo_control_poll(30);
    plus_key = minus_key = GPIO_LOW; servo_control_poll(31); servo_control_poll(100);
    CHECK(pwm_starts == 0, "both adjust keys must not start");
    minus_key = GPIO_HIGH; servo_control_poll(101); servo_control_poll(200);
    CHECK(pwm_starts == 0, "remaining held plus cannot start after chord");
    now = press(300, 1); check_pulse(1520);
    minus_key = GPIO_LOW; servo_control_poll(now); servo_control_poll(now + 100);
    check_pulse(1520);
    plus_key = GPIO_HIGH; servo_control_poll(now + 101); servo_control_poll(now + 200); check_pulse(1520);
    (void)press(now + 300, 0); check_pulse(1518);
}
static void test_debounce_and_wrap(void)
{
    uint32_t now = UINT32_MAX - 20U;
    reset(now, GPIO_LOW, GPIO_LOW);
    servo_control_poll(now + 100); CHECK(pwm_starts == 0, "boot held keys never start");
    now = press(now + 200, 1); check_pulse(1520);
    plus_key = GPIO_HIGH; servo_control_poll(now); servo_control_poll(now + 29);
    plus_key = GPIO_LOW; servo_control_poll(now + 30); servo_control_poll(now + 100); check_pulse(1520);
    plus_key = GPIO_HIGH; servo_control_poll(now + 110); servo_control_poll(now + 140);
    plus_key = GPIO_LOW; servo_control_poll(now + 141); servo_control_poll(now + 170); check_pulse(1520);
    plus_key = GPIO_HIGH; servo_control_poll(now + 171);
    plus_key = GPIO_LOW; servo_control_poll(now + 172); servo_control_poll(now + 201); check_pulse(1520);
    servo_control_poll(now + 202); check_pulse(1522);
    reset(UINT32_MAX - 15U, GPIO_HIGH, GPIO_HIGH);
    (void)press(UINT32_MAX - 15U, 1); check_pulse(1520);
}
#endif
int main(void)
{
#if SERVO_SUPPLY_MV < 6000 || SERVO_SUPPLY_MV > 7400
    reset(0, GPIO_HIGH, GPIO_HIGH);
    CHECK(status()->state == SERVO_CONTROL_SUPPLY_ERROR, "invalid supply visible");
    (void)press(0, 1); (void)press(100, 0);
    CHECK(pwm_starts == 0 && signal_low && !status()->output_enabled, "keys cannot bypass supply gate");
#else
    test_manual_only(); test_limits(); test_stop_and_resume(); test_conflicting_keys(); test_debounce_and_wrap();
#endif
    printf("PASS: %u calibration checks\n", checks); return 0;
}
