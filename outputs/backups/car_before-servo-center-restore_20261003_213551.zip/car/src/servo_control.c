#include "servo_control.h"
#include "servo_config.h"
#include "zf_driver_gpio.h"
#include "zf_driver_pwm.h"

static servo_control_status_t servo_status;
#if !SERVO_CALIBRATION_MODE
static uint32_t servo_phase_started_ms;
static uint32_t servo_last_step_ms;
#else
static uint32_t servo_decrease_changed_ms;
static uint8_t servo_decrease_sample, servo_decrease_stable, servo_decrease_armed;
#endif
static uint32_t servo_key_changed_ms;
static uint8_t servo_start_sample;
static uint8_t servo_start_stable;
static uint8_t servo_start_armed;
static uint8_t servo_pwm_initialized;

static uint8_t servo_supply_is_valid(void)
{
    return (SERVO_SUPPLY_MV >= SERVO_SUPPLY_MIN_MV &&
            SERVO_SUPPLY_MV <= SERVO_SUPPLY_MAX_MV) ? 1U : 0U;
}

static uint32_t servo_pulse_to_duty(uint16_t pulse_us)
{
    uint64_t duty;

    /* 只允许当前模式的批准窗口；使用库的占空比尺度，不套用全行程角度公式。 */
#if SERVO_CALIBRATION_MODE
    if (pulse_us < SERVO_CALIBRATION_MIN_US) pulse_us = SERVO_CALIBRATION_MIN_US;
    if (pulse_us > SERVO_CALIBRATION_MAX_US) pulse_us = SERVO_CALIBRATION_MAX_US;
#else
    if (pulse_us < SERVO_TEST_MIN_PULSE_US) pulse_us = SERVO_TEST_MIN_PULSE_US;
    if (pulse_us > SERVO_TEST_MAX_PULSE_US) pulse_us = SERVO_TEST_MAX_PULSE_US;
#endif
    duty = ((uint64_t)pulse_us * SERVO_PWM_FREQUENCY_HZ * PWM_DUTY_MAX + 500000U) / 1000000U;
    if (duty > PWM_DUTY_MAX) duty = PWM_DUTY_MAX;
    return (uint32_t)duty;
}

static void servo_disable_output(void)
{
    /* 库的零占空比经PWM整周期重载；切回低电平GPIO不等这个重载。
     * C30由本模块独占，仍有舵机供电，不能等同硬件急停或切断转矩。 */
    if (servo_pwm_initialized) pwm_set_duty(SERVO_PWM_CHANNEL, 0U);
    gpio_init(SERVO_SIGNAL_PIN, GPO, GPIO_LOW, GPO_PUSH_PULL);
    servo_status.output_enabled = 0U;
    servo_status.current_pulse_us = 0U;
    servo_status.target_pulse_us = 0U;
}

#if SERVO_CALIBRATION_MODE
static void servo_calibration_step(uint8_t increase)
{
    uint16_t pulse = servo_status.calibration_pulse_us;
    if (!servo_status.output_enabled) return;
    if (increase)
        pulse = (SERVO_CALIBRATION_MAX_US - pulse <= SERVO_CALIBRATION_STEP_US) ?
                SERVO_CALIBRATION_MAX_US : (uint16_t)(pulse + SERVO_CALIBRATION_STEP_US);
    else
        pulse = (pulse - SERVO_CALIBRATION_MIN_US <= SERVO_CALIBRATION_STEP_US) ?
                SERVO_CALIBRATION_MIN_US : (uint16_t)(pulse - SERVO_CALIBRATION_STEP_US);
    if (pulse == servo_status.calibration_pulse_us) return;
    servo_status.calibration_pulse_us = pulse;
    servo_status.current_pulse_us = pulse;
    servo_status.target_pulse_us = pulse;
    pwm_set_duty(SERVO_PWM_CHANNEL, servo_pulse_to_duty(pulse));
}
#else
static uint8_t servo_test_is_running(void)
{
    return (servo_status.state >= SERVO_CONTROL_CENTER &&
            servo_status.state <= SERVO_CONTROL_RETURN_CENTER) ? 1U : 0U;
}
#endif

void servo_control_init(uint32_t now_ms)
{
    servo_pwm_initialized = 0U;
    servo_disable_output();
    gpio_init(SERVO_START_KEY_PIN, GPI, GPIO_HIGH, GPI_PULL_UP);
    gpio_init(SERVO_STOP_KEY_PIN, GPI, GPIO_HIGH, GPI_PULL_UP);
    servo_start_sample = gpio_get_level(SERVO_START_KEY_PIN);
    /* 即便上电时按键已抬起，也先观察30ms稳定释放；按住上电不启动。 */
    servo_start_stable = SERVO_KEY_ACTIVE_LEVEL;
    servo_start_armed = 0U;
    servo_key_changed_ms = now_ms;
    servo_status.calibration_pulse_us = SERVO_REFERENCE_CENTER_US;
#if SERVO_CALIBRATION_MODE
    gpio_init(SERVO_CALIBRATION_DECREASE_KEY_PIN, GPI, GPIO_HIGH, GPI_PULL_UP);
    servo_decrease_sample = gpio_get_level(SERVO_CALIBRATION_DECREASE_KEY_PIN);
    servo_decrease_stable = SERVO_KEY_ACTIVE_LEVEL;
    servo_decrease_armed = 0U;
    servo_decrease_changed_ms = now_ms;
#else
    servo_phase_started_ms = now_ms;
    servo_last_step_ms = now_ms;
#endif
    servo_status.state = servo_supply_is_valid() ? SERVO_CONTROL_IDLE : SERVO_CONTROL_SUPPLY_ERROR;
}

servo_control_result_t servo_control_start_test(uint32_t now_ms)
{
    if (gpio_get_level(SERVO_STOP_KEY_PIN) == SERVO_KEY_ACTIVE_LEVEL)
    {
        servo_control_stop();
        return SERVO_CONTROL_START_STOP_HELD;
    }
    if (!servo_supply_is_valid())
    {
        servo_disable_output();
        servo_start_armed = 0U;
        servo_status.state = SERVO_CONTROL_SUPPLY_ERROR;
        return SERVO_CONTROL_START_SUPPLY_ERROR;
    }
    if (!servo_start_armed || servo_start_stable != SERVO_KEY_ACTIVE_LEVEL ||
        servo_start_sample != SERVO_KEY_ACTIVE_LEVEL ||
        gpio_get_level(SERVO_START_KEY_PIN) != SERVO_KEY_ACTIVE_LEVEL)
    {
        return SERVO_CONTROL_START_NOT_ARMED;
    }
    /* 忙时也消费本次按下，不能把它排队为结束后的自动重试。 */
    servo_start_armed = 0U;
#if SERVO_CALIBRATION_MODE
    (void)now_ms;
    if (gpio_get_level(SERVO_CALIBRATION_DECREASE_KEY_PIN) == SERVO_KEY_ACTIVE_LEVEL)
        return SERVO_CONTROL_START_NOT_ARMED;
    if (servo_status.output_enabled)
    {
        servo_calibration_step(1U);
    }
    else
    {
        /* 首次启用或停止后恢复，只输出已有候选值，不额外增加一步。 */
        pwm_init(SERVO_PWM_CHANNEL, SERVO_PWM_FREQUENCY_HZ,
                 servo_pulse_to_duty(servo_status.calibration_pulse_us));
        servo_pwm_initialized = 1U;
        servo_status.current_pulse_us = servo_status.calibration_pulse_us;
        servo_status.target_pulse_us = servo_status.calibration_pulse_us;
        servo_status.output_enabled = 1U;
    }
    servo_status.state = SERVO_CONTROL_CALIBRATING;
#else
    if (servo_test_is_running()) return SERVO_CONTROL_START_BUSY;

    pwm_init(SERVO_PWM_CHANNEL, SERVO_PWM_FREQUENCY_HZ,
             servo_pulse_to_duty(SERVO_REFERENCE_CENTER_US));
    servo_pwm_initialized = 1U;
    servo_status.current_pulse_us = SERVO_REFERENCE_CENTER_US;
    servo_status.target_pulse_us = SERVO_REFERENCE_CENTER_US;
    servo_status.output_enabled = 1U;
    servo_status.state = SERVO_CONTROL_CENTER;
    servo_phase_started_ms = now_ms;
    servo_last_step_ms = now_ms;
#endif
    return SERVO_CONTROL_START_OK;
}

void servo_control_stop(void)
{
    servo_disable_output();
    servo_status.state = SERVO_CONTROL_STOPPED;
    servo_start_armed = 0U;
    /* 撤销尚未消抖完成的按下；下一次必须重新观察稳定释放。 */
    servo_start_sample = SERVO_KEY_ACTIVE_LEVEL;
    servo_start_stable = SERVO_KEY_ACTIVE_LEVEL;
#if SERVO_CALIBRATION_MODE
    servo_decrease_sample = SERVO_KEY_ACTIVE_LEVEL;
    servo_decrease_stable = SERVO_KEY_ACTIVE_LEVEL;
    servo_decrease_armed = 0U;
#endif
}

#if !SERVO_CALIBRATION_MODE
static void servo_begin_motion(servo_control_state_t state, uint16_t target_us, uint32_t now_ms)
{
    servo_status.state = state;
    servo_status.target_pulse_us = target_us;
    servo_last_step_ms = now_ms;
}

static void servo_advance_motion(uint32_t now_ms)
{
    uint16_t current = servo_status.current_pulse_us;
    uint16_t target = servo_status.target_pulse_us;

    if ((uint32_t)(now_ms - servo_last_step_ms) < SERVO_TEST_STEP_INTERVAL_MS) return;
    /* 一次poll最多走一步，迟到时从现在重计时，不追赶积压产生突跳。 */
    servo_last_step_ms = now_ms;
    if (current < target)
    {
        current = ((uint32_t)(target - current) <= SERVO_TEST_STEP_US) ?
                  target : (uint16_t)(current + SERVO_TEST_STEP_US);
    }
    else if (current > target)
    {
        current = ((uint32_t)(current - target) <= SERVO_TEST_STEP_US) ?
                  target : (uint16_t)(current - SERVO_TEST_STEP_US);
    }
    servo_status.current_pulse_us = current;
    pwm_set_duty(SERVO_PWM_CHANNEL, servo_pulse_to_duty(current));
    if (current == target)
    {
        servo_phase_started_ms = now_ms;
        if (servo_status.state == SERVO_CONTROL_TO_LOW) servo_status.state = SERVO_CONTROL_HOLD_LOW;
        else if (servo_status.state == SERVO_CONTROL_TO_HIGH) servo_status.state = SERVO_CONTROL_HOLD_HIGH;
        else servo_status.state = SERVO_CONTROL_COMPLETE;
    }
}

#endif

void servo_control_poll(uint32_t now_ms)
{
    uint8_t start_sample;
#if SERVO_CALIBRATION_MODE
    uint8_t decrease_sample;
#endif

    /* 停止不等消抖，宁可因抖动停止；不能让同次启动事件抢先产生PWM。 */
    if (gpio_get_level(SERVO_STOP_KEY_PIN) == SERVO_KEY_ACTIVE_LEVEL)
    {
        if (servo_status.state != SERVO_CONTROL_STOPPED) servo_control_stop();
        return;
    }

    start_sample = gpio_get_level(SERVO_START_KEY_PIN);
#if SERVO_CALIBRATION_MODE
    decrease_sample = gpio_get_level(SERVO_CALIBRATION_DECREASE_KEY_PIN);
    if (start_sample == SERVO_KEY_ACTIVE_LEVEL && decrease_sample == SERVO_KEY_ACTIVE_LEVEL)
    {
        /* 同按增减时不移动；消费两键，防止松开其中一键后意外启动或调整。 */
        servo_start_sample = servo_start_stable = SERVO_KEY_ACTIVE_LEVEL;
        servo_start_armed = 0U; servo_key_changed_ms = now_ms;
        servo_decrease_sample = servo_decrease_stable = SERVO_KEY_ACTIVE_LEVEL;
        servo_decrease_armed = 0U; servo_decrease_changed_ms = now_ms;
        return;
    }
#endif
    if (start_sample != servo_start_sample)
    {
        servo_start_sample = start_sample;
        servo_key_changed_ms = now_ms;
    }
    if ((uint32_t)(now_ms - servo_key_changed_ms) >= SERVO_KEY_DEBOUNCE_MS)
    {
        if (start_sample != SERVO_KEY_ACTIVE_LEVEL)
        {
            servo_start_stable = start_sample;
            servo_start_armed = 1U;
        }
        else if (servo_start_stable != SERVO_KEY_ACTIVE_LEVEL)
        {
            servo_start_stable = start_sample;
            (void)servo_control_start_test(now_ms);
        }
    }

#if SERVO_CALIBRATION_MODE
    if (decrease_sample != servo_decrease_sample)
    {
        servo_decrease_sample = decrease_sample;
        servo_decrease_changed_ms = now_ms;
    }
    if ((uint32_t)(now_ms - servo_decrease_changed_ms) >= SERVO_KEY_DEBOUNCE_MS)
    {
        if (decrease_sample != SERVO_KEY_ACTIVE_LEVEL)
        {
            servo_decrease_stable = decrease_sample;
            servo_decrease_armed = 1U;
        }
        else if (servo_decrease_stable != decrease_sample)
        {
            servo_decrease_stable = decrease_sample;
            if (servo_decrease_armed) servo_calibration_step(0U);
            servo_decrease_armed = 0U;
        }
    }
#else
    switch (servo_status.state)
    {
        case SERVO_CONTROL_CENTER:
            if ((uint32_t)(now_ms - servo_phase_started_ms) >= SERVO_TEST_CENTER_HOLD_MS)
                servo_begin_motion(SERVO_CONTROL_TO_LOW, SERVO_TEST_MIN_PULSE_US, now_ms);
            break;
        case SERVO_CONTROL_HOLD_LOW:
            if ((uint32_t)(now_ms - servo_phase_started_ms) >= SERVO_TEST_ENDPOINT_HOLD_MS)
                servo_begin_motion(SERVO_CONTROL_TO_HIGH, SERVO_TEST_MAX_PULSE_US, now_ms);
            break;
        case SERVO_CONTROL_HOLD_HIGH:
            if ((uint32_t)(now_ms - servo_phase_started_ms) >= SERVO_TEST_ENDPOINT_HOLD_MS)
                servo_begin_motion(SERVO_CONTROL_RETURN_CENTER, SERVO_REFERENCE_CENTER_US, now_ms);
            break;
        case SERVO_CONTROL_TO_LOW:
        case SERVO_CONTROL_TO_HIGH:
        case SERVO_CONTROL_RETURN_CENTER:
            servo_advance_motion(now_ms);
            break;
        default:
            break;
    }
#endif
}

const servo_control_status_t *servo_control_get_status(void)
{
    return &servo_status;
}
