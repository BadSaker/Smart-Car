/* Application adaptation of the SeekFree Assistant MT9V03X example.
 * Original example: Copyright (c) 2022 SEEKFREE 逐飞科技.
 * SPDX-License-Identifier: GPL-3.0-or-later
 * See car/library/LICENSE and docs/seekfree-assistant-debugging.md for provenance.
 * This adapter keeps the existing V3.11.2 protocol library unchanged. */
#include "zf_common_headfile.h"
#include "camera_debug.h"
#include "camera_display.h"

volatile camera_debug_status_t camera_debug_status = CAMERA_DEBUG_DISABLED;
volatile uint32_t camera_debug_frames_sent = 0;

#if CAMERA_DEBUG_ENABLED
#if MT9V03X_W > 255 || MT9V03X_H > 255
#error "The application boundary arrays use 8-bit coordinates"
#endif

extern seekfree_assistant_transfer_callback_function seekfree_assistant_transfer_callback;
static seekfree_assistant_transfer_callback_function transport_write;
static uint32_t frame_sequence;
static uint8_t frame_available;
#if CAMERA_DEBUG_IMAGE_MODE != CAMERA_DEBUG_BOUNDARIES_ONLY
static uint8_t transmit_image[MT9V03X_H][MT9V03X_W];
#endif

static uint8_t valid_port(const char *text, uint32 minimum)
{
    uint32 value = 0;
    size_t i, length = strlen(text);
    if (length == 0U || length > 5U) return 0;
    for (i = 0; i < length; ++i)
    {
        if (text[i] < '0' || text[i] > '9') return 0;
        value = value * 10U + (uint32)(text[i] - '0');
    }
    return value >= minimum && value <= 65535U;
}

static uint8_t valid_ipv4(const char *text)
{
    uint32 part = 0, digits = 0, dots = 0;
    if (strlen(text) > 15U) return 0;
    for (;; ++text)
    {
        if (*text >= '0' && *text <= '9')
        {
            part = part * 10U + (uint32)(*text - '0');
            if (++digits > 3U || part > 255U) return 0;
        }
        else if (*text == '.' || *text == '\0')
        {
            if (digits == 0U) return 0;
            if (*text == '\0') return dots == 3U;
            if (++dots > 3U) return 0;
            part = 0; digits = 0;
        }
        else return 0;
    }
}

static uint8_t valid_credentials(const char *ssid, const char *password)
{
    size_t ssid_length = strlen(ssid), password_length = strlen(password);
    /* Two CRLFs plus NUL must also fit the vendor's 64-byte sprintf buffer. */
    return ssid_length > 0U && ssid_length <= 32U &&
           ssid_length + password_length <= 59U &&
           strpbrk(ssid, "\r\n") == NULL && strpbrk(password, "\r\n") == NULL;
}

/* The vendor packet sender ignores callback return values. Stop later chunks
 * after a transport failure, so they do not continue an incomplete frame. */
static uint32 camera_debug_transfer(const uint8 *data, uint32 length)
{
    uint32 remaining;
    if (camera_debug_status != CAMERA_DEBUG_READY || transport_write == NULL)
        return length;
    remaining = transport_write(data, length);
    if (remaining != 0U)
    {
        camera_debug_status = CAMERA_DEBUG_SEND_ERROR;
        camera_display_network_status(camera_debug_status);
    }
    return remaining;
}
#endif

uint8_t camera_debug_init(uint8_t *left, uint8_t *middle, uint8_t *right)
{
    camera_debug_status = CAMERA_DEBUG_DISABLED;
    camera_debug_frames_sent = 0;
#if CAMERA_DEBUG_ENABLED
    frame_sequence = 0;
    frame_available = 0;
    transport_write = NULL;
    if (left == NULL || middle == NULL || right == NULL)
    {
        camera_debug_status = CAMERA_DEBUG_CONFIG_ERROR;
        camera_display_network_status(camera_debug_status);
        return 1;
    }
    char ssid[] = CAMERA_DEBUG_WIFI_SSID;
    char password[] = CAMERA_DEBUG_WIFI_PASSWORD;
    char server_ip[] = CAMERA_DEBUG_WIFI_SERVER_IP;
    char server_port[] = CAMERA_DEBUG_WIFI_SERVER_PORT;
    char local_port[] = CAMERA_DEBUG_WIFI_LOCAL_PORT;
    if (!valid_credentials(ssid, password) || !valid_ipv4(server_ip) ||
        !valid_port(server_port, 1U) ||
        (strcmp(local_port, "0") != 0 && !valid_port(local_port, 2048U)))
    {
        camera_debug_status = CAMERA_DEBUG_CONFIG_ERROR;
        camera_display_network_status(camera_debug_status);
        return 1;
    }
    camera_display_message("Wi-Fi module joining network...");
    if (wifi_spi_init(ssid, password[0] != '\0' ? password : NULL))
    {
        camera_debug_status = CAMERA_DEBUG_INIT_ERROR;
        camera_display_network_status(camera_debug_status);
        return 1;
    }
    camera_display_message("Connecting to PC TCP server...");
    if (wifi_spi_socket_connect("TCP", server_ip, server_port, local_port))
    {
        camera_debug_status = CAMERA_DEBUG_CONNECT_ERROR;
        camera_display_network_status(camera_debug_status);
        return 1;
    }
    seekfree_assistant_interface_init(SEEKFREE_ASSISTANT_WIFI_SPI);
    transport_write = seekfree_assistant_transfer_callback;
    seekfree_assistant_transfer_callback = camera_debug_transfer;
#if CAMERA_DEBUG_IMAGE_MODE == CAMERA_DEBUG_BOUNDARIES_ONLY
    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, NULL, MT9V03X_W, MT9V03X_H);
#else
    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, transmit_image[0], MT9V03X_W, MT9V03X_H);
#endif
    seekfree_assistant_camera_boundary_config(X_BOUNDARY, MT9V03X_H, left, middle, right, NULL, NULL, NULL);
    camera_debug_status = CAMERA_DEBUG_READY;
#else
    (void)left; (void)middle; (void)right;
#endif
    camera_display_network_status(camera_debug_status);
    return 0;
}

void camera_debug_capture_frame(const uint8_t *gray_image)
{
    /* Preview is independent of wireless status, before any binarization. */
    camera_display_frame(gray_image);
#if CAMERA_DEBUG_ENABLED
    if (camera_debug_status != CAMERA_DEBUG_READY || gray_image == NULL) return;
#if CAMERA_DEBUG_IMAGE_MODE == CAMERA_DEBUG_GRAY
    memcpy(transmit_image[0], gray_image, sizeof(transmit_image));
#endif
    frame_available = 1;
#else
    (void)gray_image;
#endif
}

void camera_debug_send_frame(const uint8_t *binary_image)
{
#if CAMERA_DEBUG_ENABLED
    if (camera_debug_status != CAMERA_DEBUG_READY || !frame_available) return;
    frame_available = 0;
    if (frame_sequence++ % CAMERA_DEBUG_FRAME_DIVIDER != 0U) return;
#if CAMERA_DEBUG_IMAGE_MODE == CAMERA_DEBUG_BINARY
    if (binary_image == NULL) return;
    memcpy(transmit_image[0], binary_image, sizeof(transmit_image));
#else
    (void)binary_image;
#endif
    seekfree_assistant_camera_send();
    if (camera_debug_status == CAMERA_DEBUG_READY) ++camera_debug_frames_sent;
#else
    (void)binary_image;
#endif
}
