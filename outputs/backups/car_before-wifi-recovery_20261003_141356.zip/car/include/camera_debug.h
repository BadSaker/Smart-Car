#ifndef AUTOCAR_CAMERA_DEBUG_H
#define AUTOCAR_CAMERA_DEBUG_H

#include <stdint.h>
#include "camera_debug_config.h"

typedef enum
{
    CAMERA_DEBUG_DISABLED,
    CAMERA_DEBUG_READY,
    CAMERA_DEBUG_CONFIG_ERROR,
    CAMERA_DEBUG_INIT_ERROR,
    CAMERA_DEBUG_CONNECT_ERROR,
    CAMERA_DEBUG_SEND_ERROR
} camera_debug_status_t;

extern volatile camera_debug_status_t camera_debug_status;
extern volatile uint32_t camera_debug_frames_sent;

/* 0 = initialized (or intentionally disabled); nonzero = failure.
 * Boundary arrays must remain valid and contain one X coordinate per image row. */
uint8_t camera_debug_init(uint8_t *left, uint8_t *middle, uint8_t *right);
/* Main-loop only: display raw grayscale and capture a wireless snapshot before
 * modifying it. Local preview also works with a failed/disabled network. */
void camera_debug_capture_frame(const uint8_t *gray_image);
/* Main-loop only, after line extraction and before drawing into the image.
 * Binary view uses one GRAY byte per pixel (0/255), not packed 1-bit pixels.
 * Transmission blocks. On failure, reset/reinitialize before transmitting again. */
void camera_debug_send_frame(const uint8_t *binary_image);

#endif
