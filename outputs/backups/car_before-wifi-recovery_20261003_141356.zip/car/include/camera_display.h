#ifndef AUTOCAR_CAMERA_DISPLAY_H
#define AUTOCAR_CAMERA_DISPLAY_H
#include <stdint.h>
#include "camera_debug.h"
/* Main-loop only. Ordinary IPS200 SPI on the RT1064 V3.0 P6 connector. */
void camera_display_init(void);
void camera_display_message(const char *text);
void camera_display_network_status(camera_debug_status_t status);
/* Display raw grayscale without modifying the caller's stable frame. */
void camera_display_frame(const uint8_t *gray_image);
#endif
