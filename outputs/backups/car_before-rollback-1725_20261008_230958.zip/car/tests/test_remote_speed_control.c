#include "remote_speed_control.h"
#include "remote_speed_config.h"
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

#define CHECK(condition) do { if (!(condition)) { \
    fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #condition); return 1; \
} } while (0)

/* 手算目标每拍增加15 mm/s；测试使用真实PID，不替换控制算法。 */
static int test_ramp(void)
{
    remote_speed_control_t ctx;
    remote_speed_output_t out;
    unsigned i;
    unsigned previous = 0;
    remote_speed_control_init(&ctx);
    for (i = 1; i <= 24; ++i)
    {
        remote_speed_control_step(&ctx, 350, 20, 20, i, &out);
        CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
        CHECK(out.target_mm_s == (i < 24 ? (int16_t)(15 * i) : 350));
        CHECK(out.left_duty_permille <= previous + 8);
        CHECK(out.left_duty_permille <= 200);
        CHECK(out.left_duty_permille == out.right_duty_permille);
        previous = out.left_duty_permille;
    }
    CHECK(out.left_duty_permille > 100);
    return 0;
}

static int test_feedback(void)
{
    remote_speed_control_t ctx;
    remote_speed_output_t out;
    unsigned i;
    remote_speed_control_init(&ctx);
    for (i = 1; i <= 30; ++i)
        remote_speed_control_step(&ctx, 350, 80, 200, i, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
    CHECK(out.left_duty_permille > out.right_duty_permille + 15);
    CHECK(out.left_speed_mm_s == 80 && out.right_speed_mm_s == 200);
    for (; i <= 60; ++i)
        remote_speed_control_step(&ctx, 350, 900, 900, i, &out);
    CHECK(out.left_duty_permille == 0 && out.right_duty_permille == 0);
    CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
    return 0;
}

static int test_reverse(void)
{
    remote_speed_control_t forward, reverse;
    remote_speed_output_t a, b;
    unsigned i;
    remote_speed_control_init(&forward);
    remote_speed_control_init(&reverse);
    for (i = 1; i <= 20; ++i)
    {
        remote_speed_control_step(&forward, 200, 40, 60, i, &a);
        remote_speed_control_step(&reverse, -200, -40, -60, i, &b);
        CHECK(b.fault == REMOTE_SPEED_FAULT_NONE);
        CHECK(b.target_mm_s == -a.target_mm_s);
        CHECK(b.left_duty_permille == a.left_duty_permille);
        CHECK(b.right_duty_permille == a.right_duty_permille);
        CHECK(b.left_speed_mm_s == -40 && b.right_speed_mm_s == -60);
    }
    return 0;
}

static int test_stop_reset(void)
{
    remote_speed_control_t ctx, fresh;
    remote_speed_output_t a, b;
    unsigned i;
    remote_speed_control_init(&ctx);
    for (i = 1; i <= 20; ++i)
        remote_speed_control_step(&ctx, 350, 20, 20, i, &a);
    CHECK(a.left_duty_permille > 0);
    remote_speed_control_step(&ctx, 0, 500, 500, 20, &a);
    CHECK(a.left_duty_permille == 0 && a.right_duty_permille == 0);
    CHECK(a.target_mm_s == 0 && a.fault == REMOTE_SPEED_FAULT_NONE);
    remote_speed_control_init(&fresh);
    remote_speed_control_step(&ctx, 350, 20, 20, 0, &a);
    remote_speed_control_step(&fresh, 350, 20, 20, 0, &b);
    CHECK(a.left_duty_permille == b.left_duty_permille);
    CHECK(a.target_mm_s == 15);
    remote_speed_control_step(&ctx, -200, -20, -20, 1, &a);
    CHECK(a.left_duty_permille == 0 && a.right_duty_permille == 0);
    CHECK(a.target_mm_s == 0 && a.fault == REMOTE_SPEED_FAULT_NONE);
    remote_speed_control_step(&ctx, -200, -20, -20, 2, &a);
    CHECK(a.target_mm_s == -15 && a.left_duty_permille <= 8);
    remote_speed_control_reset(&ctx);
    remote_speed_control_step(&ctx, -200, -20, -20, 2, &a);
    CHECK(a.target_mm_s == -15 && a.left_duty_permille <= 8);
    return 0;
}

static int test_filter(void)
{
    remote_speed_control_t ctx;
    remote_speed_output_t out;
    remote_speed_control_init(&ctx);
    remote_speed_control_step(&ctx, 350, 200, -20, 0, &out);
    CHECK(out.left_speed_mm_s == 200 && out.right_speed_mm_s == -20);
    remote_speed_control_step(&ctx, 350, 0, 80, 1, &out);
    CHECK(out.left_speed_mm_s == 140 && out.right_speed_mm_s == 10);
    remote_speed_control_step(&ctx, 350, 0, 80, 1, &out);
    CHECK(out.left_speed_mm_s == 140 && out.right_speed_mm_s == 10);
    return 0;
}

static int test_stale(void)
{
    remote_speed_control_t ctx;
    remote_speed_output_t out;
    unsigned i;
    remote_speed_control_init(&ctx);
    remote_speed_control_step(&ctx, 350, 20, 20, UINT32_MAX, &out);
    for (i = 0; i < 2; ++i)
    {
        remote_speed_control_step(&ctx, 350, 20, 20, UINT32_MAX, &out);
        CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
    }
    remote_speed_control_step(&ctx, 350, 20, 20, UINT32_MAX, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_STALE);
    CHECK(out.left_duty_permille == 0 && out.right_duty_permille == 0);
    remote_speed_control_step(&ctx, 0, 20, 20, 0, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_STALE);
    remote_speed_control_step(&ctx, 350, 20, 20, 1, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_STALE && out.left_duty_permille == 0);
    remote_speed_control_reset(&ctx);
    remote_speed_control_step(&ctx, 350, 20, 20, UINT32_MAX, &out);
    remote_speed_control_step(&ctx, 350, 20, 20, 0, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_NONE && out.target_mm_s == 30);
    return 0;
}

static int test_overspeed(void)
{
    static const int32_t speeds[] = {1201, -1201, INT32_MAX, INT32_MIN};
    remote_speed_control_t ctx;
    remote_speed_output_t out;
    unsigned i;
    for (i = 0; i < sizeof(speeds) / sizeof(speeds[0]); ++i)
    {
        remote_speed_control_init(&ctx);
        remote_speed_control_step(&ctx, 350, 20, 20, 0, &out);
        remote_speed_control_step(&ctx, 350, 20, speeds[i], 1, &out);
        CHECK(out.fault == REMOTE_SPEED_FAULT_OVERSPEED);
        CHECK(out.left_duty_permille == 0 && out.right_duty_permille == 0);
    }
    remote_speed_control_init(&ctx);
    remote_speed_control_step(&ctx, 350, 1200, 1200, 0, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
    return 0;
}

static int test_direction(void)
{
    remote_speed_control_t ctx;
    remote_speed_output_t out;
    unsigned i;
    remote_speed_control_init(&ctx);
    for (i = 1; i < 8; ++i)
    {
        remote_speed_control_step(&ctx, 350, 100, -31, i, &out);
        CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
    }
    remote_speed_control_step(&ctx, 350, 100, -31, 8, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_DIRECTION);
    CHECK(out.left_duty_permille == 0 && out.right_duty_permille == 0);
    remote_speed_control_reset(&ctx);
    for (i = 1; i <= 20; ++i)
    {
        remote_speed_control_step(&ctx, -200, -100, i % 2 ? 50 : -50, i, &out);
        CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
    }
    remote_speed_control_reset(&ctx);
    for (i = 1; i <= 20; ++i)
    {
        remote_speed_control_step(&ctx, 350, -30, 100, i, &out);
        CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
    }
    return 0;
}

static int test_stall(void)
{
    remote_speed_control_t ctx;
    remote_speed_output_t out;
    unsigned i;
    remote_speed_control_init(&ctx);
    for (i = 1; i < 20; ++i)
    {
        remote_speed_control_step(&ctx, 350, 50, 0, i, &out);
        CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
    }
    for (; i <= 29; ++i)
    {
        remote_speed_control_step(&ctx, 350, 50, 0, i, &out);
        if (out.fault) break;
    }
    CHECK(out.fault == REMOTE_SPEED_FAULT_STALL && i <= 29);
    CHECK(out.left_duty_permille == 0 && out.right_duty_permille == 0);
    remote_speed_control_reset(&ctx);
    for (i = 1; i <= 120; ++i)
    {
        remote_speed_control_step(&ctx, 350, 50, i % 15 ? 0 : 10, i, &out);
        CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
    }
    remote_speed_control_reset(&ctx);
    for (i = 1; i <= 40; ++i)
    {
        remote_speed_control_step(&ctx, 70, 0, 0, i, &out);
        CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
    }
    return 0;
}

static int test_saturation(void)
{
    remote_speed_control_t ctx;
    remote_speed_output_t out;
    unsigned i;
    remote_speed_control_init(&ctx);
    for (i = 1; i <= 500; ++i)
    {
        remote_speed_control_step(&ctx, INT16_MAX, 20, 20, i, &out);
        CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
        CHECK(out.target_mm_s <= 350 && out.left_duty_permille <= 200);
        CHECK(isfinite(ctx.left_pid.integral) && fabsf(ctx.left_pid.integral) <= 80.0f);
    }
    CHECK(out.left_duty_permille == 200);
    remote_speed_control_reset(&ctx);
    for (i = 1; i <= 30; ++i)
        remote_speed_control_step(&ctx, INT16_MIN, -20, -20, i, &out);
    CHECK(out.target_mm_s == -200 && out.fault == REMOTE_SPEED_FAULT_NONE);
    return 0;
}

static int test_invalid_runtime(void)
{
    remote_speed_control_t ctx;
    remote_speed_output_t out;
    memset(&ctx, 0, sizeof(ctx));
    remote_speed_control_step(&ctx, 350, 20, 20, 1, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_CONFIG && out.left_duty_permille == 0);
    remote_speed_control_init(&ctx);
    ctx.left_pid.config.kp = NAN;
    remote_speed_control_step(&ctx, 350, 20, 20, 2, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_CONFIG && out.right_duty_permille == 0);
    remote_speed_control_reset(&ctx);
    remote_speed_control_step(&ctx, 350, 20, 20, 3, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_NONE);
    ctx.right_pid.integral = INFINITY;
    remote_speed_control_step(&ctx, 350, 20, 20, 4, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_CONFIG && out.left_duty_permille == 0);
    remote_speed_control_init(NULL);
    remote_speed_control_reset(NULL);
    remote_speed_control_step(NULL, 350, 20, 20, 1, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_CONFIG && out.left_duty_permille == 0);
    remote_speed_control_step(&ctx, 350, 20, 20, 1, NULL);
    return 0;
}

static int test_invalid_config(void)
{
    remote_speed_control_t ctx;
    remote_speed_output_t out;
    remote_speed_control_init(&ctx);
    remote_speed_control_step(&ctx, 350, 20, 20, 1, &out);
    CHECK(out.fault == REMOTE_SPEED_FAULT_CONFIG);
    CHECK(out.left_duty_permille == 0 && out.right_duty_permille == 0);
    return 0;
}

int main(int argc, char **argv)
{
    static const struct { const char *name; int (*run)(void); } cases[] = {
        {"ramp", test_ramp}, {"feedback", test_feedback},
        {"reverse", test_reverse}, {"stop-reset", test_stop_reset},
        {"filter", test_filter}, {"stale", test_stale},
        {"overspeed", test_overspeed}, {"direction", test_direction},
        {"stall", test_stall}, {"saturation", test_saturation},
        {"invalid-runtime", test_invalid_runtime}, {"invalid-config", test_invalid_config}
    };
    unsigned i;
    if (argc != 2) return 2;
    for (i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i)
        if (strcmp(argv[1], cases[i].name) == 0) return cases[i].run();
    return 2;
}
