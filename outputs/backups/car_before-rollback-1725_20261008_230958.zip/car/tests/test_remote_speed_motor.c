/* 真实遥控后端与闭环模块联合验证，桩仅替换GPIO/PWM及编码器采样。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "motor_test_platform.h"
#include "motor_control.h"
#include "encoder_feedback.h"
static uint8_t start_key=1,stop_key=1;
static uint32_t m1,m2,mask;
static encoder_feedback_snapshot_t feedback;
static unsigned checks;
#define CHECK(c) do {++checks;if(!(c)){printf("FAIL line %d: %s\n",__LINE__,#c);exit(1);}}while(0)
void gpio_init(gpio_pin_enum p,gpio_dir_enum d,uint8_t l,uint32_t m){(void)p;(void)d;(void)l;(void)m;}
uint8_t gpio_get_level(gpio_pin_enum p){return p==C12?start_key:stop_key;}
void gpio_set_level(gpio_pin_enum p,uint8_t l){(void)p;(void)l;CHECK(m1==0 && m2==0);}
void pwm_init(pwm_channel_enum c,uint32_t f,uint32_t d){(void)f;if(c==PWM2_MODULE1_CHA_C8)m1=d;else m2=d;}
void pwm_set_duty(pwm_channel_enum c,uint32_t d){if(c==PWM2_MODULE1_CHA_C8)m1=d;else m2=d;}
uint32_t __get_PRIMASK(void){return mask;}void __disable_irq(void){mask=1;}void __set_PRIMASK(uint32_t m){mask=m;}
void encoder_feedback_reset_totals(void){}
void encoder_feedback_get_snapshot(encoder_feedback_snapshot_t *p){*p=feedback;}
static void tick(unsigned n,int update)
{
    while(n--){if(update)++feedback.sample_sequence;motor_control_tick_10ms();CHECK(m1<=2000 && m2<=2000);}
}
static motor_control_status_t status(void){motor_control_status_t s;motor_control_get_status(&s);return s;}
static void reset_arm(void)
{
    start_key=1;stop_key=1;memset(&feedback,0,sizeof feedback);feedback.left.speed_mm_s=100;feedback.right.speed_mm_s=200;
    motor_control_init();motor_control_enable_test();motor_control_remote_set_link(1);tick(6,1);
    start_key=0;tick(4,1);start_key=1;tick(4,1);CHECK(status().remote_wait_neutral);
    motor_control_submit_remote(0,1);tick(1,1);CHECK(status().remote_armed && !status().remote_wait_neutral);
}
int main(void)
{
    reset_arm();motor_control_submit_remote(100,0);tick(20,1);
    CHECK(m1>m2);CHECK(m1>1000); /* 慢左轮得到更多PWM，新上限允许超过旧10%。 */
    tick(11,1);CHECK(m1==0 && m2==0 && status().state==MOTOR_REMOTE_TIMEOUT);
    motor_control_submit_remote(100,0);tick(5,1);CHECK(m1>0);
    stop_key=0;tick(1,1);CHECK(m1==0 && m2==0 && !status().remote_armed);
    stop_key=1;motor_control_submit_remote(100,0);tick(5,1);CHECK(m1==0 && m2==0);
    reset_arm();motor_control_submit_remote(100,0);tick(8,1);tick(5,0);
    CHECK(m1==0 && m2==0 && !status().remote_armed);
    reset_arm();feedback.left.speed_mm_s=-100;motor_control_submit_remote(100,0);tick(12,1);
    CHECK(m1==0 && m2==0 && !status().remote_armed);
    reset_arm();feedback.right.speed_mm_s=1500;motor_control_submit_remote(100,0);tick(1,1);
    CHECK(m1==0 && m2==0 && !status().remote_armed);
    reset_arm();motor_control_submit_remote(100,0);tick(10,1);
    motor_control_submit_remote(-100,0);tick(1,1);CHECK(m1==0 && m2==0);
    tick(12,1);CHECK(m1==0 && m2==0 && status().state==MOTOR_REMOTE_REVERSING);
    feedback.left.speed_mm_s=feedback.right.speed_mm_s=0;
    tick(2,1);
    feedback.left.speed_mm_s=-100;feedback.right.speed_mm_s=-80;tick(10,1);
    CHECK(status().applied_permille<0 && m1>0 && m2>0);
    motor_control_remote_set_link(0);tick(1,1);CHECK(m1==0 && m2==0 && !status().remote_armed);
    reset_arm();motor_control_submit_remote(100,0);tick(10,1);
    feedback.left.speed_mm_s=feedback.right.speed_mm_s=0;
    motor_control_submit_remote(-100,0);tick(1,1);tick(4,0);
    CHECK(m1==0 && m2==0 && !status().remote_armed);
    reset_arm();tick(5,0);motor_control_submit_remote(100,0);tick(1,0);
    CHECK(m1==0 && m2==0 && !status().remote_armed);
    reset_arm();motor_control_submit_remote(100,0);tick(10,1);
    motor_control_autonomous_set(1,50,70);tick(1,1);
    CHECK(m1==500 && m2==700 && status().autonomous_active && !status().remote_armed);
    motor_control_autonomous_set(0,0,0);tick(1,1);CHECK(m1==0 && m2==0);
    printf("%u closed-loop remote motor checks passed\n",checks);return 0;
}
