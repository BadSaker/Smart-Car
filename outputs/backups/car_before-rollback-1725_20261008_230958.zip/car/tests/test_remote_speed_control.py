"""编译真实手柄速度内核与PID，验证轮速闭环、状态清理和故障边界。"""
from pathlib import Path
import os
import subprocess
import unittest


ROOT = Path(__file__).resolve().parents[2]
SCRATCH = ROOT / "tmp/remote-speed/kernel"
COMPILER = os.environ.get(
    "AUTOCAR_HOST_CC",
    r"D:\Xilinx\Vivado\2022.2\tps\mingw\6.2.0\win64.o\nt\bin\gcc.exe",
)


class RemoteSpeedControlTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        SCRATCH.mkdir(parents=True, exist_ok=True)
        cls.environment = os.environ.copy()
        cls.environment["PATH"] = str(Path(COMPILER).parent) + os.pathsep + cls.environment["PATH"]
        cls.executable = cls.compile_case("default")

    @classmethod
    def compile_case(cls, name, definitions=()):
        executable = SCRATCH / ("test-remote-speed-" + name + ".exe")
        command = [
            COMPILER, "-std=c99", "-Wall", "-Wextra", "-Werror", "-pedantic", "-O2",
            "-I" + str(ROOT / "car/include"), "-I" + str(ROOT / "car/config"),
            *["-D" + definition for definition in definitions],
            str(ROOT / "car/tests/test_remote_speed_control.c"),
            str(ROOT / "car/src/remote_speed_control.c"),
            str(ROOT / "car/src/control_pid.c"), "-lm", "-o", str(executable),
        ]
        result = subprocess.run(command, capture_output=True, text=True,
                                encoding="utf-8", errors="replace", env=cls.environment)
        if result.returncode:
            raise AssertionError(result.stdout + result.stderr)
        return executable

    def run_case(self, name, executable=None):
        result = subprocess.run([str(executable or self.executable), name],
                                capture_output=True, text=True, encoding="utf-8",
                                errors="replace", env=self.environment)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_target_and_pwm_rise_are_limited(self):
        self.run_case("ramp")

    def test_wheels_close_their_own_feedback_loops(self):
        self.run_case("feedback")

    def test_reverse_uses_command_relative_speed(self):
        self.run_case("reverse")

    def test_stop_reset_and_direction_change_clear_history(self):
        self.run_case("stop-reset")

    def test_filter_seeds_from_first_sample_and_only_updates_on_fresh_data(self):
        self.run_case("filter")

    def test_stale_feedback_latches_until_explicit_reset_and_allows_sequence_wrap(self):
        self.run_case("stale")

    def test_raw_overspeed_stops_before_filtering(self):
        self.run_case("overspeed")

    def test_wrong_direction_requires_continuous_eighty_milliseconds(self):
        self.run_case("direction")

    def test_single_wheel_stall_stops_within_remote_lease(self):
        self.run_case("stall")

    def test_input_pwm_and_integral_limits_hold_over_long_run(self):
        self.run_case("saturation")

    def test_invalid_runtime_state_returns_safe_zero(self):
        self.run_case("invalid-runtime")

    def test_unsigned_threshold_constants_preserve_signed_wheel_checks(self):
        executable = self.compile_case("unsigned-thresholds", (
            "REMOTE_SPEED_OVERSPEED_MM_S=1200U", "REMOTE_SPEED_DIRECTION_MM_S=30U",
        ))
        self.run_case("reverse", executable)
        self.run_case("direction", executable)

    def test_invalid_compile_time_configurations_return_safe_zero(self):
        cases = (
            "REMOTE_SPEED_KP=NAN", "REMOTE_SPEED_KI=INFINITY",
            "REMOTE_SPEED_KD=-1.0f", "REMOTE_SPEED_FEEDFORWARD=-1.0f",
            "REMOTE_SPEED_MAX_DUTY_PERMILLE=0", "REMOTE_SPEED_MAX_DUTY_PERMILLE=1001",
            "REMOTE_SPEED_ACCEL_MM_S2=0.0f", "REMOTE_SPEED_DUTY_STEP_PERMILLE=0",
            "REMOTE_SPEED_FILTER_ALPHA=0.0f", "REMOTE_SPEED_FILTER_ALPHA=1.01f",
            "REMOTE_SPEED_INTEGRAL_LIMIT_PERMILLE=-1.0f", "REMOTE_SPEED_FORWARD_MM_S=0",
            "REMOTE_SPEED_REVERSE_MM_S=32768", "REMOTE_SPEED_OVERSPEED_MM_S=0",
            "REMOTE_SPEED_STALE_MS=0", "REMOTE_SPEED_DIRECTION_MS=0",
            "REMOTE_SPEED_STALL_MS=0",
        )
        for index, definition in enumerate(cases):
            with self.subTest(configuration=definition):
                executable = self.compile_case("invalid-" + str(index), (definition,))
                self.run_case("invalid-config", executable)


if __name__ == "__main__":
    unittest.main(verbosity=2)
