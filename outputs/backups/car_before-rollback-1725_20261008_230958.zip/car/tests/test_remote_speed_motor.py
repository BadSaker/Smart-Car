"""闭环默认配置的真实电机后端联合回归，旧开环门控由原测试保留。"""
from pathlib import Path
import subprocess,unittest
from test_motor_control import COMPILER,PLATFORM
ROOT=Path(__file__).resolve().parents[2]
SCRATCH=ROOT/"tmp/remote-speed/motor-tests"
class RemoteSpeedMotorTests(unittest.TestCase):
    def test_default_closed_loop(self):
        SCRATCH.mkdir(parents=True,exist_ok=True)
        (SCRATCH/"motor_test_platform.h").write_text(PLATFORM,encoding="ascii")
        for name in ["zf_driver_gpio.h","zf_driver_pwm.h"]:
            (SCRATCH/name).write_text('#include "motor_test_platform.h"\n',encoding="ascii")
        exe=SCRATCH/"remote-speed-motor.exe"
        cmd=[COMPILER,"-std=c99","-Wall","-Wextra","-Werror","-O2","-I"+str(SCRATCH),"-I"+str(ROOT/"car/include"),"-I"+str(ROOT/"car/config"),str(ROOT/"car/tests/test_remote_speed_motor.c")]
        cmd += [str(ROOT/"car/src"/name) for name in ["motor_control.c","remote_speed_control.c","control_pid.c"]]+["-lm","-o",str(exe)]
        r=subprocess.run(cmd,capture_output=True,text=True,encoding="utf8",errors="replace");self.assertEqual(r.returncode,0,r.stdout+r.stderr)
        r=subprocess.run([str(exe)],capture_output=True,text=True,encoding="utf8",errors="replace");self.assertEqual(r.returncode,0,r.stdout+r.stderr);print(r.stdout.strip())
if __name__=="__main__":unittest.main(verbosity=2)
