#ifndef AUTOCAR_REMOTE_SPEED_CONTROL_H
#define AUTOCAR_REMOTE_SPEED_CONTROL_H

#include "control_pid.h"
#include <stdint.h>

typedef enum
{
    REMOTE_SPEED_FAULT_NONE = 0,
    REMOTE_SPEED_FAULT_CONFIG,
    REMOTE_SPEED_FAULT_STALE,
    REMOTE_SPEED_FAULT_DIRECTION,
    REMOTE_SPEED_FAULT_OVERSPEED,
    REMOTE_SPEED_FAULT_STALL
} remote_speed_fault_t;

typedef struct
{
    uint16_t left_duty_permille;  /* 正PWM幅度0..配置上限，DIR由后端处理。 */
    uint16_t right_duty_permille;
    int16_t target_mm_s;         /* 斜坡后的目标；前进为正，后退为负。 */
    int32_t left_speed_mm_s;     /* 滤波后轮速，始终前进为正，向0取整。 */
    int32_t right_speed_mm_s;
    uint8_t fault;               /* remote_speed_fault_t；故障输出两路0。 */
} remote_speed_output_t;

/* 仅由模块写入，单一PIT上下文持有；无堆与硬件访问，不得并发调用。
 * PID的输入为相对命令方向的速度幅度，输出及积分单位为PWM千分比。 */
typedef struct
{
    control_pid_t left_pid;
    control_pid_t right_pid;
    float target_magnitude_mm_s;
    float left_filtered_mm_s;
    float right_filtered_mm_s;
    uint32_t feedback_sequence;
    uint16_t stale_ms;
    uint16_t left_direction_ms;
    uint16_t right_direction_ms;
    uint16_t left_stall_ms;
    uint16_t right_stall_ms;
    uint16_t left_duty_permille;
    uint16_t right_duty_permille;
    int8_t direction;
    uint8_t has_feedback;
    uint8_t initialized;
    uint8_t fault;
} remote_speed_control_t;

/* 从remote_speed_config.h装载参数并清全部状态；非法配置锁存CONFIG。
 * reset同样重新装载参数，清PID/滤波/斜坡/反馈计时及故障；NULL无操作。
 * 停车、模式切换及后端换DIR前应调用reset。故障须由上层撤销遥控允许，
 * 完成C12+Down重新允许后才能恢复；本接口不承担武装与租约管理。 */
void remote_speed_control_init(remote_speed_control_t *ctx);
void remote_speed_control_reset(remote_speed_control_t *ctx);

/* 必须每10 ms调用一次；速度输入单位mm/s，先由调用者统一为前进正号。
 * signed_target_mm_s正前负后，并按配置前/后限速。左右同目标独立PID。
 * 首个反馈sequence（包括0）建立基线，首个原始样本直接初始化滤波；
 * 后续仅sequence变化时更新滤波，uint32_t回绕合法；相同sequence累计
 * 到配置时限停机。原始轮速检查超速、持续反向及堵转，不被滤波延迟。
 * 0目标立即清动态状态、两路归零，保留既有故障锁存；显式reset清故障。
 * 未reset而直接改变目标符号时，本拍清状态归零，下拍从0重新爬升；
 * 后端仍须自行执行机械换向等待。故障锁存到reset/init且总输出为0。
 * 非有限参数/状态或非法配置返回CONFIG；out为NULL时无操作，ctx为NULL
 * 时输出CONFIG。不要以fast-math或有限数学假设编译本模块及PID。 */
void remote_speed_control_step(remote_speed_control_t *ctx,
                               int16_t signed_target_mm_s,
                               int32_t left_forward_mm_s,
                               int32_t right_forward_mm_s,
                               uint32_t feedback_sequence,
                               remote_speed_output_t *out);

#endif
