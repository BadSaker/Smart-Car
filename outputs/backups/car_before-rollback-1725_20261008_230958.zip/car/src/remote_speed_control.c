#include "remote_speed_control.h"
#include "remote_speed_config.h"
#include <math.h>
#include <stddef.h>
#include <string.h>

static uint8_t finite_range(float value, float minimum, float maximum)
{
    return (uint8_t)(isfinite(value) && value >= minimum && value <= maximum);
}

static uint8_t integer_range(float value, float minimum, float maximum)
{
    return (uint8_t)(finite_range(value, minimum, maximum) &&
                     value == (float)(uint16_t)value);
}

static uint8_t config_is_valid(void)
{
    return (uint8_t)(
        integer_range(REMOTE_SPEED_FORWARD_MM_S, 1.0f, 32767.0f) &&
        integer_range(REMOTE_SPEED_REVERSE_MM_S, 1.0f, 32767.0f) &&
        integer_range(REMOTE_SPEED_MAX_DUTY_PERMILLE, 1.0f, 1000.0f) &&
        finite_range(REMOTE_SPEED_ACCEL_MM_S2, 0.001f, 3276700.0f) &&
        integer_range(REMOTE_SPEED_DUTY_STEP_PERMILLE, 1.0f,
                      REMOTE_SPEED_MAX_DUTY_PERMILLE) &&
        isfinite(REMOTE_SPEED_KP) && REMOTE_SPEED_KP >= 0.0f &&
        isfinite(REMOTE_SPEED_KI) && REMOTE_SPEED_KI >= 0.0f &&
        isfinite(REMOTE_SPEED_KD) && REMOTE_SPEED_KD >= 0.0f &&
        isfinite(REMOTE_SPEED_FEEDFORWARD) && REMOTE_SPEED_FEEDFORWARD >= 0.0f &&
        finite_range(REMOTE_SPEED_INTEGRAL_LIMIT_PERMILLE, 0.0f,
                     REMOTE_SPEED_MAX_DUTY_PERMILLE) &&
        finite_range(REMOTE_SPEED_FILTER_ALPHA, 0.000001f, 1.0f) &&
        integer_range(REMOTE_SPEED_STALE_MS, 1.0f, 65535.0f) &&
        integer_range(REMOTE_SPEED_OVERSPEED_MM_S, 1.0f, 32767.0f) &&
        REMOTE_SPEED_FORWARD_MM_S <= REMOTE_SPEED_OVERSPEED_MM_S &&
        REMOTE_SPEED_REVERSE_MM_S <= REMOTE_SPEED_OVERSPEED_MM_S &&
        integer_range(REMOTE_SPEED_DIRECTION_MM_S, 0.0f,
                      REMOTE_SPEED_OVERSPEED_MM_S) &&
        integer_range(REMOTE_SPEED_DIRECTION_MS, 1.0f, 65535.0f) &&
        integer_range(REMOTE_SPEED_STALL_TARGET_MM_S, 1.0f, 32767.0f) &&
        integer_range(REMOTE_SPEED_STALL_DUTY_PERMILLE, 1.0f,
                      REMOTE_SPEED_MAX_DUTY_PERMILLE) &&
        integer_range(REMOTE_SPEED_STALL_SPEED_MM_S, 1.0f,
                      REMOTE_SPEED_OVERSPEED_MM_S) &&
        integer_range(REMOTE_SPEED_STALL_MS, 1.0f, 65535.0f));
}

static void clear_dynamic_state(remote_speed_control_t *ctx)
{
    control_pid_reset(&ctx->left_pid);
    control_pid_reset(&ctx->right_pid);
    ctx->target_magnitude_mm_s = 0.0f;
    ctx->left_filtered_mm_s = 0.0f;
    ctx->right_filtered_mm_s = 0.0f;
    ctx->feedback_sequence = 0U;
    ctx->stale_ms = 0U;
    ctx->left_direction_ms = 0U;
    ctx->right_direction_ms = 0U;
    ctx->left_stall_ms = 0U;
    ctx->right_stall_ms = 0U;
    ctx->left_duty_permille = 0U;
    ctx->right_duty_permille = 0U;
    ctx->direction = 0;
    ctx->has_feedback = 0U;
}

static void latch_fault(remote_speed_control_t *ctx, uint8_t fault,
                        remote_speed_output_t *out)
{
    clear_dynamic_state(ctx);
    ctx->fault = fault;
    memset(out, 0, sizeof(*out));
    out->fault = fault;
}

static uint16_t elapsed_ms(uint16_t previous, uint8_t condition)
{
    uint32_t next;
    if (!condition) return 0U;
    next = (uint32_t)previous + REMOTE_SPEED_PERIOD_MS;
    return (uint16_t)(next < 65535U ? next : 65535U);
}

static uint8_t timeout_reached(uint16_t elapsed, uint32_t threshold)
{
    return (uint8_t)((uint32_t)elapsed >= threshold);
}

static uint16_t limit_duty_rise(float duty, uint16_t previous)
{
    float ceiling = (float)previous + REMOTE_SPEED_DUTY_STEP_PERMILLE;
    if (duty > ceiling) duty = ceiling;
    if (duty > REMOTE_SPEED_MAX_DUTY_PERMILLE) duty = REMOTE_SPEED_MAX_DUTY_PERMILLE;
    if (duty < 0.0f) duty = 0.0f;
    return (uint16_t)duty;
}

void remote_speed_control_init(remote_speed_control_t *ctx)
{
    control_pid_config_t config;
    if (ctx == NULL) return;
    memset(ctx, 0, sizeof(*ctx));
    if (!config_is_valid())
    {
        ctx->fault = REMOTE_SPEED_FAULT_CONFIG;
        return;
    }
    config.kp = REMOTE_SPEED_KP;
    config.ki = REMOTE_SPEED_KI;
    config.kd = REMOTE_SPEED_KD;
    config.output_min = 0.0f;
    config.output_max = REMOTE_SPEED_MAX_DUTY_PERMILLE;
    config.integral_limit = REMOTE_SPEED_INTEGRAL_LIMIT_PERMILLE;
    config.derivative_tau_s = 0.0f;
    ctx->initialized = (uint8_t)(control_pid_init(&ctx->left_pid, &config) &&
                                 control_pid_init(&ctx->right_pid, &config));
    if (!ctx->initialized) ctx->fault = REMOTE_SPEED_FAULT_CONFIG;
}

void remote_speed_control_reset(remote_speed_control_t *ctx)
{
    remote_speed_control_init(ctx);
}

void remote_speed_control_step(remote_speed_control_t *ctx,
                               int16_t signed_target_mm_s,
                               int32_t left_forward_mm_s,
                               int32_t right_forward_mm_s,
                               uint32_t feedback_sequence,
                               remote_speed_output_t *out)
{
    const float dt_s = (float)REMOTE_SPEED_PERIOD_MS * 0.001f;
    const float target_step = REMOTE_SPEED_ACCEL_MM_S2 * dt_s;
    float requested_magnitude;
    float left_relative_mm_s;
    float right_relative_mm_s;
    float left_duty;
    float right_duty;
    int8_t direction;
    if (out == NULL) return;
    memset(out, 0, sizeof(*out));
    if (ctx == NULL)
    {
        out->fault = REMOTE_SPEED_FAULT_CONFIG;
        return;
    }
    if (ctx->fault != REMOTE_SPEED_FAULT_NONE)
    {
        out->fault = ctx->fault;
        return;
    }
    if (!ctx->initialized || !config_is_valid() ||
        !finite_range(ctx->target_magnitude_mm_s, 0.0f, 32767.0f) ||
        !finite_range(ctx->left_filtered_mm_s, -(float)REMOTE_SPEED_OVERSPEED_MM_S,
                       REMOTE_SPEED_OVERSPEED_MM_S) ||
        !finite_range(ctx->right_filtered_mm_s, -(float)REMOTE_SPEED_OVERSPEED_MM_S,
                       REMOTE_SPEED_OVERSPEED_MM_S))
    {
        latch_fault(ctx, REMOTE_SPEED_FAULT_CONFIG, out);
        return;
    }
    if (signed_target_mm_s == 0)
    {
        clear_dynamic_state(ctx);
        return;
    }
    direction = signed_target_mm_s > 0 ? 1 : -1;
    if (ctx->direction != 0 && direction != ctx->direction)
    {
        /* 软件防止跨方向携带积分；机械停转等待由后端单独保证。 */
        clear_dynamic_state(ctx);
        return;
    }
    ctx->direction = direction;
    if (fabsf((float)left_forward_mm_s) > REMOTE_SPEED_OVERSPEED_MM_S ||
        fabsf((float)right_forward_mm_s) > REMOTE_SPEED_OVERSPEED_MM_S)
    {
        latch_fault(ctx, REMOTE_SPEED_FAULT_OVERSPEED, out);
        return;
    }
    if (!ctx->has_feedback)
    {
        ctx->left_filtered_mm_s = (float)left_forward_mm_s;
        ctx->right_filtered_mm_s = (float)right_forward_mm_s;
        ctx->feedback_sequence = feedback_sequence;
        ctx->has_feedback = 1U;
    }
    else if (ctx->feedback_sequence != feedback_sequence)
    {
        ctx->left_filtered_mm_s += REMOTE_SPEED_FILTER_ALPHA *
            ((float)left_forward_mm_s - ctx->left_filtered_mm_s);
        ctx->right_filtered_mm_s += REMOTE_SPEED_FILTER_ALPHA *
            ((float)right_forward_mm_s - ctx->right_filtered_mm_s);
        ctx->feedback_sequence = feedback_sequence;
        ctx->stale_ms = 0U;
    }
    else
    {
        ctx->stale_ms = elapsed_ms(ctx->stale_ms, 1U);
        if (timeout_reached(ctx->stale_ms, REMOTE_SPEED_STALE_MS))
        {
            latch_fault(ctx, REMOTE_SPEED_FAULT_STALE, out);
            return;
        }
    }
    left_relative_mm_s = (float)direction * (float)left_forward_mm_s;
    right_relative_mm_s = (float)direction * (float)right_forward_mm_s;
    ctx->left_direction_ms = elapsed_ms(ctx->left_direction_ms,
        (uint8_t)(left_relative_mm_s < -(float)REMOTE_SPEED_DIRECTION_MM_S));
    ctx->right_direction_ms = elapsed_ms(ctx->right_direction_ms,
        (uint8_t)(right_relative_mm_s < -(float)REMOTE_SPEED_DIRECTION_MM_S));
    if (timeout_reached(ctx->left_direction_ms, REMOTE_SPEED_DIRECTION_MS) ||
        timeout_reached(ctx->right_direction_ms, REMOTE_SPEED_DIRECTION_MS))
    {
        latch_fault(ctx, REMOTE_SPEED_FAULT_DIRECTION, out);
        return;
    }
    requested_magnitude = fabsf((float)signed_target_mm_s);
    if (direction > 0 && requested_magnitude > REMOTE_SPEED_FORWARD_MM_S)
        requested_magnitude = REMOTE_SPEED_FORWARD_MM_S;
    if (direction < 0 && requested_magnitude > REMOTE_SPEED_REVERSE_MM_S)
        requested_magnitude = REMOTE_SPEED_REVERSE_MM_S;
    if (requested_magnitude > ctx->target_magnitude_mm_s + target_step)
        ctx->target_magnitude_mm_s += target_step;
    else if (requested_magnitude < ctx->target_magnitude_mm_s - target_step)
        ctx->target_magnitude_mm_s -= target_step;
    else
        ctx->target_magnitude_mm_s = requested_magnitude;

    left_duty = control_pid_step(&ctx->left_pid, ctx->target_magnitude_mm_s,
        (float)direction * ctx->left_filtered_mm_s,
        REMOTE_SPEED_FEEDFORWARD * ctx->target_magnitude_mm_s, dt_s);
    right_duty = control_pid_step(&ctx->right_pid, ctx->target_magnitude_mm_s,
        (float)direction * ctx->right_filtered_mm_s,
        REMOTE_SPEED_FEEDFORWARD * ctx->target_magnitude_mm_s, dt_s);
    if (!ctx->left_pid.valid || !ctx->right_pid.valid ||
        !isfinite(left_duty) || !isfinite(right_duty))
    {
        latch_fault(ctx, REMOTE_SPEED_FAULT_CONFIG, out);
        return;
    }
    ctx->left_duty_permille = limit_duty_rise(left_duty, ctx->left_duty_permille);
    ctx->right_duty_permille = limit_duty_rise(right_duty, ctx->right_duty_permille);
    ctx->left_stall_ms = elapsed_ms(ctx->left_stall_ms,
        (uint8_t)(ctx->target_magnitude_mm_s >= REMOTE_SPEED_STALL_TARGET_MM_S &&
                   ctx->left_duty_permille >= REMOTE_SPEED_STALL_DUTY_PERMILLE &&
                   fabsf((float)left_forward_mm_s) < REMOTE_SPEED_STALL_SPEED_MM_S));
    ctx->right_stall_ms = elapsed_ms(ctx->right_stall_ms,
        (uint8_t)(ctx->target_magnitude_mm_s >= REMOTE_SPEED_STALL_TARGET_MM_S &&
                   ctx->right_duty_permille >= REMOTE_SPEED_STALL_DUTY_PERMILLE &&
                   fabsf((float)right_forward_mm_s) < REMOTE_SPEED_STALL_SPEED_MM_S));
    if (timeout_reached(ctx->left_stall_ms, REMOTE_SPEED_STALL_MS) ||
        timeout_reached(ctx->right_stall_ms, REMOTE_SPEED_STALL_MS))
    {
        latch_fault(ctx, REMOTE_SPEED_FAULT_STALL, out);
        return;
    }
    out->left_duty_permille = ctx->left_duty_permille;
    out->right_duty_permille = ctx->right_duty_permille;
    out->target_mm_s = (int16_t)((float)direction * ctx->target_magnitude_mm_s);
    out->left_speed_mm_s = (int32_t)ctx->left_filtered_mm_s;
    out->right_speed_mm_s = (int32_t)ctx->right_filtered_mm_s;
}
