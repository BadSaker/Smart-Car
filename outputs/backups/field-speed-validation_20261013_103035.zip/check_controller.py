from pathlib import Path
import subprocess
root = Path.cwd()
scratch = root/'tmp/field-speed-20261013'
source = (root/'car/tests/test_autonomous_drive.c').read_bytes()
old = b'        tick(60,1,1,1);'
assert source.count(old) == 1
new = b'        tick((unsigned)(AUTO_CURVE_OUTER_SPEED_MM_S/(AUTO_ACCEL_MM_S2*0.01f))+5U,1,1,1);'
source = source.replace(old, new)
probe = b'''    /* Check straight target and Q=65/64 speed-cap transition after ramp settles. */
    reset();start();tick(200,1,1,1);
    CHECK(car.status.target_speed_mm_s==AUTO_CRUISE_SPEED_MM_S);
    in.confidence=64;tick(2,1,1,1);
    CHECK(car.status.target_speed_mm_s==AUTO_ELEMENT_SPEED_MM_S);
    in.confidence=65;tick(200,1,1,1);
    CHECK(car.status.target_speed_mm_s==AUTO_CRUISE_SPEED_MM_S);
    in.vision_valid=0;tick(1,1,1,1);
    CHECK(car.status.left_duty_permille==0 && car.status.right_duty_permille==0);
'''
assert source.count(b'    test_outer_quality();') == 1
source = source.replace(b'    test_outer_quality();', probe+b'    test_outer_quality();')
test = scratch/'test_autonomous_drive.c'
test.write_bytes(source)
exe = scratch/'controller.exe'
compiler = r'E:\Xilinx\Vivado\2022.2\tps\mingw\6.2.0\win64.o\nt\bin\gcc.exe'
cmd = [compiler,'-std=c99','-Wall','-Wextra','-Werror','-O2','-I'+str(root/'car/include'),'-I'+str(root/'car/config'),str(test),str(root/'car/src/autonomous_drive.c'),str(root/'car/src/control_pid.c'),'-lm','-o',str(exe)]
subprocess.run(cmd, check=True)
subprocess.run([str(exe)], check=True)
