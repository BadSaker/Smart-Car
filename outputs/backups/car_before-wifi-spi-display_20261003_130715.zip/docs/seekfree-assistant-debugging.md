# 逐飞助手摄像头可视化调试

更新日期：2026-10-01。适用软件为逐飞助手 **V1.2.7**，随软件提供的说明书版本为 **V1.4**。用户已确认MT9V034摄像头装好，逐飞官方双模DAP接入电脑后出现 **COM7**；主板/核心板的具体版本、串口跳线连通性仍需实物核对。

**当前排查状态：用户报告COM7原始接收计数为0，工程已暂设 `CAMERA_DIAGNOSTIC_MODE=1`（串口心跳诊断）。本轮 `autocar` 固件只发文本，不发图像。先按下文“零接收诊断”操作；恢复图传需要改回0并重新编译下载。根因尚未由实物观测确认。**

## 零接收诊断

图像页面的FPS/字节率为0只能说明没有正常图像更新，应同时看“串口助手”原始接收计数。用户已确认后者也为0，排查重点先放在程序运行及UART到PC链路，不能仅凭摄像头背面红灯判断采集正常或损坏。当前主板只接核心板和摄像头，无电机/编码器并不会自动导致串口零接收。

最新反馈：用户报告核心板灯闪烁，但串口未收到心跳。若观察的是当前模式1的B9/IO灯且按500ms节奏持续翻转，说明心跳循环持续执行、发送调用可以返回；尚不能证明B12引脚的电气信号到达DAP。当前优先核对B12→J2→下载口/排线→DAP RX→COM7通路，保持模式1，不再以摄像头初始化阻塞解释这一现象。用户尚未说明本次是否已经改用外部供电；不得将供电问题记为已排除。

用户随后确认目前只有USB供电、没有接入电池。指定例程 `main.c` 第50行提醒使用电源供电，并指出下载器供电会导致模块电压不足，第64行也提醒避免供电不足。**先验证供电：** 断电后，按实际主板的额定输入电压、极性和电源接口接入匹配的电池或稳压电源，DAP USB用于下载和通信。不要按芯片型号猜测主板输入电压，也不要把电池直接接到摄像头3V3接口。当前没有测得实际电压，仍须通过外部供电后的对照结果确认是否为故障原因。

配置入口：[camera_debug_config.h](../car/config/camera_debug_config.h)。诊断实现：[camera_diagnostics.c](../car/src/camera_diagnostics.c)。

| `CAMERA_DIAGNOSTIC_MODE` | 用途 | 上位机页面 |
| ---: | --- | --- |
| 1（当前） | 仅UART1文本心跳和核心板B9/IO灯；不调用摄像头、编码器、电机、舵机或应用PIT初始化 | 串口助手 |
| 2 | 摄像头初始化过程、CSI中断次数和观察到的完成帧次数；不运行车辆控制、不发送图像包 | 串口助手 |
| 0 | 恢复原来的图像处理及可视化调试流程 | 图像传输（图传启用时） |

两个诊断模式固定使用UART1、B12/B13、115200、8N1，直接调用 `uart_write_string`，不依赖 `printf/fputc` 串口重定向。`snprintf`只在RAM中组织文字。诊断模式优先于图传开关。

### 先验证串口和程序运行

1. 重新打开更新后的 `car/autocar.uvprojx`，确认工程文件列表包含 `camera_diagnostics.c`，Rebuild后下载。若Keil仍缓存旧工程设置，重新加载磁盘上的工程，避免旧配置覆盖新增文件注册。
2. 逐飞助手切换到 **串口助手**，连接COM7、115200、8N1、无流控，取消HEX显示。
3. 主板按规格外部供电。若正在Keil调试会话中且CPU停在main/断点，按Run/F5；也可退出调试后按核心板RESET运行。
4. 观察 **核心板上B9/IO指示灯**，不是摄像头红灯、CORE电源灯或DAP指示灯。串口诊断应每500ms翻转一次，并持续输出：

```text
AUTOCAR_DIAG UART1 B12/B13 115200 8N1
UART_HEARTBEAT n=1 camera=SKIPPED motors=OFF
UART_HEARTBEAT n=2 camera=SKIPPED motors=OFF
```

| 观察 | 能说明什么 | 下一步 |
| --- | --- | --- |
| B9/IO灯翻转，但原始接收仍0 | 诊断循环在执行，数据未到达PC；摄像头采集不会阻塞此模式 | 核对B12经J2到DAP RX的板内通路、共地、DAP串口桥及COM号 |
| 灯不翻转且接收0 | 尚不能证明诊断循环持续运行 | 确认确实烧录了本轮固件、CPU处于Run、复位/启动状态、核心板及主板供电；可用Watch看`camera_diag_stage` |
| 持续收到UART_HEARTBEAT | UART发送及PC接收链路基本可用 | 改模式2检查摄像头 |
| 收到乱码但字节增长 | 有串口数据，解码或电气条件需核对 | 检查115200/8N1/无流控、地线及电平 |

**J2是板内串口连接，不是SWD排线是否插对。** 核心板说明书明确：J2未接通时，MCU B12与下载口TX断开；SWD仍可能正常烧录。J4对应接收方向，J5是电源通路，不要混淆。实物板卡版本尚未确认，先核对丝印、原理图或断电通断结果，不盲目短接焊盘。

### 串口通后检查摄像头

将配置中的模式改为2，重新编译下载，仍使用串口助手：

```text
CAMERA_INIT_BEGIN attempt=1
CAMERA_INIT_OK waiting for CSI frames
CAMERA_STATE csi_irq=50 frames=49 stage=6
```

上面数值仅为格式示例。`frames`是每10ms轮询观察到完成标志的累计次数，可能漏掉采集帧，不能当作精确FPS；CSI中断次数也可能包含其他事件。`stage=6`只表示曾观察到完成帧，持续采集需要看计数是否继续增长。

- 只有 `CAMERA_INIT_BEGIN` 后停止：最后可见位置是驱动初始化调用内，需进一步核对程序是否卡住/断言、控制通信和供电。
- 反复 `CAMERA_INIT_FAIL`：摄像头配置通信未成功，检查电源、排线线序和SCCB/UART5配置通路。
- `CAMERA_INIT_OK`，IRQ和帧数始终0：初始化返回成功，但没有观察到CSI采集进展，检查采集接口、PCLK/VSYNC、IRQ/运行状态。
- IRQ增长但帧数始终0：有CSI中断，尚未得到完整帧通知，需要进一步检查CSI状态和缓冲交接。
- 帧数持续增长：已有采集完成通知。改模式0恢复图传，再检查上位机是否收到图像。

可观察的阶段值：0未进入诊断，1诊断启动中，2串口心跳，3调用摄像头初始化，4初始化失败，5等待完成帧，6曾观察到完成帧。诊断不会替代实物供电或波形测量；两种模式均未由自动化工具实际烧录。

## 当前工程提供什么

正常模式（`CAMERA_DIAGNOSTIC_MODE=0`）通过DAP的虚拟串口发送 **188×120原始灰度图＋实际左线、中线、右线**。三条线来自 `img_process.c` 的计算，不是示例中预先画好的演示线。屏幕、电机和舵机输出仍按 [board_config.h](../car/config/board_config.h) 保持关闭，未由自动化工具执行烧录或硬件测试。

| 文件 | 职责 |
| --- | --- |
| [camera_debug_config.h](../car/config/camera_debug_config.h) | 开关、传输方式、图像视图、抽帧、Wi-Fi连接参数 |
| [camera_debug.c](../car/src/camera_debug.c) | 初始化传输、稳定图像快照、协议配置和发送失败处理 |
| [camera_debug.h](../car/include/camera_debug.h) | 应用接口与可观察状态 |
| [main.c](../car/src/main.c) | 在二值化前保存灰度图，完成边线/转向计算后发送 |
| [seekfree_assistant.c](../car/library/zf_components/seekfree_assistant.c) | 供应商原有图像、边线协议实现，未改写 |

图传启用时关闭原先每10帧一次的周期 `printf`，避免文本混入二进制图传。摄像头初始化失败信息、开机状态及助手初始化失败信息仍在开始图传前经UART1输出。运行时不要向同一图传串口追加普通打印。

本次接入图像与三条边线，没有绑定远程PID参数、目标速度或虚拟手柄。上位机的“调参”按钮不会自动改变本项目控制参数。

## 指定例程 main.c 的用法与迁入依据

来源：[1.2.7配套RT1064总钻风示例](<D:/seekfree_assistant-V1.2.7/【程序】各个单片机的使用程序/RT1064/seekfree_assistant_mt9v03x_demo/user/src/main.c>)。

它的核心调用顺序是：

1. `clock_init`、`debug_init` 配置基础环境和UART1。
2. `seekfree_assistant_interface_init(SEEKFREE_ASSISTANT_DEBUG_UART)` 绑定发送/接收接口。这个函数只选接口，不负责初始化Wi-Fi或建立网络连接。
3. `mt9v03x_init` 初始化摄像头。
4. `seekfree_assistant_camera_information_config` 登记图像类型、数据地址、宽、高。
5. `seekfree_assistant_camera_boundary_config` 登记边线类型及数组地址。
6. 每收到新帧，复制图像到稳定缓冲区，再调用 `seekfree_assistant_camera_send()`。

原例的 `INCLUDE_BOUNDARY_TYPE`：0仅图像；1图像＋逐行X坐标；2图像＋逐列Y坐标；3图像＋任意XY点；4仅逐行边线。原例默认3，边线由循环人工构造，不能当作实际识别结果。

本项目每行只有一个左右边界/中线点，因此使用 **X_BOUNDARY**，点数120，数组下标就是行号Y，数组值是列坐标X。配置一次数组地址后，每帧发送其最新计算结果。

已逐文件对照指定包与工程V3.11.2组件：图像协议 `.c/.h` 只有版权注释拼写差异，当前interface额外支持BLE6A20。因此直接复用现有组件，没有用旧包覆盖SDK或摄像头驱动。

## 现在使用 DAP 与 COM7

本节适用于正常图传模式0。当前串口心跳模式1请先按上文诊断步骤操作。

1. 断电确认摄像头排线、DAP与核心板原厂调试排线连接正确。主板按其规格外部供电、与DAP共地；例程明确提醒不要仅靠下载器为摄像头等模块供电。
2. 打开 [autocar.uvprojx](../car/autocar.uvprojx)，按 [构建说明](environment-and-build.md) 编译，再通过DAP的SWD接口下载固件并运行。也可使用 [已生成固件目录](../outputs/firmware/)。本次自动化工作未替你执行烧录。
3. 关闭其他软件对COM7的串口占用。SWD下载功能与COM串口图传是不同通道，能下载不等于串口信号已接通。
4. 打开逐飞助手V1.2.7，选择 **图像传输 → 串行端口 → COM7**。
5. 设置 **115200、8数据位、1停止位、无校验、无流控**，点击 **连接**。若复位或重插后COM号改变，以设备管理器为准。
6. 连接后复位核心板一次，确认程序运行，再等待数秒，应收到灰度图和三条边线。宽高、图像类型和边线方式都由协议传入，PC不需要另外填写188×120或手工选GRAY。

核心板到DAP的串口通路：MCU **B12/TX → DAP接收端**，MCU **B13/RX ← DAP发送端**，同时共地。使用匹配的10P排线时核对板上串口跳线即可，不要随意另接供电。

逐飞普通核心板和Lite说明书都将 **J2**用于B12/TX通路、**J4**用于B13/RX通路，但焊盘位置须依据实物版本核对。仅上行图传主要需要TX通路；双向串口还需要RX通路。普通说明书§9.2.2末句将J4误写成J2，不能只按该句操作；J5属于供电通路，不能当串口跳线处理。DVL6B芯片型号本身不能证明核心板一定是Lite。

## 图像模式与带宽

只修改 [camera_debug_config.h](../car/config/camera_debug_config.h)，然后重新编译下载：

| 配置 | 取值与作用 |
| --- | --- |
| `CAMERA_DEBUG_ENABLED` | 1启用图传；0恢复原有周期文本诊断 |
| `CAMERA_DEBUG_TRANSPORT` | 默认 `CAMERA_DEBUG_DAP_UART`；将来Wi-Fi用 `CAMERA_DEBUG_WIFI_UART` |
| `CAMERA_DEBUG_IMAGE_MODE` | `CAMERA_DEBUG_GRAY`原始灰度；`CAMERA_DEBUG_BINARY`二值处理结果；`CAMERA_DEBUG_BOUNDARIES_ONLY`仅三条线 |
| `CAMERA_DEBUG_UART_BAUDRATE` | DAP/UART1图传波特率，默认115200；PC必须一致。它不修改Wi-Fi模块UART8波特率 |
| `CAMERA_DEBUG_FRAME_DIVIDER` | 默认1；先发送第一帧，以后每N个已处理帧发送一次。不是毫秒周期 |

默认图像＋三线约22936字节。115200、8N1的理论有效带宽为11520字节/秒，因此一帧约2秒，加上处理与显示开销可能更慢；这不是摄像头采集帧率。即使提高抽帧间隔，单次发送仍会阻塞约这么久。

二值视图仍通过GRAY协议逐像素发送0/255，数据量没有缩小。仅边线约376字节，理论串口时间约33ms，可以更快观察线条变化，但没有灰度画面属于预期。

首次连接保持115200。若以后提高波特率，先核对具体DAP版本的串口能力，不根据“双模”名称推断其支持任意高速率。

所有图传都在主循环执行，不在10ms PIT中断中执行。阻塞传输仍会降低图像处理和转向更新速度，因此当前固件用于静态/架空调试；正式运动控制前应关闭图传或另行设计和验证非阻塞方案。

## 将来使用 Wi-Fi 转串口模块

以下针对与当前逐飞库匹配的 **Wi-Fi UART模块**，用户尚未拥有，只有编译及协议模拟验证，没有无线实测。使用前恢复 `CAMERA_DIAGNOSTIC_MODE=0`。

### 模块与接线

| Wi-Fi UART模块信号 | 当前库默认MCU接口 |
| --- | --- |
| RX | UART8_TX，D16 |
| TX | UART8_RX，D17 |
| RTS | D26 |
| RST | D27 |
| VCC/GND | 按匹配模块及主板说明连接5V/GND，共地 |

实际主板插座、供电和电平以实物版本为准。库的UART8速率为115200；旧例程里RST写B9的注释与实际头文件不一致，以 [wifi_uart.h](../car/library/zf_device/zf_device_wifi_uart.h) 的D27定义为准。

### 电脑与固件配置

1. 电脑和模块接入互相可达的2.4GHz Wi-Fi网络，确认没有访客/客户端隔离。
2. 在电脑上查该网络接口的实际IPv4地址，例如通过 `ipconfig`。目标是电脑地址，不是127.0.0.1、路由器地址或模块自己的地址。
3. 逐飞助手选择 **图像传输 → 网络 → TCP Server**，选择电脑实际IPv4、端口 **8080**，点击连接开始监听。
4. Windows防火墙为逐飞助手在相应网络类型放行；不需要关闭整个防火墙。
5. 编辑 `camera_debug_config.h`，将下列占位文字替换为实际网络参数：

```c
#define CAMERA_DEBUG_TRANSPORT       CAMERA_DEBUG_WIFI_UART
#define CAMERA_DEBUG_WIFI_SSID       "你的2.4GHz网络名称"
#define CAMERA_DEBUG_WIFI_PASSWORD   "网络密码"
#define CAMERA_DEBUG_WIFI_SERVER_IP  "电脑的实际IPv4"
#define CAMERA_DEBUG_WIFI_SERVER_PORT "8080"
```

6. 重新编译下载。**先让电脑服务器监听，再复位车端。** 初始化顺序为模块入网 `wifi_uart_init(..., WIFI_UART_STATION)` → 连接电脑 `wifi_uart_connect_tcp_servers(..., WIFI_UART_COMMAND)` → 绑定助手接口 → 发图。
7. 连接成功后，上位机应显示模块客户端和图像。代码不会自动重连；配置错误或连接失败后，修正配置/网络并重新初始化或复位。

手册示例端口为8080，库头文件默认目标端口为8086。本项目显式传入配置中的8080，不使用库默认目标端口，两端必须保持一致。

这里使用COMMAND发送模式。上游SERIANET分支的无符号长度递减存在返回值下溢问题，本次没有选用它，也没有修改第三方驱动。Wi-Fi UART仍受MCU与模块之间串口带宽限制，不能因有Wi-Fi就认为灰度图会高速传输。

### 不同无线产品的区别

| 产品 | 电脑端操作 | 当前工程支持情况 |
| --- | --- | --- |
| 普通无线转串口（配套USB无线端） | 选择配套端的COM口 | 不属于本次Wi-Fi UART初始化方案 |
| Wi-Fi转串口 | 网络TCP/UDP；本次用PC Server/车端Client | 已有可配置分支，未硬件实测 |
| Wi-Fi SPI | 网络TCP/UDP，MCU侧使用SPI | 本次未接入此传输分支 |

购买/接入前先核对具体模块类型，不能把普通无线串口按Wi-Fi的SSID/IP方式配置。

## 状态与排查

可在Keil观察 `camera_debug_status` 和 `camera_debug_frames_sent`：

| 状态值 | 含义 | 检查方向 |
| ---: | --- | --- |
| 0 | 已关闭 | `CAMERA_DEBUG_ENABLED` |
| 1 | 初始化成功，可发送 | 若PC无图，检查物理通路和PC设置；并不证明PC实际收到了图像 |
| 2 | 配置错误 | Wi-Fi SSID/IP/端口是否为空，边线数组是否有效 |
| 3 | Wi-Fi模块初始化失败 | 模块类型、供电、UART8连接、SSID/密码 |
| 4 | TCP连接失败 | 电脑监听、地址端口、同网、防火墙与隔离 |
| 5 | 发送失败 | 网络/模块状态；恢复后重新初始化或复位 |

发送回调返回非0时，本帧后续数据块和未来帧都会停止发送，避免在失败后继续拼接数据。COMMAND等待模块应答可能持续约10秒一次，发送失败不一定立即返回；已经部分发出的帧不会被“撤回”。

- **COM7不存在或连接失败**：重新核对设备管理器、数据线和串口占用；烧录SWD驱动与串口枚举是两件事。
- **收到初始化失败文本**：检查摄像头供电、排线和CSI接口。相机未初始化成功时不会进入正常图传。
- **COM7能连接但字节数始终不变**：检查固件是否运行、B12/J2和共地，不能只用“能下载”判定串口已经接通。
- **字节数增长但无正确图像**：检查115200/8N1/无流控、图像传输页、是否运行本次固件及是否混入运行期printf。
- **图像慢**：先与上述带宽估算比较，可切换仅边线模式。
- **TCP服务开启失败**：检查端口占用；换端口时两端同时改。
- **录制视频回放在动，实时界面不动**：按手册故障7检查显卡驱动；若录像本身也不动，先排查数据发送。

上位机保存图片/视频默认可能写到助手程序目录。长期保留的采集材料应先按 [文件规范](standards/files.md) 与 [命名规范](standards/naming.md) 确定位置；本次没有新增图片/视频产物目录。

## 来源与验证范围

- [逐飞助手说明书V1.4](<D:/seekfree_assistant-V1.2.7/【文档】说明书/逐飞助手说明书 V1.4.pdf>)：PDF第8–16页通信、第29–40页图传、第52–53页故障排查；印刷页码比PDF页码少1。
- [DAPLink使用说明V1.2](<../SeekFree/RT1064_Library/【文档】说明书 芯片手册等/核心板文档/DAP 下载器使用说明/DAPLink使用说明 V1.2.pdf>)：PDF第3、5页，CDC串口及连接说明。
- [普通RT1064核心板说明书V1.9](<../SeekFree/RT1064_Library/【文档】说明书 芯片手册等/核心板文档/【！！必读！！】核心板使用说明/RT1064核心板说明书 V1.9.pdf>)：§9.2串口跳线。
- [RT1064 Lite说明书1.2](<../SeekFree/RT1064_Library/【文档】说明书 芯片手册等/核心板文档/【！！必读！！】核心板使用说明/RT1064 Lite核心板使用说明1.2.pdf>)：§7.1串口跳线。

正常图传协议测试使用真实应用适配层、真实逐飞协议及FIFO代码，替代UART/Wi-Fi硬件I/O；覆盖7种配置、11个场景。DAP和Wi-Fi配置均通过Keil6.21全量编译，0错误0警告。编译和主机测试不能代替COM7连接摄像头或实际Wi-Fi模块的验证。

```powershell
python -B .\car\tests\test_camera_debug.py
```

首次图传整合记录：[协议测试](../logs/camera-debug-tests.log)、[完整主机检查](../logs/camera-debug-suite.log)、[DAP编译](../logs/camera-debug-dap-build.log)、[Wi-Fi编译](../logs/camera-debug-wifi-build.log)。Wi-Fi编译使用临时测试参数，不作为可直接联网的固件交付。

本轮零接收排查另增5个诊断场景，覆盖串口心跳、初始化失败重试、初始化调用停住、无帧等待及完成帧计数。连同11个协议场景、4项构建脚本检查及19项算法检查全部通过。模式1、2、0分别通过Keil6.21编译，均0错误0警告；模式0的BIN与加入诊断前完全相同。当前发布至 `outputs/firmware/autocar.*` 的是模式1串口心跳固件；旧正常图传固件保存在 `outputs/backups/car_before-camera-diagnostics_20261001_180904.zip`。

本轮记录：[诊断及回归检查](../logs/camera-diagnostics-tests.log)、[串口诊断编译](../logs/camera-diagnostics-serial-build.log)、[摄像头诊断编译](../logs/camera-diagnostics-camera-build.log)、[正常模式编译](../logs/camera-diagnostics-normal-build.log)。未进行自动烧录或硬件收发测试，故障根因仍待实物反馈。
