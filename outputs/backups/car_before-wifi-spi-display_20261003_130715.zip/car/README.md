# Autocar RT1064 工程

打开 [autocar.uvprojx](autocar.uvprojx)，目标 `autocar`。

本工程用于 C 车模、逐飞 MIMXRT1064DVL6B、MT9V034、DRV8701 和1024线增量式编码器的基础调试。没有屏幕，默认关闭电机/舵机输出。引脚与功能开关见 [board_config.h](config/board_config.h)，接线仍需按实物确认。

当前正在排查COM7原始接收为0：`CAMERA_DIAGNOSTIC_MODE=1`，烧录后请在串口助手查看心跳，图像页面不会显示图像。模式2检查摄像头初始化/帧状态，改回0才恢复正常图传。配置在 [camera_debug_config.h](config/camera_debug_config.h)，判读步骤见下方逐飞助手指南。

在工作区根目录执行：

```powershell
.\car\scripts\build.ps1
.\car\scripts\test.ps1
```

- [构建与调试说明](../docs/environment-and-build.md)
- [硬件与引脚](../docs/hardware-and-pins.md)
- [逐飞助手图传使用说明](../docs/seekfree-assistant-debugging.md)
- [已知问题与验证边界](../docs/known-issues.md)
- [全部例程的使用说明](../docs/examples/README.md)
- [最终固件](../outputs/firmware/)

`src/` 为应用实现，`include/` 为接口，`config/` 为硬件配置，`library/` 为保留来源和许可的SDK与逐飞驱动。图像/PID来源于本地摄像头组参考工程并作了回归修复；中断框架和底层库来源于V3.11.2。尚未实现完整赛道元素处理和自动停车。
