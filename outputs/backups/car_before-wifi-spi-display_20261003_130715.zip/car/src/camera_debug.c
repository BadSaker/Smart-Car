/* Application adaptation of the SeekFree Assistant MT9V03X example.
 * Original example: Copyright (c) 2022 SEEKFREE 逐飞科技.
 * SPDX-License-Identifier: GPL-3.0-or-later
 * See car/library/LICENSE and docs/seekfree-assistant-debugging.md for provenance.
 * This adapter keeps the existing V3.11.2 protocol library unchanged. */
#include "zf_common_headfile.h"
#include "camera_debug.h"

volatile camera_debug_status_t camera_debug_status = CAMERA_DEBUG_DISABLED;
volatile uint32_t camera_debug_frames_sent = 0;

#if CAMERA_DEBUG_ENABLED
#if MT9V03X_W > 255 || MT9V03X_H > 255
#error "The application boundary arrays use 8-bit coordinates"
#endif

extern seekfree_assistant_transfer_callback_function seekfree_assistant_transfer_callback;
static seekfree_assistant_transfer_callback_function transport_write;
static uint32_t frame_sequence;
static uint8_t frame_available;
#if CAMERA_DEBUG_IMAGE_MODE != CAMERA_DEBUG_BOUNDARIES_ONLY
static uint8_t transmit_image[MT9V03X_H][MT9V03X_W];
#endif

/* The vendor packet sender ignores callback return values. Stop later chunks
 * after a transport failure, so they do not continue an incomplete frame. */
static uint32 camera_debug_transfer(const uint8 *data, uint32 length)
{
    uint32 remaining;
    if (camera_debug_status != CAMERA_DEBUG_READY || transport_write == NULL)
        return length;
    remaining = transport_write(data, length);
    if (remaining != 0U)
        camera_debug_status = CAMERA_DEBUG_SEND_ERROR;
    return remaining;
}
#endif

uint8_t camera_debug_init(uint8_t *left, uint8_t *middle, uint8_t *right)
{
    camera_debug_status = CAMERA_DEBUG_DISABLED;
    camera_debug_frames_sent = 0;
#if CAMERA_DEBUG_ENABLED
    frame_sequence = 0;
    frame_available = 0;
    transport_write = NULL;
    if (left == NULL || middle == NULL || right == NULL)
    {
        camera_debug_status = CAMERA_DEBUG_CONFIG_ERROR;
        return 1;
    }
#if CAMERA_DEBUG_TRANSPORT == CAMERA_DEBUG_DAP_UART
    /* debug_init() already created the receive FIFO. Reapply this application's
     * selected baud, then restore RX interrupts cleared by UART reinitialization. */
    uart_init(DEBUG_UART_INDEX, CAMERA_DEBUG_UART_BAUDRATE, DEBUG_UART_TX_PIN, DEBUG_UART_RX_PIN);
    uart_rx_interrupt(DEBUG_UART_INDEX, DEBUG_UART_USE_INTERRUPT);
    seekfree_assistant_interface_init(SEEKFREE_ASSISTANT_DEBUG_UART);
#else
    char ssid[] = CAMERA_DEBUG_WIFI_SSID;
    char password[] = CAMERA_DEBUG_WIFI_PASSWORD;
    char server_ip[] = CAMERA_DEBUG_WIFI_SERVER_IP;
    char server_port[] = CAMERA_DEBUG_WIFI_SERVER_PORT;
    if (ssid[0] == '\0' || server_ip[0] == '\0' || server_port[0] == '\0')
    {
        camera_debug_status = CAMERA_DEBUG_CONFIG_ERROR;
        return 1;
    }
    if (wifi_uart_init(ssid, password, WIFI_UART_STATION))
    {
        camera_debug_status = CAMERA_DEBUG_INIT_ERROR;
        return 1;
    }
    /* COMMAND has defined 0-success semantics; the vendor SERIANET branch has
     * an unsigned-length underflow on completion and is not used here. */
    if (wifi_uart_connect_tcp_servers(server_ip, server_port, WIFI_UART_COMMAND))
    {
        camera_debug_status = CAMERA_DEBUG_CONNECT_ERROR;
        return 1;
    }
    seekfree_assistant_interface_init(SEEKFREE_ASSISTANT_WIFI_UART);
#endif
    transport_write = seekfree_assistant_transfer_callback;
    seekfree_assistant_transfer_callback = camera_debug_transfer;
#if CAMERA_DEBUG_IMAGE_MODE == CAMERA_DEBUG_BOUNDARIES_ONLY
    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, NULL, MT9V03X_W, MT9V03X_H);
#else
    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, transmit_image[0], MT9V03X_W, MT9V03X_H);
#endif
    seekfree_assistant_camera_boundary_config(X_BOUNDARY, MT9V03X_H, left, middle, right, NULL, NULL, NULL);
    camera_debug_status = CAMERA_DEBUG_READY;
#else
    (void)left; (void)middle; (void)right;
#endif
    return 0;
}

void camera_debug_capture_frame(const uint8_t *gray_image)
{
#if CAMERA_DEBUG_ENABLED
    if (camera_debug_status != CAMERA_DEBUG_READY || gray_image == NULL) return;
#if CAMERA_DEBUG_IMAGE_MODE == CAMERA_DEBUG_GRAY
    memcpy(transmit_image[0], gray_image, sizeof(transmit_image));
#endif
    frame_available = 1;
#else
    (void)gray_image;
#endif
}

void camera_debug_send_frame(const uint8_t *binary_image)
{
#if CAMERA_DEBUG_ENABLED
    if (camera_debug_status != CAMERA_DEBUG_READY || !frame_available) return;
    frame_available = 0;
    if (frame_sequence++ % CAMERA_DEBUG_FRAME_DIVIDER != 0U) return;
#if CAMERA_DEBUG_IMAGE_MODE == CAMERA_DEBUG_BINARY
    if (binary_image == NULL) return;
    memcpy(transmit_image[0], binary_image, sizeof(transmit_image));
#else
    (void)binary_image;
#endif
    seekfree_assistant_camera_send();
    if (camera_debug_status == CAMERA_DEBUG_READY) ++camera_debug_frames_sent;
#else
    (void)binary_image;
#endif
}
