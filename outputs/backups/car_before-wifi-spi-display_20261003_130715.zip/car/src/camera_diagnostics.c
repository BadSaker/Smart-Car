#include "zf_common_headfile.h"
#include "camera_diagnostics.h"

volatile camera_diag_stage_t camera_diag_stage = CAMERA_DIAG_NOT_STARTED;
volatile uint32_t camera_diag_init_attempts = 0;
volatile uint32_t camera_diag_csi_irq_count = 0;
volatile uint32_t camera_diag_frame_count = 0;

void camera_diagnostics_run(void)
{
#if CAMERA_DIAGNOSTIC_MODE != CAMERA_DIAGNOSTIC_NONE
    char text[160];
    uint32_t heartbeat = 0;
    camera_diag_stage = CAMERA_DIAG_STARTING;
    camera_diag_init_attempts = 0;
    camera_diag_csi_irq_count = 0;
    camera_diag_frame_count = 0;
    gpio_init(B9, GPO, GPIO_LOW, GPO_PUSH_PULL);
    uart_init(DEBUG_UART_INDEX, 115200U, DEBUG_UART_TX_PIN, DEBUG_UART_RX_PIN);
    uart_rx_interrupt(DEBUG_UART_INDEX, DEBUG_UART_USE_INTERRUPT);
    interrupt_global_enable(0);
    uart_write_string(DEBUG_UART_INDEX, "\r\nAUTOCAR_DIAG UART1 B12/B13 115200 8N1\r\n");

#if CAMERA_DIAGNOSTIC_MODE == CAMERA_DIAGNOSTIC_SERIAL
    camera_diag_stage = CAMERA_DIAG_SERIAL_RUNNING;
    while (1)
    {
        gpio_toggle_level(B9);
        ++heartbeat;
        snprintf(text, sizeof(text), "UART_HEARTBEAT n=%lu camera=SKIPPED motors=OFF\r\n", (unsigned long)heartbeat);
        uart_write_string(DEBUG_UART_INDEX, text);
        system_delay_ms(500);
    }
#else
    system_delay_ms(300);
    while (1)
    {
        camera_diag_stage = CAMERA_DIAG_INITIALIZING;
        ++camera_diag_init_attempts;
        snprintf(text, sizeof(text), "CAMERA_INIT_BEGIN attempt=%lu\r\n", (unsigned long)camera_diag_init_attempts);
        uart_write_string(DEBUG_UART_INDEX, text);
        if (mt9v03x_init() == 0)
        {
            camera_diag_stage = CAMERA_DIAG_WAITING_FRAME;
            uart_write_string(DEBUG_UART_INDEX, "CAMERA_INIT_OK waiting for CSI frames\r\n");
            break;
        }
        camera_diag_stage = CAMERA_DIAG_INIT_FAILED;
        uart_write_string(DEBUG_UART_INDEX, "CAMERA_INIT_FAIL retry in 1s\r\n");
        gpio_toggle_level(B9);
        system_delay_ms(1000);
    }
    while (1)
    {
        if (mt9v03x_finish_flag)
        {
            mt9v03x_finish_flag = 0;
            ++camera_diag_frame_count;
            camera_diag_stage = CAMERA_DIAG_FRAMES_ACTIVE;
        }
        if (++heartbeat % 100U == 0U)
        {
            gpio_toggle_level(B9);
            snprintf(text, sizeof(text), "CAMERA_STATE csi_irq=%lu frames=%lu stage=%u\r\n",
                     (unsigned long)camera_diag_csi_irq_count,
                     (unsigned long)camera_diag_frame_count, (unsigned)camera_diag_stage);
            uart_write_string(DEBUG_UART_INDEX, text);
        }
        system_delay_ms(10);
    }
#endif
#endif
}
