"""Compile the real adapter/protocol for host verification, stubbing hardware only."""
from pathlib import Path
import argparse
import os
import shutil
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[2]
SCRATCH = ROOT / 'tmp/camera-debug-tests'
COMPILER = os.environ.get('AUTOCAR_HOST_CC', r'D:\Xilinx\Vivado\2022.2\tps\mingw\6.2.0\win64.o\nt\bin\gcc.exe')
TYPES = '''#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
typedef uint8_t uint8; typedef uint16_t uint16; typedef uint32_t uint32;
typedef int32_t int32; typedef volatile uint8 vuint8;
/* MinGW PE weak aliases differ from the ARM linker. Keep the real function
 * bodies, using ordinary linkage for this host-only build. */
#define ZF_WEAK
#define zf_assert(x) assert(x)
'''
PLATFORM = '''#pragma once
#include "zf_common_typedef.h"
#include "seekfree_assistant.h"
#include "seekfree_assistant_interface.h"
#define MT9V03X_W 188
#define MT9V03X_H 120
#define DEBUG_UART_INDEX 1
#define DEBUG_UART_TX_PIN 12
#define DEBUG_UART_RX_PIN 13
#define DEBUG_UART_USE_INTERRUPT 1
#define WIFI_UART_STATION 0
#define WIFI_UART_COMMAND 0
void uart_init(int,uint32,int,int);
void uart_rx_interrupt(int,uint32);
uint8 wifi_uart_init(char*,char*,int);
uint8 wifi_uart_connect_tcp_servers(char*,char*,int);
'''
SENDERS = ['debug_send_buffer','wifi_uart_send_buffer','wireless_uart_send_buffer',
           'bluetooth_ch9141_send_buffer','wifi_spi_send_buffer','ble6a20_send_buffer']
READERS = ['debug_read_ring_buffer','wifi_uart_read_buffer','wireless_uart_read_buffer',
           'bluetooth_ch9141_read_buffer','wifi_spi_read_buffer','ble6a20_read_buffer']
PLATFORM += '\n'.join('uint32 '+n+'(const uint8*,uint32);' for n in SENDERS)
PLATFORM += '\n' + '\n'.join('uint32 '+n+'(uint8*,uint32);' for n in READERS)
WIFI = ['CAMERA_DEBUG_TRANSPORT=1','CAMERA_DEBUG_WIFI_SSID="test-network"',
        'CAMERA_DEBUG_WIFI_PASSWORD="test-password"','CAMERA_DEBUG_WIFI_SERVER_IP="192.168.1.2"']
PROFILES = {
    'dap-gray': [], 'dap-binary': ['CAMERA_DEBUG_IMAGE_MODE=1'],
    'dap-boundaries': ['CAMERA_DEBUG_IMAGE_MODE=2'],
    'dap-decimated': ['CAMERA_DEBUG_FRAME_DIVIDER=2'],
    'wifi-gray': WIFI,
    'wifi-missing-config': ['CAMERA_DEBUG_TRANSPORT=1','TEST_WIFI_MISSING_CONFIG=1'],
    'disabled': ['CAMERA_DEBUG_ENABLED=0'],
}
SELECTED = None


class CameraDebugTests(unittest.TestCase):
    def test_protocol_profiles(self):
        stub = SCRATCH / 'include'
        stub.mkdir(parents=True, exist_ok=True)
        (stub/'zf_common_typedef.h').write_text(TYPES, encoding='ascii')
        (stub/'camera_platform.h').write_text(PLATFORM, encoding='ascii')
        headers = ['zf_common_headfile.h','zf_common_debug.h','zf_driver_uart.h',
                   'zf_device_wireless_uart.h','zf_device_bluetooth_ch9141.h',
                   'zf_device_wifi_uart.h','zf_device_wifi_spi.h','zf_device_ble6a20.h']
        for name in headers:
            (stub/name).write_text('#include "camera_platform.h"\n', encoding='ascii')
        shutil.copy2(ROOT/'car/library/zf_common/zf_common_fifo.h', stub/'zf_common_fifo.h')
        fifo_source = SCRATCH/'zf_common_fifo.c'
        shutil.copy2(ROOT/'car/library/zf_common/zf_common_fifo.c', fifo_source)
        profiles = PROFILES if not SELECTED else {SELECTED: PROFILES[SELECTED]}
        for name, definitions in profiles.items():
            with self.subTest(profile=name):
                exe = SCRATCH/(name+'.exe')
                command = [COMPILER,'-std=c99','-Wall','-Wextra','-Wno-unused-parameter',
                           '-ffunction-sections','-fdata-sections','-Wl,--gc-sections',
                           '-I'+str(stub),'-I'+str(ROOT/'car/include'),
                           '-I'+str(ROOT/'car/config'),'-I'+str(ROOT/'car/library/zf_components')]
                command += ['-D'+d for d in definitions]
                command += [str(ROOT/p) for p in ['car/tests/test_camera_debug.c','car/src/camera_debug.c',
                             'car/library/zf_components/seekfree_assistant.c',
                             'car/library/zf_components/seekfree_assistant_interface.c']]
                command += [str(fifo_source),'-o',str(exe)]
                build = subprocess.run(command,capture_output=True,text=True,encoding='utf-8',errors='replace')
                self.assertEqual(build.returncode,0,build.stdout+build.stderr)
                scenarios = [0,3] if name == 'dap-gray' else [0,1,2,3] if name == 'wifi-gray' else [0]
                for scenario in scenarios:
                    result = subprocess.run([str(exe),str(scenario)],capture_output=True,text=True,encoding='utf-8',errors='replace')
                    self.assertEqual(result.returncode,0,f'{name}/{scenario}: '+result.stdout+result.stderr)
                    print(f'{name}/{scenario}: '+result.stdout.strip())


if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--profile',choices=PROFILES)
    options,remaining=parser.parse_known_args();SELECTED=options.profile
    unittest.main(argv=[__file__]+remaining,verbosity=2)
