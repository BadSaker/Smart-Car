"""Verify diagnostic loops without a board; compiler and files stay task-local."""
from pathlib import Path
import os
import subprocess
import unittest

ROOT=Path(__file__).resolve().parents[2]
SCRATCH=ROOT/'tmp/camera-diagnostics-tests'
CC=os.environ.get('AUTOCAR_HOST_CC',r'D:\Xilinx\Vivado\2022.2\tps\mingw\6.2.0\win64.o\nt\bin\gcc.exe')
STUB='''#pragma once
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
typedef uint8_t uint8;
#define B9 9
#define GPO 1
#define GPIO_LOW 0
#define GPO_PUSH_PULL 0
#define DEBUG_UART_INDEX 1
#define DEBUG_UART_TX_PIN 12
#define DEBUG_UART_RX_PIN 13
#define DEBUG_UART_USE_INTERRUPT 1
extern volatile uint8 mt9v03x_finish_flag;
void gpio_init(int,int,int,unsigned);
void gpio_toggle_level(int);
void interrupt_global_enable(unsigned);
void uart_init(int,unsigned,int,int);
void uart_rx_interrupt(int,unsigned);
void uart_write_string(int,const char*);
void system_delay_ms(unsigned);
uint8 mt9v03x_init(void);
'''


class CameraDiagnosticsTests(unittest.TestCase):
    def test_serial_and_camera_states(self):
        SCRATCH.mkdir(parents=True,exist_ok=True)
        (SCRATCH/'zf_common_headfile.h').write_text(STUB,encoding='ascii')
        for mode,scenarios in [(1,[0]),(2,[0,1,2,3])]:
            with self.subTest(mode=mode):
                exe=SCRATCH/f'diagnostics-{mode}.exe'
                build=subprocess.run([CC,'-std=c99','-Wall','-Wextra','-I'+str(SCRATCH),
                    '-I'+str(ROOT/'car/include'),'-I'+str(ROOT/'car/config'),
                    '-DCAMERA_DIAGNOSTIC_MODE='+str(mode),
                    str(ROOT/'car/tests/test_camera_diagnostics.c'),str(ROOT/'car/src/camera_diagnostics.c'),
                    '-o',str(exe)],capture_output=True,text=True,encoding='utf-8',errors='replace')
                self.assertEqual(build.returncode,0,build.stdout+build.stderr)
                for scenario in scenarios:
                    run=subprocess.run([str(exe),str(scenario)],capture_output=True,text=True,encoding='utf-8',errors='replace')
                    self.assertEqual(run.returncode,0,run.stdout+run.stderr)
                    print(f'diagnostics mode={mode} scenario={scenario}: {run.stdout.strip()}')


if __name__=='__main__': unittest.main(verbosity=2)
