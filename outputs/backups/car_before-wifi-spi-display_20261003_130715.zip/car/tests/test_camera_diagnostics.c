/* Host checks for the real diagnostic loops; only board I/O is replaced. */
#include "zf_common_headfile.h"
#include "camera_diagnostics.h"
#include <setjmp.h>

static jmp_buf stop;
static char output[8192];
static unsigned delays, toggles, camera_calls;
static int scenario;
volatile uint8 mt9v03x_finish_flag;
#define CHECK(x) do { if (!(x)) { printf("FAIL line %d: %s\n",__LINE__,#x); return 1; } } while (0)

void gpio_init(int pin,int dir,int level,unsigned mode) { assert(pin==B9 && dir==GPO); (void)level; (void)mode; }
void gpio_toggle_level(int pin) { assert(pin==B9); ++toggles; }
void interrupt_global_enable(unsigned mask) { assert(mask==0); }
void uart_init(int uart,unsigned baud,int tx,int rx) { assert(uart==DEBUG_UART_INDEX && baud==115200 && tx==DEBUG_UART_TX_PIN && rx==DEBUG_UART_RX_PIN); }
void uart_rx_interrupt(int uart,unsigned enabled) { assert(uart==DEBUG_UART_INDEX && enabled==DEBUG_UART_USE_INTERRUPT); }
void uart_write_string(int uart,const char *text)
{
    assert(uart==DEBUG_UART_INDEX);
    assert(strlen(output)+strlen(text)<sizeof(output));
    strcat(output,text);
}
uint8 mt9v03x_init(void)
{
    assert(strstr(output,"CAMERA_INIT_BEGIN")!=NULL);
    assert(camera_diag_stage==CAMERA_DIAG_INITIALIZING);
    ++camera_calls;
    if (scenario==3) longjmp(stop,1); /* Observe the last stage before a stuck driver. */
    return scenario==1;
}
void system_delay_ms(unsigned ms)
{
    if (ms==300) return; /* Camera power-up settling, not a polling interval. */
    ++delays;
#if CAMERA_DIAGNOSTIC_MODE == CAMERA_DIAGNOSTIC_SERIAL
    assert(ms==500);
    if (delays>=4) longjmp(stop,1);
#else
    if (scenario==1) {
        assert(ms==1000);
        if (delays>=3) longjmp(stop,1);
    } else {
        assert(ms==10);
        if (scenario==2 && (delays%2)==0) {
            ++camera_diag_csi_irq_count;
            mt9v03x_finish_flag=1;
        }
        if (delays>=210) longjmp(stop,1);
    }
#endif
}

int main(int argc,char **argv)
{
    scenario=argc>1?atoi(argv[1]):0;
    if (setjmp(stop)==0) camera_diagnostics_run();
    CHECK(strstr(output,"AUTOCAR_DIAG")!=NULL);
#if CAMERA_DIAGNOSTIC_MODE == CAMERA_DIAGNOSTIC_SERIAL
    CHECK(camera_calls==0 && toggles==4);
    CHECK(camera_diag_stage==CAMERA_DIAG_SERIAL_RUNNING);
    CHECK(strstr(output,"UART_HEARTBEAT n=4")!=NULL);
#else
    if (scenario==1) {
        CHECK(camera_calls==3 && camera_diag_init_attempts==3);
        CHECK(camera_diag_stage==CAMERA_DIAG_INIT_FAILED);
        CHECK(strstr(output,"CAMERA_INIT_FAIL")!=NULL);
    } else if (scenario==3) {
        CHECK(camera_calls==1 && camera_diag_stage==CAMERA_DIAG_INITIALIZING);
        CHECK(strstr(output,"CAMERA_INIT_OK")==NULL);
    } else {
        CHECK(camera_calls==1 && toggles>=2);
        CHECK(strstr(output,"CAMERA_INIT_OK")!=NULL);
        if (scenario==2) {
            CHECK(camera_diag_frame_count>50 && camera_diag_csi_irq_count>=camera_diag_frame_count);
            CHECK(camera_diag_stage==CAMERA_DIAG_FRAMES_ACTIVE);
        } else {
            CHECK(camera_diag_frame_count==0 && camera_diag_csi_irq_count==0);
            CHECK(camera_diag_stage==CAMERA_DIAG_WAITING_FRAME);
            CHECK(strstr(output,"csi_irq=0 frames=0")!=NULL);
        }
    }
#endif
    puts("PASS: diagnostic output, stage and heartbeat match the observed state");
    return 0;
}
