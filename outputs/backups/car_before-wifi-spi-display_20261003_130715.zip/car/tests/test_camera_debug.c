/* Exercise the application adapter and the real SeekFree packet implementation.
 * Only UART/Wi-Fi hardware I/O is replaced by this host fixture. */
#include "zf_common_headfile.h"
#include "camera_debug.h"
#include "camera_debug_config.h"

static uint8 wire[100000];
static uint32 wire_length;
static unsigned write_calls;
static int selected_transport = -1;
static uint32 configured_baud;
static int failure;
static uint8 gray[MT9V03X_H][MT9V03X_W];
static uint8 binary_image[MT9V03X_H][MT9V03X_W];
static uint8 left[MT9V03X_H], middle[MT9V03X_H], right[MT9V03X_H];
#define CHECK(x) do { if (!(x)) { printf("FAIL line %d: %s\n", __LINE__, #x); return 1; } } while (0)

static uint32 capture(int transport, const uint8 *data, uint32 size)
{
    selected_transport = transport;
    ++write_calls;
    if (failure == 3 && write_calls == 2) return size;
    if (wire_length + size > sizeof(wire)) abort();
    memcpy(wire + wire_length, data, size);
    wire_length += size;
    return 0;
}
uint32 debug_send_buffer(const uint8 *p, uint32 n) { return capture(0, p, n); }
uint32 wifi_uart_send_buffer(const uint8 *p, uint32 n) { return capture(1, p, n); }
#define UNUSED_WRITER(name) uint32 name(const uint8 *p, uint32 n) { return capture(9,p,n); }
UNUSED_WRITER(wireless_uart_send_buffer)
UNUSED_WRITER(bluetooth_ch9141_send_buffer)
UNUSED_WRITER(wifi_spi_send_buffer)
UNUSED_WRITER(ble6a20_send_buffer)
#define EMPTY_READER(name) uint32 name(uint8 *p, uint32 n) { (void)p; (void)n; return 0; }
EMPTY_READER(debug_read_ring_buffer)
EMPTY_READER(wifi_uart_read_buffer)
EMPTY_READER(wireless_uart_read_buffer)
EMPTY_READER(bluetooth_ch9141_read_buffer)
EMPTY_READER(wifi_spi_read_buffer)
EMPTY_READER(ble6a20_read_buffer)
void uart_init(int port, uint32 baud, int tx, int rx)
{
    assert(port == DEBUG_UART_INDEX && tx == DEBUG_UART_TX_PIN && rx == DEBUG_UART_RX_PIN);
    configured_baud = baud;
}
void uart_rx_interrupt(int port, uint32 enable) { assert(port == DEBUG_UART_INDEX && enable == DEBUG_UART_USE_INTERRUPT); }
uint8 wifi_uart_init(char *ssid, char *password, int mode)
{
    assert(strcmp(ssid,"test-network") == 0 && strcmp(password,"test-password") == 0);
    assert(mode == WIFI_UART_STATION);
    return failure == 1;
}
uint8 wifi_uart_connect_tcp_servers(char *ip, char *port, int mode)
{
    assert(strcmp(ip,"192.168.1.2") == 0 && strcmp(port,"8080") == 0);
    assert(mode == WIFI_UART_COMMAND);
    return failure == 2;
}

int main(int argc, char **argv)
{
    uint32 i, payload_size, dot_offset;
    const uint8 dot_header[] = {0xaa, 0x03, 0x03, 8, 120, 0, 7, 0};
    uint8 camera_header[] = {0xaa, 0x02, 0x43, 8, 188, 0, 120, 0};
    if (argc > 1) failure = atoi(argv[1]);
    for (i=0; i<sizeof(gray); ++i) {
        ((uint8 *)gray)[i] = (uint8)(i % 251U);
        ((uint8 *)binary_image)[i] = (i & 1U) ? 255 : 0;
    }
    for (i=0; i<MT9V03X_H; ++i) {
        left[i]=(uint8)(3+i%17); middle[i]=(uint8)(80+i%21); right[i]=(uint8)(170+i%17);
    }
    {
        uint8 result = camera_debug_init(left,middle,right);
#if !CAMERA_DEBUG_ENABLED
        CHECK(result == 0 && camera_debug_status == CAMERA_DEBUG_DISABLED);
        camera_debug_capture_frame(gray[0]);
        camera_debug_send_frame(binary_image[0]);
        CHECK(wire_length == 0);
        puts("PASS: disabled transport"); return 0;
#elif defined(TEST_WIFI_MISSING_CONFIG)
        CHECK(result != 0 && camera_debug_status == CAMERA_DEBUG_CONFIG_ERROR);
        CHECK(wire_length == 0);
        puts("PASS: missing Wi-Fi configuration"); return 0;
#else
        if (failure == 1 || failure == 2) {
            CHECK(result != 0);
            CHECK(camera_debug_status == (failure == 1 ? CAMERA_DEBUG_INIT_ERROR : CAMERA_DEBUG_CONNECT_ERROR));
            camera_debug_capture_frame(gray[0]); camera_debug_send_frame(binary_image[0]);
            CHECK(wire_length == 0);
            puts("PASS: initialization failure stays silent"); return 0;
        }
        CHECK(result == 0 && camera_debug_status == CAMERA_DEBUG_READY);
#endif
    }
    camera_debug_send_frame(binary_image[0]);
    CHECK(wire_length == 0); /* Never send an unprepared/stale frame. */
    camera_debug_capture_frame(gray[0]);
    memset(gray, 0xee, sizeof(gray)); /* The adapter must own a stable snapshot. */
    camera_debug_send_frame(binary_image[0]);
    if (failure == 3) {
        CHECK(camera_debug_status == CAMERA_DEBUG_SEND_ERROR && write_calls == 2);
        CHECK(wire_length == 8);
        camera_debug_capture_frame(gray[0]); camera_debug_send_frame(binary_image[0]);
        CHECK(write_calls == 2); /* Do not append later chunks after transport failure. */
        failure = 0; wire_length = 0; write_calls = 0;
        CHECK(camera_debug_init(left,middle,right) == 0);
        camera_debug_capture_frame(gray[0]); camera_debug_send_frame(binary_image[0]);
        CHECK(camera_debug_status == CAMERA_DEBUG_READY && camera_debug_frames_sent == 1);
        CHECK(wire_length > 8);
        puts("PASS: failed send stops output; reinitialization restores it"); return 0;
    }
    CHECK(selected_transport == CAMERA_DEBUG_TRANSPORT);
#if CAMERA_DEBUG_TRANSPORT == CAMERA_DEBUG_DAP_UART
    CHECK(configured_baud == CAMERA_DEBUG_UART_BAUDRATE);
#endif
#if CAMERA_DEBUG_IMAGE_MODE == CAMERA_DEBUG_BOUNDARIES_ONLY
    payload_size = 0; camera_header[2] = 0x53;
#else
    payload_size = 188U * 120U;
#endif
    CHECK(wire_length == 8 + payload_size + 8 + 3*120);
    CHECK(memcmp(wire,camera_header,8) == 0);
    for (i=0; i<payload_size; ++i) {
#if CAMERA_DEBUG_IMAGE_MODE == CAMERA_DEBUG_BINARY
        CHECK(wire[8+i] == ((i & 1U) ? 255 : 0));
#else
        CHECK(wire[8+i] == (uint8)(i % 251U));
#endif
    }
    dot_offset = 8 + payload_size;
    CHECK(memcmp(wire+dot_offset,dot_header,8) == 0);
    CHECK(memcmp(wire+dot_offset+8,left,120) == 0);
    CHECK(memcmp(wire+dot_offset+128,middle,120) == 0);
    CHECK(memcmp(wire+dot_offset+248,right,120) == 0);
    {
        uint32 previous = wire_length;
        camera_debug_send_frame(binary_image[0]); CHECK(wire_length == previous);
#if CAMERA_DEBUG_FRAME_DIVIDER == 2
        camera_debug_capture_frame(gray[0]); camera_debug_send_frame(binary_image[0]);
        CHECK(wire_length == previous);
        camera_debug_capture_frame(gray[0]); camera_debug_send_frame(binary_image[0]);
        CHECK(wire_length == 2 * previous && camera_debug_frames_sent == 2);
#endif
    }
    puts("PASS: packet bytes, image snapshot, real boundaries and transport");
    return 0;
}
