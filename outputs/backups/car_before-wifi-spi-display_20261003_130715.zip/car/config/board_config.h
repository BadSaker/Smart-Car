#ifndef AUTOCAR_BOARD_CONFIG_H
#define AUTOCAR_BOARD_CONFIG_H

/* C chassis, MIMXRT1064DVL6B, MT9V034, DRV8701, 1024-line encoder.
 * Board connector revision, encoder A/B wiring and rotation signs need bench verification.
 * This first bring-up configuration does not drive the motor or steering servo.
 */
#define APP_ENABLE_TFT180          (0)
#define APP_ENABLE_MOTOR_OUTPUT    (0)
#define APP_ENABLE_SERVO_OUTPUT    (0)
#define APP_CONTROL_PERIOD_MS     (10)
#define APP_CONTROL_PERIOD_S      ((float)APP_CONTROL_PERIOD_MS / 1000.0f)
#define APP_ENCODER_LEFT_SIGN     (-1)
#define APP_ENCODER_RIGHT_SIGN    (1)
#define APP_ENCODER_LINES         (1024U)



// 编码器引脚信息
// 前进计数应为正；实际方向通过上方 APP_ENCODER_LEFT_SIGN/RIGHT_SIGN 标定。
// 左轮编码器
#define ENCODER_1 (QTIMER1_ENCODER1)
#define ENCODER_1_A (QTIMER1_ENCODER1_CH1_C0)
#define ENCODER_1_B (QTIMER1_ENCODER1_CH2_C1)
// 右轮编码器
#define ENCODER_2 (QTIMER1_ENCODER2)
#define ENCODER_2_A (QTIMER1_ENCODER2_CH1_C2)
#define ENCODER_2_B (QTIMER1_ENCODER2_CH2_C24)

// 电机参数设置
// !!! 请确保dir和pwm脚不要弄反了，否则电机会疯转 !!!
// 左轮电机
#define MOTOR1_PWM (PWM2_MODULE0_CHA_C6)
#define MOTOR1_DIR (C7)
// 左电机前进需要的DIR脚的电平 (GPIO_HIGH or GPIO_LOW) 请自行测试
#define MOTOR1_FORWARD_DIR_LEVEL (GPIO_HIGH)
// 右轮电机
#define MOTOR2_PWM (PWM2_MODULE1_CHA_C8)
#define MOTOR2_DIR (C9)
// 右电机前进需要的DIR脚的电平 (GPIO_HIGH or GPIO_LOW) 请自行测试
#define MOTOR2_FORWARD_DIR_LEVEL (GPIO_HIGH)


// 舵机参数设置
#define SERVO_MOTOR_PWM (PWM4_MODULE2_CHA_C30) // 定义主板上舵机对应引脚
#define SERVO_MOTOR_FREQ (50)                  // 定义主板上舵机频率  请务必注意范围 50-300
#define SERVO_MOTOR_L_MAX (100)  // 定义主板上舵机活动范围(左打方向的极限值) 角度 自行标定
#define SERVO_MOTOR_R_MAX (85) // 定义主板上舵机活动范围(右打方向的极限值) 角度 自行标定
#define SERVO_DIR (SERVO_MOTOR_L_MAX>SERVO_MOTOR_R_MAX?-1.f:1.f) // 根据左右duty的大小自动决定舵机方向

// 参考舵机模型：0–180°对应0.5–2.5ms脉宽，实际中位/限位必须标定。
// duty = PWM_DUTY_MAX * (0.5 + angle / 90) / (1000 / frequency_hz)
#define SERVO_MOTOR_DUTY(x) ((float)PWM_DUTY_MAX / (1000.0 / (float)SERVO_MOTOR_FREQ) * (0.5 + (float)(x) / 90.0))

#if (SERVO_MOTOR_FREQ < 50 || SERVO_MOTOR_FREQ > 300)
#error "SERVO_MOTOR_FREQ ERROE!"
#endif

#endif /* AUTOCAR_BOARD_CONFIG_H */
