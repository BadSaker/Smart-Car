#ifndef AUTOCAR_CAMERA_DIAGNOSTICS_H
#define AUTOCAR_CAMERA_DIAGNOSTICS_H

#include <stdint.h>
#include "camera_debug_config.h"

typedef enum
{
    CAMERA_DIAG_NOT_STARTED,
    CAMERA_DIAG_STARTING,
    CAMERA_DIAG_SERIAL_RUNNING,
    CAMERA_DIAG_INITIALIZING,
    CAMERA_DIAG_INIT_FAILED,
    CAMERA_DIAG_WAITING_FRAME,
    CAMERA_DIAG_FRAMES_ACTIVE
} camera_diag_stage_t;

extern volatile camera_diag_stage_t camera_diag_stage;
extern volatile uint32_t camera_diag_init_attempts;
extern volatile uint32_t camera_diag_csi_irq_count;
extern volatile uint32_t camera_diag_frame_count;

/* Call after clock_init/debug_init. Modes 1/2 do not return and never initialize
 * actuator/encoder/PIT application control. UART output bypasses printf/fputc. */
void camera_diagnostics_run(void);

#endif
