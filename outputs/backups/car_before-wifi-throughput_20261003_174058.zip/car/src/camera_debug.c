/* 逐飞助手摄像头协议的应用适配：本地预览优先，Wi-Fi按主循环分步发送。
 * Copyright (c) 2022 SEEKFREE 逐飞科技.
 * SPDX-License-Identifier: GPL-3.0-or-later
 * 来源与许可见car/library/LICENSE及docs/seekfree-assistant-debugging.md。
 * 供应商图像协议保持原样，仅用回调把一帧序列化到稳定队列。 */
#include "zf_common_headfile.h"
#include "camera_debug.h"
#include "camera_display.h"
#include "wifi_spi_async.h"

volatile camera_debug_status_t camera_debug_status = CAMERA_DEBUG_DISABLED;
volatile uint32_t camera_debug_frames_sent = 0;
volatile uint32_t camera_debug_frames_dropped = 0;
volatile uint32_t camera_debug_error_count = 0;
volatile uint32_t camera_debug_reconnect_count = 0;
volatile camera_debug_stage_t camera_debug_last_error_stage = CAMERA_DEBUG_STAGE_NONE;
volatile uint32_t camera_debug_last_remaining = 0;
static uint8_t display_timer_armed;
static uint32_t display_updated_ms;

#if CAMERA_DEBUG_ENABLED
#if MT9V03X_W > 255 || MT9V03X_H > 255 || MT9V03X_W < 1 || MT9V03X_H < 1
#error "Camera boundary dimensions must fit 8-bit coordinates"
#endif
#if CAMERA_DEBUG_IMAGE_MODE == CAMERA_DEBUG_BOUNDARIES_ONLY
#define CAMERA_PACKET_IMAGE_BYTES 0U
#else
#define CAMERA_PACKET_IMAGE_BYTES (MT9V03X_W * MT9V03X_H)
static uint8_t transmit_image[MT9V03X_H][MT9V03X_W];
#endif
#define CAMERA_PACKET_CAPACITY (sizeof(seekfree_assistant_camera_struct) + CAMERA_PACKET_IMAGE_BYTES + sizeof(seekfree_assistant_camera_dot_struct) + 3U * MT9V03X_H)

extern seekfree_assistant_transfer_callback_function seekfree_assistant_transfer_callback;
static uint8_t queued_packet[CAMERA_PACKET_CAPACITY];
static uint32_t queued_length, queued_offset;
static uint32_t frame_sequence, observed_link_errors;
static uint8_t frame_available, building_packet, packet_overflow, configuration_valid;

/* 仅在协议序列化期间写队列；不调用任何硬件通信或等待函数。 */
static uint32 collect_packet(const uint8 *data, uint32 length)
{
    if (!building_packet || packet_overflow || data == NULL || length > sizeof(queued_packet) - queued_length)
    {
        packet_overflow = 1;
        return length;
    }
    memcpy(queued_packet + queued_length, data, length);
    queued_length += length;
    return 0;
}

static camera_debug_stage_t packet_stage(uint32_t offset)
{
    if (offset < sizeof(seekfree_assistant_camera_struct)) return CAMERA_DEBUG_STAGE_IMAGE_HEADER;
    offset -= sizeof(seekfree_assistant_camera_struct);
#if CAMERA_DEBUG_IMAGE_MODE != CAMERA_DEBUG_BOUNDARIES_ONLY
    if (offset < CAMERA_PACKET_IMAGE_BYTES) return CAMERA_DEBUG_STAGE_IMAGE;
    offset -= CAMERA_PACKET_IMAGE_BYTES;
#endif
    if (offset < sizeof(seekfree_assistant_camera_dot_struct)) return CAMERA_DEBUG_STAGE_BOUNDARY_HEADER;
    offset -= sizeof(seekfree_assistant_camera_dot_struct);
    if (offset < MT9V03X_H) return CAMERA_DEBUG_STAGE_LEFT;
    if (offset < 2U * MT9V03X_H) return CAMERA_DEBUG_STAGE_MIDDLE;
    return CAMERA_DEBUG_STAGE_RIGHT;
}

static camera_debug_status_t visible_state(const wifi_spi_async_status_t *link)
{
    switch (link->state)
    {
        case WIFI_SPI_ASYNC_READY: return CAMERA_DEBUG_READY;
        case WIFI_SPI_ASYNC_CONFIG_ERROR: return CAMERA_DEBUG_CONFIG_ERROR;
        case WIFI_SPI_ASYNC_CONNECTING: return CAMERA_DEBUG_CONNECTING;
        case WIFI_SPI_ASYNC_INITIALIZING:
        case WIFI_SPI_ASYNC_JOINING: return CAMERA_DEBUG_INITIALIZING;
        case WIFI_SPI_ASYNC_BACKOFF:
            if (link->last_error_phase == WIFI_SPI_ASYNC_ERROR_SOCKET) return CAMERA_DEBUG_CONNECT_ERROR;
            if (link->last_error_phase == WIFI_SPI_ASYNC_ERROR_SEND || link->last_error_phase == WIFI_SPI_ASYNC_ERROR_RECEIVE)
                return CAMERA_DEBUG_SEND_ERROR;
            return CAMERA_DEBUG_INIT_ERROR;
        default: return CAMERA_DEBUG_DISABLED;
    }
}
#endif

uint8_t camera_debug_init(uint8_t *left, uint8_t *middle, uint8_t *right)
{
    camera_debug_status = CAMERA_DEBUG_DISABLED;
    camera_debug_frames_sent = 0;
    camera_debug_frames_dropped = 0;
    camera_debug_error_count = 0;
    camera_debug_reconnect_count = 0;
    camera_debug_last_error_stage = CAMERA_DEBUG_STAGE_NONE;
    camera_debug_last_remaining = 0;
    display_timer_armed = 0;
#if CAMERA_DEBUG_ENABLED
    frame_available = 0; frame_sequence = 0;
    queued_length = 0; queued_offset = 0;
    building_packet = 0; packet_overflow = 0; configuration_valid = 0;
    observed_link_errors = 0;
    if (left == NULL || middle == NULL || right == NULL)
    {
        camera_debug_status = CAMERA_DEBUG_CONFIG_ERROR;
        camera_debug_last_error_stage = CAMERA_DEBUG_STAGE_CONFIG;
        camera_debug_error_count = 1;
        camera_display_network_status(camera_debug_status);
        return 1;
    }
    if (wifi_spi_async_init(CAMERA_DEBUG_WIFI_SSID, CAMERA_DEBUG_WIFI_PASSWORD,
                            CAMERA_DEBUG_WIFI_SERVER_IP, CAMERA_DEBUG_WIFI_SERVER_PORT,
                            CAMERA_DEBUG_WIFI_LOCAL_PORT))
    {
        camera_debug_status = CAMERA_DEBUG_CONFIG_ERROR;
        camera_debug_last_error_stage = CAMERA_DEBUG_STAGE_CONFIG;
        camera_debug_error_count = 1;
        camera_display_network_status(camera_debug_status);
        return 1;
    }
    configuration_valid = 1;
    seekfree_assistant_interface_init(SEEKFREE_ASSISTANT_CUSTOM);
    seekfree_assistant_transfer_callback = collect_packet;
#if CAMERA_DEBUG_IMAGE_MODE == CAMERA_DEBUG_BOUNDARIES_ONLY
    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, NULL, MT9V03X_W, MT9V03X_H);
#else
    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, transmit_image[0], MT9V03X_W, MT9V03X_H);
#endif
    seekfree_assistant_camera_boundary_config(X_BOUNDARY, MT9V03X_H, left, middle, right, NULL, NULL, NULL);
    camera_debug_status = CAMERA_DEBUG_INITIALIZING;
#else
    (void)left; (void)middle; (void)right;
#endif
    camera_display_network_status(camera_debug_status);
    return 0;
}

void camera_debug_poll(uint32_t now_ms)
{
#if CAMERA_DEBUG_ENABLED
    if (configuration_valid)
    {
        uint32_t remaining = queued_length - queued_offset;
        uint32_t accepted = wifi_spi_async_poll(now_ms, remaining ? queued_packet + queued_offset : NULL, remaining);
        const wifi_spi_async_status_t *link = wifi_spi_async_get_status();
        camera_debug_error_count = link->error_count;
        camera_debug_reconnect_count = link->reconnect_count;
        /* SPI已交出字节也可能同时收到错误应答，先处理状态再计算成功帧。 */
        if (link->error_count != observed_link_errors)
        {
            observed_link_errors = link->error_count;
            camera_debug_last_remaining = remaining;
            switch (link->last_error_phase)
            {
                case WIFI_SPI_ASYNC_ERROR_CONFIG: camera_debug_last_error_stage = CAMERA_DEBUG_STAGE_CONFIG; break;
                case WIFI_SPI_ASYNC_ERROR_SOCKET: camera_debug_last_error_stage = CAMERA_DEBUG_STAGE_TCP; break;
                case WIFI_SPI_ASYNC_ERROR_SEND: camera_debug_last_error_stage = packet_stage(queued_offset); break;
                case WIFI_SPI_ASYNC_ERROR_RECEIVE: camera_debug_last_error_stage = CAMERA_DEBUG_STAGE_RECEIVE; break;
                default: camera_debug_last_error_stage = CAMERA_DEBUG_STAGE_WIFI; break;
            }
        }
        if (link->state != WIFI_SPI_ASYNC_READY)
        {
            if (remaining) ++camera_debug_frames_dropped;
            queued_length = 0; queued_offset = 0; frame_available = 0;
        }
        else if (accepted > remaining)
        {
            /* 传输层违反契约时停止继续使用不可信偏移，避免越界。 */
            configuration_valid = 0;
            ++camera_debug_error_count;
            camera_debug_last_error_stage = CAMERA_DEBUG_STAGE_CONFIG;
            queued_length = 0; queued_offset = 0; frame_available = 0;
            camera_debug_status = CAMERA_DEBUG_CONFIG_ERROR;
        }
        else if (remaining)
        {
            queued_offset += accepted;
            if (queued_offset == queued_length)
            {
                ++camera_debug_frames_sent;
                queued_length = 0; queued_offset = 0;
            }
        }
        if (configuration_valid) camera_debug_status = visible_state(link);
        camera_display_network_status(camera_debug_status);
    }
#endif
    if (!display_timer_armed || (uint32_t)(now_ms - display_updated_ms) >= 250U)
    {
        display_timer_armed = 1;
        display_updated_ms = now_ms;
        camera_display_statistics();
    }
}

void camera_debug_capture_frame(const uint8_t *gray_image)
{
    /* 本地预览与网络状态无关，始终先显示当前原始灰度。 */
    camera_display_frame(gray_image);
#if CAMERA_DEBUG_ENABLED
    frame_available = 0;
    if (gray_image == NULL) return;
    if (frame_sequence++ % CAMERA_DEBUG_FRAME_DIVIDER != 0U ||
        camera_debug_status != CAMERA_DEBUG_READY || queued_length != 0U)
    {
        ++camera_debug_frames_dropped;
        return;
    }
#if CAMERA_DEBUG_IMAGE_MODE == CAMERA_DEBUG_GRAY
    memcpy(transmit_image[0], gray_image, sizeof(transmit_image));
#endif
    frame_available = 1;
#else
    (void)gray_image;
#endif
}

void camera_debug_send_frame(const uint8_t *binary_image)
{
#if CAMERA_DEBUG_ENABLED
    if (!frame_available || camera_debug_status != CAMERA_DEBUG_READY || queued_length) return;
    frame_available = 0;
#if CAMERA_DEBUG_IMAGE_MODE == CAMERA_DEBUG_BINARY
    if (binary_image == NULL) { ++camera_debug_frames_dropped; return; }
    memcpy(transmit_image[0], binary_image, sizeof(transmit_image));
#else
    (void)binary_image;
#endif
    queued_offset = 0; queued_length = 0; packet_overflow = 0;
    building_packet = 1;
    seekfree_assistant_camera_send();
    building_packet = 0;
    if (packet_overflow || queued_length != sizeof(queued_packet))
    {
        queued_length = 0; configuration_valid = 0;
        ++camera_debug_error_count;
        camera_debug_last_error_stage = CAMERA_DEBUG_STAGE_CONFIG;
        camera_debug_status = CAMERA_DEBUG_CONFIG_ERROR;
        camera_display_network_status(camera_debug_status);
    }
#else
    (void)binary_image;
#endif
}
