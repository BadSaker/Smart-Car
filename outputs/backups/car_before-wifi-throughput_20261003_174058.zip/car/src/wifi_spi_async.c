/*********************************************************************************************************************
* RT1064DVL6A Opensource Library 即（RT1064DVL6A 开源库）是一个基于官方 SDK 接口的第三方开源库
* Copyright (c) 2022 SEEKFREE 逐飞科技
*
* 本文件是 RT1064DVL6A 开源库的一部分
*
* RT1064DVL6A 开源库 是免费软件
* 您可以根据自由软件基金会发布的 GPL（GNU General Public License，即 GNU通用公共许可证）的条款
* 即 GPL 的第3版（即 GPL3.0）或（您选择的）任何后来的版本，重新发布和/或修改它
*
* 本开源库的发布是希望它能发挥作用，但并未对其作任何的保证
* 甚至没有隐含的适销性或适合特定用途的保证
* 更多细节请参见 GPL
*
* 您应该在收到本开源库的同时收到一份 GPL 的副本
* 如果没有，请参阅<https://www.gnu.org/licenses/>
*
* 额外注明：
* 本开源库使用 GPL3.0 开源许可证协议 以上许可申明为译文版本
* 许可申明英文版在 libraries/doc 文件夹下的 GPL3_permission_statement.txt 文件中
* 许可证副本在 libraries 文件夹下 即该文件夹下的 LICENSE 文件
* 欢迎各位使用并传播本程序 但修改内容时必须保留逐飞科技的版权声明（即本声明）
*
* 文件名称          zf_device_wifi_spi
* 公司名称          成都逐飞科技有限公司
* 版本信息          查看 libraries/doc 文件夹内 version 文件 版本说明
* 开发环境          IAR 8.32.4 or MDK 5.33
* 适用平台          RT1064DVL6A
* 店铺链接          https://seekfree.taobao.com/
*
* 修改记录
* 日期              作者                备注
* 2022-09-21        SeekFree            first version
********************************************************************************************************************/
/* 本项目基于逐飞V3.11.2的线上协议实现应用层异步握手；上方保留原版权声明。
 * 仅沿用GPIO/SPI原语；每次poll最多一笔有限长度事务，不等待模块INT变化。
 * 电气SPI移位仍是同步原语，其单笔长度受1024字节预算限制。 */
#include <stddef.h>
#include <string.h>
#include "zf_driver_gpio.h"
#include "zf_driver_spi.h"
#include "zf_device_wifi_spi.h"
#include "wifi_spi_async.h"
#include "wifi_spi_async_config.h"

#if (WIFI_SPI_ASYNC_CHUNK_SIZE < 32U) || (WIFI_SPI_ASYNC_CHUNK_SIZE > 1024U)
#error "WIFI_SPI_ASYNC_CHUNK_SIZE必须为32至1024字节"
#endif

#if (WIFI_SPI_ASYNC_TRANSACTION_GUARD_MS < 2U)
#error "WIFI_SPI_ASYNC_TRANSACTION_GUARD_MS不得小于2毫秒"
#endif

typedef enum
{
    WIFI_SPI_ASYNC_STEP_SETUP,
    WIFI_SPI_ASYNC_STEP_RESET_LOW,
    WIFI_SPI_ASYNC_STEP_BOOT_WAIT,
    WIFI_SPI_ASYNC_STEP_VERSION_COMMAND,
    WIFI_SPI_ASYNC_STEP_VERSION_REPLY,
    WIFI_SPI_ASYNC_STEP_WIFI_COMMAND,
    WIFI_SPI_ASYNC_STEP_WIFI_REPLY,
    WIFI_SPI_ASYNC_STEP_SOCKET_COMMAND,
    WIFI_SPI_ASYNC_STEP_SOCKET_REPLY,
    WIFI_SPI_ASYNC_STEP_DATA
} wifi_spi_async_step_t;

typedef struct
{
    wifi_spi_async_status_t status;
    wifi_spi_async_step_t step;
    uint32_t phase_since_ms;
    uint32_t transaction_guard_since_ms;
    uint32_t busy_since_ms;
    uint16_t wifi_length;
    uint16_t socket_length;
    uint8_t wifi_command[64];
    uint8_t socket_command[41];
    uint8_t transaction_guard;
    uint8_t transaction_guard_pending;
    uint8_t busy_waiting;
    uint8_t receive_pending;
} wifi_spi_async_context_t;

static wifi_spi_async_context_t wifi_async;

/* 有界扫描既限制串长度，也拒绝会改变供应商CRLF字段结构的换行。 */
static uint8_t wifi_spi_async_text_length(const char *text, uint16_t maximum,
                                          uint16_t *length)
{
    uint16_t index;
    if (text == NULL) return 0;
    for (index = 0; index <= maximum; ++index)
    {
        if (text[index] == '\0')
        {
            *length = index;
            return 1;
        }
        if (text[index] == '\r' || text[index] == '\n') return 0;
    }
    return 0;
}

static uint8_t wifi_spi_async_valid_ip(const char *ip, uint16_t length)
{
    uint16_t index, value = 0, digits = 0, sections = 0;
    for (index = 0; index <= length; ++index)
    {
        if (index == length || ip[index] == '.')
        {
            if (digits == 0 || value > 255) return 0;
            ++sections;
            digits = 0;
            value = 0;
        }
        else
        {
            if (ip[index] < '0' || ip[index] > '9' || ++digits > 3) return 0;
            value = (uint16_t)(value * 10U + (uint16_t)(ip[index] - '0'));
        }
    }
    return sections == 4;
}

static uint8_t wifi_spi_async_valid_port(const char *text, uint16_t length, uint8_t local)
{
    uint16_t index;
    uint32_t port = 0;
    if (length == 0) return 0;
    for (index = 0; index < length; ++index)
    {
        if (text[index] < '0' || text[index] > '9') return 0;
        port = port * 10U + (uint32_t)(text[index] - '0');
    }
    if (port > 65535U) return 0;
    return local ? (port == 0U || port >= 2048U) : (port > 0U);
}

static void wifi_spi_async_append(uint8_t *buffer, uint16_t *length,
                                   const char *text, uint16_t text_length)
{
    memcpy(buffer + *length, text, text_length);
    *length = (uint16_t)(*length + text_length);
    buffer[(*length)++] = '\r';
    buffer[(*length)++] = '\n';
}

uint8_t wifi_spi_async_init(const char *ssid, const char *password,
                          const char *ip, const char *port, const char *local_port)
{
    uint16_t ssid_length = 0, password_length = 0, ip_length = 0;
    uint16_t port_length = 0, local_length = 0;
    memset(&wifi_async, 0, sizeof(wifi_async));
    if (password == NULL) password = "";
    if (!wifi_spi_async_text_length(ssid, 32, &ssid_length) || ssid_length == 0 ||
        !wifi_spi_async_text_length(password, 59, &password_length) ||
        ssid_length + password_length > 59U ||
        !wifi_spi_async_text_length(ip, 15, &ip_length) ||
        !wifi_spi_async_valid_ip(ip, ip_length) ||
        !wifi_spi_async_text_length(port, 5, &port_length) ||
        !wifi_spi_async_valid_port(port, port_length, 0) ||
        !wifi_spi_async_text_length(local_port, 5, &local_length) ||
        !wifi_spi_async_valid_port(local_port, local_length, 1))
    {
        wifi_async.status.state = WIFI_SPI_ASYNC_CONFIG_ERROR;
        wifi_async.status.last_error_phase = WIFI_SPI_ASYNC_ERROR_CONFIG;
        wifi_async.status.error_count = 1;
        return 1;
    }
    wifi_spi_async_append(wifi_async.wifi_command, &wifi_async.wifi_length, ssid, ssid_length);
    if (password_length != 0)
        wifi_spi_async_append(wifi_async.wifi_command, &wifi_async.wifi_length, password, password_length);
    wifi_spi_async_append(wifi_async.socket_command, &wifi_async.socket_length, "TCP", 3);
    wifi_spi_async_append(wifi_async.socket_command, &wifi_async.socket_length, ip, ip_length);
    wifi_spi_async_append(wifi_async.socket_command, &wifi_async.socket_length, port, port_length);
    wifi_spi_async_append(wifi_async.socket_command, &wifi_async.socket_length, local_port, local_length);
    wifi_async.status.state = WIFI_SPI_ASYNC_INITIALIZING;
    wifi_async.step = WIFI_SPI_ASYNC_STEP_SETUP;
    return 0;
}

static void wifi_spi_async_fail(uint32_t now_ms, wifi_spi_async_error_phase_t phase)
{
    wifi_async.status.state = WIFI_SPI_ASYNC_BACKOFF;
    wifi_async.status.last_error_phase = phase;
    ++wifi_async.status.error_count;
    wifi_async.phase_since_ms = now_ms;
    wifi_async.busy_waiting = 0;
    wifi_async.receive_pending = 0;
}

static void wifi_spi_async_begin_reset(uint32_t now_ms)
{
    spi_init(WIFI_SPI_INDEX, SPI_MODE3, WIFI_SPI_SPEED,
             WIFI_SPI_SCK_PIN, WIFI_SPI_MOSI_PIN, WIFI_SPI_MISO_PIN, SPI_CS_NULL);
    gpio_init(WIFI_SPI_CS_PIN, GPO, 1, GPO_PUSH_PULL);
    gpio_init(WIFI_SPI_RST_PIN, GPO, 1, GPO_PUSH_PULL);
    gpio_init(WIFI_SPI_INT_PIN, GPI, 0, GPI_PULL_DOWN);
    gpio_set_level(WIFI_SPI_RST_PIN, 0);
    wifi_async.status.state = WIFI_SPI_ASYNC_INITIALIZING;
    wifi_async.step = WIFI_SPI_ASYNC_STEP_RESET_LOW;
    wifi_async.phase_since_ms = now_ms;
    wifi_async.transaction_guard = 0;
    wifi_async.transaction_guard_pending = 0;
    wifi_async.busy_waiting = 0;
    wifi_async.receive_pending = 0;
}

static void wifi_spi_async_finish_transaction(uint32_t now_ms)
{
    gpio_high(WIFI_SPI_CS_PIN);
    /* 入参可能早于SPI和ISR耗时，不能用它度量CS拉高后的间隔。
     * 下一次poll先用最新tick锚定并返回，再等待至少两个tick。
     * 两个整数毫秒tick包含至少一个完整毫秒，覆盖供应商ACK后的20us。 */
    wifi_async.transaction_guard_pending = 1;
    wifi_async.transaction_guard = 0;
    wifi_async.phase_since_ms = now_ms;
}

/* 头部显式使用小端编码，不依赖结构体布局、对齐或未初始化保留字节。 */
static void wifi_spi_async_header(uint8_t *header, uint8_t command, uint16_t length)
{
    header[0] = command;
    header[1] = 0;
    header[2] = (uint8_t)length;
    header[3] = (uint8_t)(length >> 8);
}

static uint16_t wifi_spi_async_reply_length(const uint8_t *header)
{
    return (uint16_t)((uint16_t)header[2] | ((uint16_t)header[3] << 8));
}

static void wifi_spi_async_write_command(uint32_t now_ms, uint8_t command,
                                          const uint8_t *payload, uint16_t length)
{
    uint8_t header[4];
    wifi_spi_async_header(header, command, length);
    gpio_low(WIFI_SPI_CS_PIN);
    spi_write_8bit_array(WIFI_SPI_INDEX, header, sizeof(header));
    spi_write_8bit_array(WIFI_SPI_INDEX, payload, length);
    wifi_spi_async_finish_transaction(now_ms);
}

static void wifi_spi_async_read_reply(uint32_t now_ms, uint8_t *reply, uint8_t *payload,
                                       uint16_t length)
{
    uint8_t header[4] = {WIFI_SPI_DATA, 0, 0, 0};
    uint8_t zeros[32] = {0};
    gpio_low(WIFI_SPI_CS_PIN);
    spi_transfer_8bit(WIFI_SPI_INDEX, header, reply, sizeof(header));
    if (length != 0)
        spi_transfer_8bit(WIFI_SPI_INDEX, zeros, payload, length);
    wifi_spi_async_finish_transaction(now_ms);
}

static void wifi_spi_async_check_received(uint32_t now_ms, const uint8_t *reply)
{
    /* 无效包的长度未定义，保持供应商忽略行为；只解释有效入站数据包。 */
    wifi_async.receive_pending = 0;
    if (reply[0] == WIFI_SPI_REPLY_DATA_START || reply[0] == WIFI_SPI_REPLY_DATA_END)
    {
        if (wifi_spi_async_reply_length(reply) > 32U)
            wifi_spi_async_fail(now_ms, WIFI_SPI_ASYNC_ERROR_RECEIVE);
        else
            wifi_async.receive_pending = (reply[0] == WIFI_SPI_REPLY_DATA_START);
    }
    else if (reply[0] == WIFI_SPI_REPLY_ERROR)
        wifi_spi_async_fail(now_ms, WIFI_SPI_ASYNC_ERROR_SEND);
}

static uint32_t wifi_spi_async_transfer(uint32_t now_ms, const uint8_t *data, uint32_t length)
{
    uint8_t header[4], reply[4], received[32], short_data[32] = {0};
    uint16_t count;
    if (wifi_async.receive_pending)
    {
        wifi_spi_async_read_reply(now_ms, reply, received, sizeof(received));
        wifi_spi_async_check_received(now_ms, reply);
        return 0;
    }
    count = (uint16_t)(length > WIFI_SPI_ASYNC_CHUNK_SIZE ? WIFI_SPI_ASYNC_CHUNK_SIZE : length);
    wifi_spi_async_header(header, WIFI_SPI_DATA, count);
    gpio_low(WIFI_SPI_CS_PIN);
    spi_transfer_8bit(WIFI_SPI_INDEX, header, reply, sizeof(header));
    if (count > 32U)
    {
        spi_transfer_8bit(WIFI_SPI_INDEX, data, received, sizeof(received));
        spi_write_8bit_array(WIFI_SPI_INDEX, data + 32, (uint32_t)count - 32U);
    }
    else
    {
        memcpy(short_data, data, count);
        spi_transfer_8bit(WIFI_SPI_INDEX, short_data, received, sizeof(received));
    }
    wifi_spi_async_finish_transaction(now_ms);
    wifi_spi_async_check_received(now_ms, reply);
    return count;
}

uint32_t wifi_spi_async_poll(uint32_t now_ms, const uint8_t *data, uint32_t length)
{
    uint8_t reply[4], received[32], request[32] = {WIFI_SPI_GET_VERSION};
    uint32_t timeout_ms;
    wifi_spi_async_error_phase_t phase;

    if (wifi_async.status.state == WIFI_SPI_ASYNC_DISABLED ||
        wifi_async.status.state == WIFI_SPI_ASYNC_CONFIG_ERROR) return 0;
    if (wifi_async.status.state == WIFI_SPI_ASYNC_BACKOFF)
    {
        if ((uint32_t)(now_ms - wifi_async.phase_since_ms) >= WIFI_SPI_ASYNC_BACKOFF_MS)
        {
            ++wifi_async.status.reconnect_count;
            wifi_spi_async_begin_reset(now_ms);
        }
        return 0;
    }
    if (wifi_async.step == WIFI_SPI_ASYNC_STEP_SETUP)
    {
        wifi_spi_async_begin_reset(now_ms);
        return 0;
    }
    if (wifi_async.step == WIFI_SPI_ASYNC_STEP_RESET_LOW)
    {
        if ((uint32_t)(now_ms - wifi_async.phase_since_ms) >= WIFI_SPI_ASYNC_RESET_LOW_MS)
        {
            gpio_set_level(WIFI_SPI_RST_PIN, 1);
            wifi_async.step = WIFI_SPI_ASYNC_STEP_BOOT_WAIT;
            wifi_async.phase_since_ms = now_ms;
        }
        return 0;
    }
    if (wifi_async.step == WIFI_SPI_ASYNC_STEP_BOOT_WAIT)
    {
        if ((uint32_t)(now_ms - wifi_async.phase_since_ms) >= WIFI_SPI_ASYNC_BOOT_WAIT_MS)
        {
            wifi_async.step = WIFI_SPI_ASYNC_STEP_VERSION_COMMAND;
            wifi_async.phase_since_ms = now_ms;
        }
        return 0;
    }
    if (wifi_async.transaction_guard_pending)
    {
        wifi_async.transaction_guard_since_ms = now_ms;
        wifi_async.transaction_guard_pending = 0;
        wifi_async.transaction_guard = 1;
        return 0;
    }
    if (wifi_async.transaction_guard)
    {
        if ((uint32_t)(now_ms - wifi_async.transaction_guard_since_ms) <
            WIFI_SPI_ASYNC_TRANSACTION_GUARD_MS) return 0;
        wifi_async.transaction_guard = 0;
    }

    if (wifi_async.status.state == WIFI_SPI_ASYNC_READY)
    {
        if (length == 0 && !wifi_async.receive_pending)
        {
            wifi_async.busy_waiting = 0;
            return 0;
        }
        if (length != 0 && data == NULL)
        {
            wifi_spi_async_fail(now_ms, WIFI_SPI_ASYNC_ERROR_SEND);
            return 0;
        }
        if (!gpio_get_level(WIFI_SPI_INT_PIN))
        {
            if (!wifi_async.busy_waiting)
            {
                wifi_async.busy_waiting = 1;
                wifi_async.busy_since_ms = now_ms;
            }
            else if ((uint32_t)(now_ms - wifi_async.busy_since_ms) >= WIFI_SPI_ASYNC_DATA_TIMEOUT_MS)
                wifi_spi_async_fail(now_ms, wifi_async.receive_pending ?
                                    WIFI_SPI_ASYNC_ERROR_RECEIVE : WIFI_SPI_ASYNC_ERROR_SEND);
            return 0;
        }
        wifi_async.busy_waiting = 0;
        return wifi_spi_async_transfer(now_ms, data, length);
    }

    timeout_ms = WIFI_SPI_ASYNC_VERSION_TIMEOUT_MS;
    phase = WIFI_SPI_ASYNC_ERROR_VERSION;
    if (wifi_async.status.state == WIFI_SPI_ASYNC_JOINING)
    {
        timeout_ms = WIFI_SPI_ASYNC_JOIN_TIMEOUT_MS;
        phase = WIFI_SPI_ASYNC_ERROR_WIFI;
    }
    else if (wifi_async.status.state == WIFI_SPI_ASYNC_CONNECTING)
    {
        timeout_ms = WIFI_SPI_ASYNC_SOCKET_TIMEOUT_MS;
        phase = WIFI_SPI_ASYNC_ERROR_SOCKET;
    }
    if (!gpio_get_level(WIFI_SPI_INT_PIN))
    {
        if ((uint32_t)(now_ms - wifi_async.phase_since_ms) >= timeout_ms)
            wifi_spi_async_fail(now_ms, phase);
        return 0;
    }
    switch (wifi_async.step)
    {
        case WIFI_SPI_ASYNC_STEP_VERSION_COMMAND:
            gpio_low(WIFI_SPI_CS_PIN);
            spi_write_8bit_array(WIFI_SPI_INDEX, request, sizeof(request));
            wifi_spi_async_finish_transaction(now_ms);
            wifi_async.step = WIFI_SPI_ASYNC_STEP_VERSION_REPLY;
            break;
        case WIFI_SPI_ASYNC_STEP_VERSION_REPLY:
            wifi_spi_async_read_reply(now_ms, reply, received, sizeof(received));
            if (reply[0] != WIFI_SPI_REPLY_VERSION || wifi_spi_async_reply_length(reply) == 0 ||
                wifi_spi_async_reply_length(reply) > sizeof(received))
                wifi_spi_async_fail(now_ms, WIFI_SPI_ASYNC_ERROR_VERSION);
            else
            {
                wifi_async.status.state = WIFI_SPI_ASYNC_JOINING;
                wifi_async.step = WIFI_SPI_ASYNC_STEP_WIFI_COMMAND;
            }
            break;
        case WIFI_SPI_ASYNC_STEP_WIFI_COMMAND:
            wifi_spi_async_write_command(now_ms, WIFI_SPI_SET_WIFI_INFORMATION,
                                          wifi_async.wifi_command, wifi_async.wifi_length);
            wifi_async.step = WIFI_SPI_ASYNC_STEP_WIFI_REPLY;
            break;
        case WIFI_SPI_ASYNC_STEP_SOCKET_COMMAND:
            wifi_spi_async_write_command(now_ms, WIFI_SPI_SET_SOCKET_INFORMATION,
                                          wifi_async.socket_command, wifi_async.socket_length);
            wifi_async.step = WIFI_SPI_ASYNC_STEP_SOCKET_REPLY;
            break;
        case WIFI_SPI_ASYNC_STEP_WIFI_REPLY:
        case WIFI_SPI_ASYNC_STEP_SOCKET_REPLY:
            wifi_spi_async_read_reply(now_ms, reply, received, 0);
            if (reply[0] != WIFI_SPI_REPLY_OK)
                wifi_spi_async_fail(now_ms, phase);
            else if (wifi_async.step == WIFI_SPI_ASYNC_STEP_WIFI_REPLY)
            {
                wifi_async.status.state = WIFI_SPI_ASYNC_CONNECTING;
                wifi_async.step = WIFI_SPI_ASYNC_STEP_SOCKET_COMMAND;
            }
            else
            {
                wifi_async.status.state = WIFI_SPI_ASYNC_READY;
                wifi_async.step = WIFI_SPI_ASYNC_STEP_DATA;
            }
            break;
        default:
            wifi_spi_async_fail(now_ms, phase);
            break;
    }
    return 0;
}

const wifi_spi_async_status_t *wifi_spi_async_get_status(void)
{
    return &wifi_async.status;
}
