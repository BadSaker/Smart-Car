#ifndef AUTOCAR_CAMERA_DEBUG_CONFIG_H
#define AUTOCAR_CAMERA_DEBUG_CONFIG_H

/* 逐飞助手1.2.7：Wi-Fi SPI加入热点，作为TCP客户端连接电脑服务器。
 * RT1064 V3.0主板P7接Wi-Fi SPI，P6接普通IPS200 SPI；不使用串口图传或心跳模式。 */
#define CAMERA_DEBUG_GRAY            0
#define CAMERA_DEBUG_BINARY          1
#define CAMERA_DEBUG_BOUNDARIES_ONLY 2
#ifndef CAMERA_DEBUG_ENABLED
#define CAMERA_DEBUG_ENABLED         1
#endif
#ifndef CAMERA_DEBUG_IMAGE_MODE
#define CAMERA_DEBUG_IMAGE_MODE      CAMERA_DEBUG_GRAY
#endif
/* 第一个处理帧入选，以后每N帧入选；屏幕始终显示当前原始灰度。 */
#ifndef CAMERA_DEBUG_FRAME_DIVIDER
#define CAMERA_DEBUG_FRAME_DIVIDER   1U
#endif

/* 本机网络凭据：不要复制密码到日志或共享报告。
 * 入网命令最多64字节，SSID与密码合计最多59字节；空密码表示开放热点。
 * 超时、重连和每轮分块长度在wifi_spi_async_config.h中配置。 */
#ifndef CAMERA_DEBUG_WIFI_SSID
#define CAMERA_DEBUG_WIFI_SSID "DESKTOP-AMQIB6T 7163"
#endif
#ifndef CAMERA_DEBUG_WIFI_PASSWORD
#define CAMERA_DEBUG_WIFI_PASSWORD "R1529k\\3"
#endif
#ifndef CAMERA_DEBUG_WIFI_SERVER_IP
#define CAMERA_DEBUG_WIFI_SERVER_IP "192.168.137.1"
#endif
#ifndef CAMERA_DEBUG_WIFI_SERVER_PORT
#define CAMERA_DEBUG_WIFI_SERVER_PORT "8080"
#endif
#ifndef CAMERA_DEBUG_WIFI_LOCAL_PORT
#define CAMERA_DEBUG_WIFI_LOCAL_PORT "0"
#endif

#if CAMERA_DEBUG_IMAGE_MODE < CAMERA_DEBUG_GRAY || CAMERA_DEBUG_IMAGE_MODE > CAMERA_DEBUG_BOUNDARIES_ONLY
#error "Unsupported camera debug image mode"
#endif
#if CAMERA_DEBUG_FRAME_DIVIDER < 1
#error "CAMERA_DEBUG_FRAME_DIVIDER must be at least 1"
#endif
#endif
