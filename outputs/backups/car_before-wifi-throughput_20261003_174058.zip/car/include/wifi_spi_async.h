#ifndef AUTOCAR_WIFI_SPI_ASYNC_H
#define AUTOCAR_WIFI_SPI_ASYNC_H

#include <stdint.h>

typedef enum
{
    WIFI_SPI_ASYNC_DISABLED = 0,
    WIFI_SPI_ASYNC_INITIALIZING,
    WIFI_SPI_ASYNC_JOINING,
    WIFI_SPI_ASYNC_CONNECTING,
    WIFI_SPI_ASYNC_READY,
    WIFI_SPI_ASYNC_BACKOFF,
    WIFI_SPI_ASYNC_CONFIG_ERROR
} wifi_spi_async_state_t;

typedef enum
{
    WIFI_SPI_ASYNC_ERROR_NONE = 0,
    WIFI_SPI_ASYNC_ERROR_CONFIG,
    WIFI_SPI_ASYNC_ERROR_VERSION,
    WIFI_SPI_ASYNC_ERROR_WIFI,
    WIFI_SPI_ASYNC_ERROR_SOCKET,
    WIFI_SPI_ASYNC_ERROR_SEND,
    WIFI_SPI_ASYNC_ERROR_RECEIVE
} wifi_spi_async_error_phase_t;

typedef struct
{
    wifi_spi_async_state_t state;
    uint32_t error_count;
    uint32_t reconnect_count;
    wifi_spi_async_error_phase_t last_error_phase;
} wifi_spi_async_status_t;

/* 仅在主循环调用。校验并复制参数，不操作外设、不等待；0为有效，1为配置错误。
 * 密码为NULL或空串表示开放热点；本地端口接受0或2048..65535。
 * 显式重新初始化会清零统计，自动重连保留累计统计。 */
uint8_t wifi_spi_async_init(const char *ssid, const char *password,
                          const char *ip, const char *port, const char *local_port);

/* 每圈主循环调用，不依赖摄像头；now_ms为每次调用时读取、分辨率1ms的可回绕计数。
 * 每次至多一笔CS事务、一次INT读取、最多1024字节发送；无就绪等待。
 * data在本次调用返回前须有效；未交出部分由调用者保留并在后续调用再次提供。
 * 返回本次经SPI交出的字节数，不表示PC已接收；还须检查状态以丢弃失败连接的半帧。
 * data=NULL且length=0仍推进握手、重连和已知剩余接收数据的丢弃。
 * 本模块独占Wi-Fi SPI接口，不能同时调用供应商wifi_spi_*通信函数。 */
uint32_t wifi_spi_async_poll(uint32_t now_ms, const uint8_t *data, uint32_t length);

/* 仅主循环读取；返回内部只读状态，下一次init/poll会更新内容。 */
const wifi_spi_async_status_t *wifi_spi_async_get_status(void);

#endif
