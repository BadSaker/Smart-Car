"""编译真实异步状态机，仅替换GPIO与SPI电气访问，检查每次轮询的预算。"""
from pathlib import Path
from datetime import datetime
import os
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[2]
SCRATCH = ROOT / 'tmp/wifi-async-tests'
COMPILER = os.environ.get('AUTOCAR_HOST_CC', r'D:\Xilinx\Vivado\2022.2\tps\mingw\6.2.0\win64.o\nt\bin\gcc.exe')
TYPES = '''#pragma once
#include <stdint.h>
#include <stddef.h>
typedef uint8_t uint8; typedef uint16_t uint16; typedef uint32_t uint32;
'''
PLATFORM = '''#pragma once
#include "zf_common_typedef.h"
#define SPI_1 1
#define SPI_MODE3 3
#define SPI1_SCK_D12 12
#define SPI1_MOSI_D14 14
#define SPI1_MISO_D15 15
#define SPI_CS_NULL 0
#define D13 13
#define B16 16
#define B17 17
#define GPO 1
#define GPI 0
#define GPO_PUSH_PULL 0
#define GPI_PULL_DOWN 0
int gpio_get_level(int);
void gpio_low(int); void gpio_high(int);
void gpio_init(int,int,int,int); void gpio_set_level(int,int);
void spi_init(int,int,uint32,int,int,int,int);
void spi_transfer_8bit(int,const uint8*,uint8*,uint32);
void spi_write_8bit_array(int,const uint8*,uint32);
'''


class WifiSpiAsyncTests(unittest.TestCase):
    def test_state_machine_and_poll_budget(self):
        stub = SCRATCH / 'include'
        stub.mkdir(parents=True, exist_ok=True)
        (stub / 'zf_common_typedef.h').write_text(TYPES, encoding='ascii')
        (stub / 'platform.h').write_text(PLATFORM, encoding='ascii')
        for header in ('zf_driver_gpio.h', 'zf_driver_spi.h'):
            (stub / header).write_text('#include "platform.h"\n', encoding='ascii')
        exe = SCRATCH / 'test_wifi_spi_async.exe'
        cmd = [COMPILER, '-std=c99', '-Wall', '-Wextra', '-Werror',
               '-I' + str(stub), '-I' + str(ROOT / 'car/include'),
               '-I' + str(ROOT / 'car/config'), '-I' + str(ROOT / 'car/library/zf_device'),
               str(ROOT / 'car/tests/test_wifi_spi_async.c'),
               str(ROOT / 'car/src/wifi_spi_async.c'), '-o', str(exe)]
        built = subprocess.run(cmd, capture_output=True, text=True,
                               encoding='utf-8', errors='replace')
        self.assertEqual(built.returncode, 0, built.stdout + built.stderr)
        scenarios = ('registration', 'configuration', 'handshake', 'open-network',
                     'reset-wrap', 'version-timeout', 'join-timeout', 'socket-timeout',
                     'send-timeout', 'chunks', 'short-padding', 'rx-budget',
                     'rx-invalid', 'ack-error', 'reconnect', 'version-ack-timeout',
                     'version-error', 'version-length', 'socket-ack-error', 'idle-reply',
                     'rx-timeout', 'no-frame-reconnect', 'send-error', 'null-data',
                     'copied-configuration', 'empty-no-timeout', 'guard-cross-tick',
                     'guard-long-isr', 'guard-wrap', 'guard-timeout-stability')
        results = []
        for scenario in scenarios:
            with self.subTest(scenario=scenario):
                ran = subprocess.run([str(exe), scenario], capture_output=True, text=True,
                                     encoding='utf-8', errors='replace', timeout=10)
                results.append(scenario + ': ' + str(ran.returncode) + '\n' + ran.stdout + ran.stderr)
                self.assertEqual(ran.returncode, 0, ran.stdout + ran.stderr)
        with (ROOT / 'logs/wifi-async-tests.log').open('a', encoding='utf-8') as log:
            log.write('\n' + datetime.now().astimezone().isoformat() + '\n')
            log.write('\n'.join(results))
        invalid_guard = subprocess.run(
            cmd[:-2] + ['-DWIFI_SPI_ASYNC_TRANSACTION_GUARD_MS=1',
                        '-o', str(SCRATCH / 'invalid_guard.exe')],
            capture_output=True, text=True, encoding='utf-8', errors='replace')
        self.assertNotEqual(invalid_guard.returncode, 0)
        self.assertIn('WIFI_SPI_ASYNC_TRANSACTION_GUARD_MS', invalid_guard.stderr)
        print(f'Executed {len(scenarios)} asynchronous Wi-Fi scenarios; see exit status and log.')


if __name__ == '__main__':
    unittest.main(verbosity=2)
