/* 用真实应用队列、屏幕适配和逐飞协议验证图传；只替换异步链路与电气接口。 */
#include "zf_common_headfile.h"
#include "camera_debug.h"
#include "camera_display.h"
#include "wifi_spi_async.h"
#include "servo_control.h"

static uint8 wire[100000], preview[MT9V03X_H * MT9V03X_W];
static uint8 gray[MT9V03X_H][MT9V03X_W], binary_image[MT9V03X_H][MT9V03X_W];
static uint8 left[MT9V03X_H], middle[MT9V03X_H], right[MT9V03X_H];
static wifi_spi_async_status_t link_status;
static servo_control_status_t servo_status;
static uint32 wire_length, preview_count, poll_calls, init_calls, display_dir_set;
static int busy, fail_next, invalid_return;
#define CHECK(x) do { if (!(x)) { printf("FAIL line %d: %s\n",__LINE__,#x); return 1; } } while (0)

uint8_t wifi_spi_async_init(const char *ssid,const char *password,const char *ip,const char *port,const char *local)
{
    ++init_calls;
    memset(&link_status,0,sizeof(link_status));
#ifdef TEST_INVALID_CONFIG
    (void)ssid; (void)password; (void)ip; (void)port; (void)local;
    link_status.state=WIFI_SPI_ASYNC_CONFIG_ERROR;
    link_status.error_count=1; link_status.last_error_phase=WIFI_SPI_ASYNC_ERROR_CONFIG;
    return 1;
#else
    assert(strcmp(ssid,"test-network")==0 && strcmp(password,"test-password")==0);
    assert(strcmp(ip,"192.168.1.2")==0 && strcmp(port,"8080")==0 && strcmp(local,"0")==0);
    link_status.state=WIFI_SPI_ASYNC_INITIALIZING;
    return 0;
#endif
}
const wifi_spi_async_status_t *wifi_spi_async_get_status(void) { return &link_status; }
uint32_t wifi_spi_async_poll(uint32_t now,const uint8_t *data,uint32_t length)
{
    uint32 n;
    (void)now; ++poll_calls;
    if (link_status.state!=WIFI_SPI_ASYNC_READY || busy || !length) return 0;
    assert(data);
    if (invalid_return) return length+1;
    n=length>257U?257U:length;
    if (fail_next) n=length>17U?17U:length;
    assert(wire_length+n<=sizeof(wire));
    memcpy(wire+wire_length,data,n); wire_length+=n;
    if (fail_next) {
        link_status.state=WIFI_SPI_ASYNC_BACKOFF;
        ++link_status.error_count;
        link_status.last_error_phase=fail_next==2?WIFI_SPI_ASYNC_ERROR_RECEIVE:WIFI_SPI_ASYNC_ERROR_SEND;
        fail_next=0;
    }
    return n;
}
/* 自定义协议回调不应触发这些旧同步传输接口。 */
#define NO_WRITER(name) uint32 name(const uint8 *p,uint32 n) { (void)p;(void)n;assert(0);return n; }
#define NO_READER(name) uint32 name(uint8 *p,uint32 n) { (void)p;(void)n;assert(0);return 0; }
NO_WRITER(debug_send_buffer) NO_WRITER(wifi_uart_send_buffer) NO_WRITER(wireless_uart_send_buffer)
NO_WRITER(bluetooth_ch9141_send_buffer) NO_WRITER(wifi_spi_send_buffer) NO_WRITER(ble6a20_send_buffer)
NO_READER(debug_read_ring_buffer) NO_READER(wifi_uart_read_buffer) NO_READER(wireless_uart_read_buffer)
NO_READER(bluetooth_ch9141_read_buffer) NO_READER(wifi_spi_read_buffer) NO_READER(ble6a20_read_buffer)
const servo_control_status_t *servo_control_get_status(void) { return &servo_status; }
void ips200_init(int kind) { assert(kind==IPS200_TYPE_SPI && display_dir_set); }
void ips200_set_dir(int dir) { assert(dir==IPS200_CROSSWISE || dir==IPS200_CROSSWISE_180);display_dir_set=1; }
void ips200_set_font(int f) { (void)f; }
void ips200_set_color(uint16 p,uint16 b) { (void)p;(void)b; }
void ips200_clear(void) {}
void ips200_show_string(uint16 x,uint16 y,const char *s) { assert(x+strlen(s)*8U<=320 && y+16<=240); }
void ips200_show_gray_image(uint16 x,uint16 y,const uint8 *p,uint16 w,uint16 h,uint16 dw,uint16 dh,uint8 threshold)
{
    assert(p && w==188 && h==120 && threshold==0);
    assert(x+dw<=320 && y+dh<=240 && (uint32)dw*h==(uint32)dh*w);
    ++preview_count;memcpy(preview,p,sizeof(preview));
}

static void prepare_pixels(void)
{
    uint32 i;
    for(i=0;i<sizeof(gray);++i) { ((uint8*)gray)[i]=(uint8)(i%251U);((uint8*)binary_image)[i]=(i&1U)?255:0; }
    for(i=0;i<120;++i) { left[i]=(uint8)(3+i%17);middle[i]=(uint8)(80+i%21);right[i]=(uint8)(170+i%17); }
}
static void drain_queue(uint32 stop_count)
{
    uint32 i;
    for(i=0;i<1000 && camera_debug_frames_sent<stop_count;++i) camera_debug_poll(1000+i);
    assert(camera_debug_frames_sent==stop_count);
}

int main(int argc,char **argv)
{
    uint32 i,n,expected_length,payload;
    uint8 result;
    int scenario=argc>1?atoi(argv[1]):0;
    uint8 image_header[]={0xaa,0x02,0x43,8,188,0,120,0};
    const uint8 dot_header[]={0xaa,0x03,0x03,8,120,0,7,0};
    camera_display_init();prepare_pixels();
    result=camera_debug_init(left,middle,right);
    CHECK(poll_calls==0 && wire_length==0);
#if !CAMERA_DEBUG_ENABLED
    CHECK(result==0 && init_calls==0);
    for(i=0;i<1000;++i) { gray[0][0]=(uint8)i;camera_debug_capture_frame(gray[0]);camera_debug_send_frame(binary_image[0]);camera_debug_poll(i); }
    CHECK(preview_count==1000 && preview[0]==(uint8)999 && poll_calls==0 && wire_length==0);
    puts("PASS: preview progresses with wireless disabled");return 0;
#elif defined(TEST_INVALID_CONFIG)
    CHECK(result!=0 && camera_debug_status==CAMERA_DEBUG_CONFIG_ERROR);
    for(i=0;i<1000;++i) { gray[0][0]=(uint8)i;camera_debug_capture_frame(gray[0]);camera_debug_send_frame(binary_image[0]);camera_debug_poll(i); }
    CHECK(preview_count==1000 && preview[0]==(uint8)999 && poll_calls==0 && wire_length==0);
    puts("PASS: invalid configuration cannot block local preview");return 0;
#else
    CHECK(result==0 && init_calls==1 && camera_debug_status==CAMERA_DEBUG_INITIALIZING);
#endif
    if(scenario==1) {
        for(i=0;i<1000;++i) {
            gray[0][0]=(uint8)i;
            link_status.state=(i<250)?WIFI_SPI_ASYNC_INITIALIZING:(i<500)?WIFI_SPI_ASYNC_JOINING:(i<750)?WIFI_SPI_ASYNC_CONNECTING:WIFI_SPI_ASYNC_BACKOFF;
            if(i==750) { link_status.error_count=1;link_status.last_error_phase=WIFI_SPI_ASYNC_ERROR_SOCKET; }
            camera_debug_capture_frame(gray[0]);camera_debug_send_frame(binary_image[0]);camera_debug_poll(i);
        }
        CHECK(preview_count==1000 && preview[0]==(uint8)999 && poll_calls==1000 && wire_length==0);
        CHECK(camera_debug_frames_sent==0 && camera_debug_error_count==1);
        puts("PASS: preview progresses through reset, joining, TCP wait and backoff");return 0;
    }
    link_status.state=WIFI_SPI_ASYNC_READY;camera_debug_poll(1);
    camera_debug_send_frame(binary_image[0]);CHECK(wire_length==0);
    camera_debug_capture_frame(gray[0]);CHECK(preview_count==1 && memcmp(preview,gray,sizeof(preview))==0);
    camera_debug_send_frame(binary_image[0]);CHECK(wire_length==0 && camera_debug_frames_sent==0);
#if CAMERA_DEBUG_IMAGE_MODE==CAMERA_DEBUG_BOUNDARIES_ONLY
    payload=0;image_header[2]=0x53;
#else
    payload=22560;
#endif
    expected_length=8+payload+8+360;
    /* 排队后同时修改图像和边线，旧帧必须保持原字节。 */
    memset(gray,0xee,sizeof(gray));memset(binary_image,0xee,sizeof(binary_image));
    memset(left,0xdd,sizeof(left));memset(middle,0xdd,sizeof(middle));memset(right,0xdd,sizeof(right));
    if(scenario==2) {
        busy=1;
        for(i=0;i<1000;++i) { gray[0][0]=(uint8)i;camera_debug_capture_frame(gray[0]);camera_debug_send_frame(binary_image[0]);camera_debug_poll(2+i); }
        CHECK(preview_count==1001 && preview[0]==(uint8)999 && wire_length==0 && camera_debug_frames_sent==0);
        busy=0;
    }
    if(scenario==3 || scenario==4) {
        camera_debug_poll(2);CHECK(wire_length==257);
        fail_next=scenario==4?2:1;camera_debug_poll(3);
        CHECK(camera_debug_frames_sent==0 && camera_debug_error_count==1 && camera_debug_last_remaining==expected_length-257);
        CHECK(camera_debug_last_error_stage==(scenario==4?CAMERA_DEBUG_STAGE_RECEIVE:CAMERA_DEBUG_STAGE_IMAGE));
        camera_debug_capture_frame(gray[0]);camera_debug_send_frame(binary_image[0]);
        n=wire_length;camera_debug_poll(4);CHECK(wire_length==n);
        link_status.state=WIFI_SPI_ASYNC_INITIALIZING;link_status.reconnect_count=1;wire_length=0;camera_debug_poll(5000);
        link_status.state=WIFI_SPI_ASYNC_READY;camera_debug_poll(6000);
        camera_debug_send_frame(binary_image[0]);camera_debug_poll(6001);CHECK(wire_length==0);
        camera_debug_capture_frame(gray[0]);camera_debug_send_frame(binary_image[0]);drain_queue(1);
        CHECK(wire_length==expected_length && memcmp(wire,image_header,8)==0);
        for(i=0;i<payload;++i) CHECK(wire[8+i]==0xee);
        CHECK(camera_debug_error_count==1 && camera_debug_reconnect_count==1);
        puts("PASS: failed partial frame is discarded before new TCP stream, including error after SPI write");return 0;
    }
    if(scenario==5) {
        invalid_return=1;camera_debug_poll(2);
        CHECK(camera_debug_status==CAMERA_DEBUG_CONFIG_ERROR && camera_debug_frames_sent==0);
        n=poll_calls;camera_debug_poll(1000);CHECK(poll_calls==n);
        camera_debug_capture_frame(gray[0]);CHECK(preview_count==2);
        puts("PASS: invalid transport return fails closed without stopping preview");return 0;
    }
    drain_queue(1);
    CHECK(wire_length==expected_length && memcmp(wire,image_header,8)==0);
    for(i=0;i<payload;++i) {
#if CAMERA_DEBUG_IMAGE_MODE==CAMERA_DEBUG_BINARY
        CHECK(wire[8+i]==((i&1U)?255:0));
#else
        CHECK(wire[8+i]==(uint8)(i%251U));
#endif
    }
    CHECK(memcmp(wire+8+payload,dot_header,8)==0);
    for(i=0;i<120;++i) { CHECK(wire[16+payload+i]==(uint8)(3+i%17));CHECK(wire[136+payload+i]==(uint8)(80+i%21));CHECK(wire[256+payload+i]==(uint8)(170+i%17)); }
    n=wire_length;camera_debug_send_frame(binary_image[0]);camera_debug_poll(9000);CHECK(wire_length==n);
#if CAMERA_DEBUG_FRAME_DIVIDER==2
    camera_debug_capture_frame(gray[0]);camera_debug_send_frame(binary_image[0]);camera_debug_poll(9001);CHECK(wire_length==n);
    camera_debug_capture_frame(gray[0]);camera_debug_send_frame(binary_image[0]);drain_queue(2);CHECK(wire_length==2*n);
#endif
    puts("PASS: stable complete protocol frame, preview priority, bounded draining and real boundary bytes");return 0;
}
