"""验证真实图像协议和应用队列，仅替换异步链路及屏幕电气接口。"""
from pathlib import Path
import argparse
import os
import shutil
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[2]
SCRATCH = ROOT / 'tmp/camera-debug-tests'
COMPILER = os.environ.get('AUTOCAR_HOST_CC', r'D:\Xilinx\Vivado\2022.2\tps\mingw\6.2.0\win64.o\nt\bin\gcc.exe')
TYPES = '''#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
typedef uint8_t uint8; typedef uint16_t uint16; typedef uint32_t uint32;
typedef int32_t int32; typedef volatile uint8 vuint8;
/* 主机PE链接器的弱符号规则不同，测试保留真实实现并采用普通链接。 */
#define ZF_WEAK
#define zf_assert(x) assert(x)
'''
PLATFORM = '''#pragma once
#include "zf_common_typedef.h"
#include "seekfree_assistant.h"
#include "seekfree_assistant_interface.h"
#define MT9V03X_W 188
#define MT9V03X_H 120
#define IPS200_TYPE_SPI 0
#define IPS200_CROSSWISE 2
#define IPS200_CROSSWISE_180 3
#define IPS200_8X16_FONT 1
#define RGB565_WHITE 0xffff
#define RGB565_BLACK 0
void ips200_init(int); void ips200_set_dir(int); void ips200_set_font(int);
void ips200_set_color(uint16,uint16); void ips200_clear(void);
void ips200_show_string(uint16,uint16,const char*);
void ips200_show_gray_image(uint16,uint16,const uint8*,uint16,uint16,uint16,uint16,uint8);
'''
SENDERS = ['debug_send_buffer','wifi_uart_send_buffer','wireless_uart_send_buffer',
           'bluetooth_ch9141_send_buffer','wifi_spi_send_buffer','ble6a20_send_buffer']
READERS = ['debug_read_ring_buffer','wifi_uart_read_buffer','wireless_uart_read_buffer',
           'bluetooth_ch9141_read_buffer','wifi_spi_read_buffer','ble6a20_read_buffer']
PLATFORM += '\n'.join('uint32 '+n+'(const uint8*,uint32);' for n in SENDERS)
PLATFORM += '\n' + '\n'.join('uint32 '+n+'(uint8*,uint32);' for n in READERS)
WIFI = ['CAMERA_DEBUG_WIFI_SSID="test-network"','CAMERA_DEBUG_WIFI_PASSWORD="test-password"',
        'CAMERA_DEBUG_WIFI_SERVER_IP="192.168.1.2"','CAMERA_DEBUG_WIFI_SERVER_PORT="8080"',
        'CAMERA_DEBUG_WIFI_LOCAL_PORT="0"']
PROFILES = {'spi-gray':WIFI,'spi-binary':WIFI+['CAMERA_DEBUG_IMAGE_MODE=1'],
            'spi-boundaries':WIFI+['CAMERA_DEBUG_IMAGE_MODE=2'],
            'spi-decimated':WIFI+['CAMERA_DEBUG_FRAME_DIVIDER=2'],
            'invalid-config':WIFI+['TEST_INVALID_CONFIG=1'],
            'disabled':['CAMERA_DEBUG_ENABLED=0']}
SELECTED = None

class CameraDebugTests(unittest.TestCase):
    def test_protocol_profiles(self):
        stub=SCRATCH/'include';stub.mkdir(parents=True,exist_ok=True)
        (stub/'zf_common_typedef.h').write_text(TYPES,encoding='utf-8')
        (stub/'camera_platform.h').write_text(PLATFORM,encoding='utf-8')
        for name in ['zf_common_headfile.h','zf_common_debug.h','zf_driver_uart.h',
                     'zf_device_wireless_uart.h','zf_device_bluetooth_ch9141.h',
                     'zf_device_wifi_uart.h','zf_device_wifi_spi.h','zf_device_ble6a20.h']:
            (stub/name).write_text('#include "camera_platform.h"\n',encoding='utf-8')
        shutil.copy2(ROOT/'car/library/zf_common/zf_common_fifo.h',stub/'zf_common_fifo.h')
        shutil.copy2(ROOT/'car/library/zf_common/zf_common_fifo.c',SCRATCH/'zf_common_fifo.c')
        profiles=PROFILES if not SELECTED else {SELECTED:PROFILES[SELECTED]}
        for name,definitions in profiles.items():
            with self.subTest(profile=name):
                exe=SCRATCH/(name+'.exe')
                cmd=[COMPILER,'-std=c99','-Wall','-Wextra','-Werror','-Wno-unused-parameter',
                     '-ffunction-sections','-fdata-sections','-Wl,--gc-sections',
                     '-I'+str(stub),'-I'+str(ROOT/'car/include'),'-I'+str(ROOT/'car/config'),
                     '-I'+str(ROOT/'car/library/zf_components')]
                cmd+=['-D'+d for d in definitions]
                cmd+=[str(ROOT/p) for p in ['car/tests/test_camera_debug.c','car/src/camera_debug.c',
                      'car/src/camera_display.c','car/library/zf_components/seekfree_assistant.c',
                      'car/library/zf_components/seekfree_assistant_interface.c']]
                cmd+=[str(SCRATCH/'zf_common_fifo.c'),'-o',str(exe)]
                built=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace')
                self.assertEqual(built.returncode,0,built.stdout+built.stderr)
                scenarios=range(6) if name=='spi-gray' else [0]
                for scenario in scenarios:
                    ran=subprocess.run([str(exe),str(scenario)],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=10)
                    self.assertEqual(ran.returncode,0,f'{name}/{scenario}: '+ran.stdout+ran.stderr)
                    print(f'{name}/{scenario}: '+ran.stdout.strip())

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--profile',choices=PROFILES)
    options,remaining=parser.parse_known_args();SELECTED=options.profile
    unittest.main(argv=[__file__]+remaining,verbosity=2)
