from pathlib import Path
import re,json,hashlib
root=Path(__file__).resolve().parents[2]
for p in (root/'simulation/tools/history').glob('*.py'):
    text=p.read_text(encoding='utf-8').replace('Path(__file__).resolve().parents[1]','Path(__file__).resolve().parents[2]')
    p.write_text(text,encoding='utf-8')
for name in ('check_camera_alignment.py','check_camera_ui.py'):
    p=root/'simulation/tools'/name
    text=p.read_text(encoding='utf-8').replace("ROOT.parent/'tmp/figs'","ROOT/'assets/measurements'")
    p.write_text(text,encoding='utf-8')
p=root/'simulation/docs/control-tuning.md'
text=p.read_text(encoding='utf-8').replace('`vendor/`与`../../car/`的算法及配置一致','算法统一读取`../../car/`，验收输出独立源码快照').replace("& 'D:\\anaconda3\\python.exe'",'python')
p.write_text(text,encoding='utf-8')
p=root/'docs/autonomous-driving.md'
text=p.read_text(encoding='utf-8').replace('[Autodrive.rar](../../Autodrive.rar)','Autodrive.rar（历史输入压缩包，当前工作区未附带）')
p.write_text(text,encoding='utf-8')
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'simulation/assets/measurements').glob('*.png')}
original={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'tmp/figs').glob('*.png')}
assert manifest==original and len(manifest)==8
(root/'simulation/assets/measurements/manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('Historical paths updated; eight original measurement images preserved byte-for-byte.')
