from pathlib import Path
import json,re,shutil
ROOT=Path(__file__).resolve().parents[2]
config=ROOT/'car/config/camera_debug_config.h'
text=config.read_text(encoding='utf-8')
names=('SSID','PASSWORD','SERVER_IP','SERVER_PORT','LOCAL_PORT')
definitions=[]
for name in names:
    match=re.search(r'^#define CAMERA_DEBUG_WIFI_'+name+r'\s+(.+)$',text,re.M)
    definitions.append('#define CAMERA_DEBUG_WIFI_'+name+' '+match[1])
local=ROOT/'car/config/camera_debug_local.h'
if not local.exists():local.write_text('#ifndef AUTOCAR_CAMERA_DEBUG_LOCAL_H\n#define AUTOCAR_CAMERA_DEBUG_LOCAL_H\n'+'\n'.join(definitions)+'\n#endif\n',encoding='utf-8')
start=text.index('/* 本机网络凭据')
end=text.index('/* 只重试',start)
replacement='''/* 本机凭据由configure-wifi.ps1生成；测试可显式覆盖全部网络宏。 */
#if CAMERA_DEBUG_ENABLED && !defined(CAMERA_DEBUG_WIFI_SSID)
#include "camera_debug_local.h"
#endif
#ifndef CAMERA_DEBUG_WIFI_SSID
#define CAMERA_DEBUG_WIFI_SSID ""
#endif
#ifndef CAMERA_DEBUG_WIFI_PASSWORD
#define CAMERA_DEBUG_WIFI_PASSWORD ""
#endif
#ifndef CAMERA_DEBUG_WIFI_SERVER_IP
#define CAMERA_DEBUG_WIFI_SERVER_IP ""
#endif
#ifndef CAMERA_DEBUG_WIFI_SERVER_PORT
#define CAMERA_DEBUG_WIFI_SERVER_PORT "8080"
#endif
#ifndef CAMERA_DEBUG_WIFI_LOCAL_PORT
#define CAMERA_DEBUG_WIFI_LOCAL_PORT "0"
#endif

'''
config.write_text(text[:start]+replacement+text[end:],encoding='utf-8')
editor=ROOT/'car/.vscode/c_cpp_properties.json'
data=json.loads(editor.read_text(encoding='utf-8'))
for c in data['configurations']:
    c['includePath']=[re.sub(r'^c:\\Users\\Lynn\\Desktop\\Files\\Autodrive\\car',lambda _: '${workspaceFolder}',p,flags=re.I).replace('\\','/') for p in c['includePath'] if not p.lower().startswith('d:\\keil')]
    c['compilerPath']='${env:AUTOCAR_ARM_CC}'
editor.write_text(json.dumps(data,ensure_ascii=False,indent=4)+'\n',encoding='utf-8')
for p in (ROOT/'docs').rglob('*.md'):
    text=p.read_text(encoding='utf-8')
    # Correct all relative links to the verified sibling source repository.
    text=re.sub(r'(?<=\()(?P<prefix>(?:\.\./)+)SeekFree(?=[/\)])',lambda m:'../'+m[0],text)
    text=text.replace('C:\\Users\\Lynn\\Desktop\\Files\\Autodrive','<项目根目录>')
    p.write_text(text,encoding='utf-8')
for p in (ROOT/'car/tests').glob('test_*.py'):
    text=p.read_text(encoding='utf-8')
    if 'AUTOCAR_HOST_CC' in text:
        text=re.sub(r'os\.environ\.get\(\s*[\'"]AUTOCAR_HOST_CC[\'"]\s*,\s*r?[\'"]D:\\Xilinx\\Vivado\\2022\.2\\tps\\mingw\\6\.2\.0\\win64\.o\\nt\\bin\\gcc\.exe[\'"]\s*,?\s*\)', 'find_compiler()',text)
        if 'find_compiler()' in text:
            text='from host_toolchain import find_compiler\n'+text
            p.write_text(text,encoding='utf-8')
# Preserve old diagnostics as versioned history rather than current acceptance commands.
historical=('check_ui_120.py','check_parameter_workflow.py','check_diagnostics_comparison.py','check_c1_model.py','check_independent_gcc.py','benchmark_event_loop.py','check_render_performance.py','check_viewport_culling.py','capture_chat.py')
archive=ROOT/'simulation/tools/history';archive.mkdir(exist_ok=True)
for name in historical:
    src=ROOT/'simulation/tools'/name
    if src.exists():
        content=src.read_text(encoding='utf-8').replace('Path(__file__).resolve().parents[1]','Path(__file__).resolve().parents[2]')
        (archive/name).write_text(content,encoding='utf-8');src.unlink()
docs=ROOT/'simulation/docs'
archive=docs/'archive';archive.mkdir(exist_ok=True)
for p in docs.iterdir():
    if p.is_file() and p.name not in ('camera-alignment.md','control-tuning.md'):
        if p.suffix=='.md':
            text=p.read_text(encoding='utf-8')
            text=re.sub(r'(?<=\()(?P<t>[^)]+)(?=\))',lambda m: m[0] if m[0].startswith(('http','https','#')) else '../'+m[0],text)
            (archive/p.name).write_text(text,encoding='utf-8');p.unlink()
        else:shutil.move(str(p),str(archive/p.name))
materials=ROOT/'simulation/assets/measurements';materials.mkdir(exist_ok=True)
for p in (ROOT/'tmp/figs').glob('*.png'):
    shutil.copy2(p,materials/p.name)
print('Mechanical migration complete; credentials were not printed.')
