from pathlib import Path
import sys,os,json
import numpy as np
task=Path(__file__).resolve().parent
root=task.parents[1]
mode=sys.argv[1]
source=task/'baseline' if mode=='before' else root/'simulation'
sys.path.insert(0,str(source))
from parameters import defaults
from engine import Simulation
outputs=[]
for scenario,direction in [('straight','A→B'),('full','A→B'),('full','B→A')]:
    p=defaults();p.update(scenario=scenario,direction=direction)
    s=Simulation(p);s.started=True
    for _ in range(1200):
        s.tick();outputs.append(np.r_[s.data,s.rows.ravel(),s.x,s.y,s.h,s.v])
values=np.array(outputs)
if mode=='before':np.save(task/'native-baseline.npy',values)
else:
    expected=np.load(task/'native-baseline.npy')
    assert np.array_equal(expected,values),'Native or model output changed'
print(json.dumps({'mode':mode,'ticks':len(values),'fields':values.shape[1],'identical':mode=='after'}))
