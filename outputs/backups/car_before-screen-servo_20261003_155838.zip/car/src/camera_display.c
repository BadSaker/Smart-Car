#include "zf_common_headfile.h"
#include "board_config.h"
#include "camera_display.h"

#if APP_ENABLE_IPS200
static int previous_network_status = -1;
static void display_line(uint16 y, const char *text)
{
    char line[40];
    /* 39 characters at 8 pixels fit the 320-pixel landscape screen. */
    snprintf(line, sizeof(line), "%-39.39s", text);
    ips200_show_string(0, y, line);
}
#endif

void camera_display_init(void)
{
#if APP_ENABLE_IPS200
    /* The driver writes MADCTL during init, so set orientation first. */
    ips200_set_dir(APP_IPS200_DIRECTION);
    ips200_init(IPS200_TYPE_SPI);
    ips200_set_font(IPS200_8X16_FONT);
    ips200_set_color(RGB565_WHITE, RGB565_BLACK);
    ips200_clear();
    previous_network_status = -1;
    display_line(0, "MT9V034 GRAY 188x120");
    camera_display_message("Camera initializing...");
    display_line(224, "Wi-Fi not started");
#endif
}

void camera_display_message(const char *text)
{
#if APP_ENABLE_IPS200
    if (text != NULL) display_line(16, text);
#else
    (void)text;
#endif
}

void camera_display_network_status(camera_debug_status_t status)
{
#if APP_ENABLE_IPS200
    const char *text;
    char details[40];
    if ((int)status == previous_network_status) return;
    previous_network_status = (int)status;
    switch (status)
    {
        case CAMERA_DEBUG_READY:         text = "Wi-Fi TCP ready"; break;
        case CAMERA_DEBUG_CONFIG_ERROR:  text = "Wi-Fi: check network config"; break;
        case CAMERA_DEBUG_INIT_ERROR:    text = "Wi-Fi failed; waiting to reconnect"; break;
        case CAMERA_DEBUG_CONNECT_ERROR: text = "TCP failed; waiting to reconnect"; break;
        case CAMERA_DEBUG_INITIALIZING:  text = "Wi-Fi initializing / reconnecting"; break;
        case CAMERA_DEBUG_CONNECTING:    text = "TCP connecting to PC..."; break;
        case CAMERA_DEBUG_SEND_ERROR:
        {
            const char *part;
            switch (camera_debug_last_error_stage)
            {
                case CAMERA_DEBUG_STAGE_IMAGE_HEADER:    part = "head"; break;
                case CAMERA_DEBUG_STAGE_IMAGE:           part = "image"; break;
                case CAMERA_DEBUG_STAGE_BOUNDARY_HEADER: part = "b-head"; break;
                case CAMERA_DEBUG_STAGE_LEFT:            part = "left"; break;
                case CAMERA_DEBUG_STAGE_MIDDLE:          part = "middle"; break;
                case CAMERA_DEBUG_STAGE_RIGHT:           part = "right"; break;
                default:                                part = "unknown"; break;
            }
            snprintf(details, sizeof(details), "TX %s rem:%lu; reconnect", part,
                     (unsigned long)camera_debug_last_remaining);
            text = details;
        }break;
        default:                        text = "Wi-Fi output disabled"; break;
    }
    display_line(224, text);
#else
    (void)status;
#endif
}

void camera_display_statistics(void)
{
#if APP_ENABLE_IPS200
    char text[40];
    /* Even three maximum uint32 values fit the 39-character line. */
    snprintf(text, sizeof(text), "TX:%lu E:%lu R:%lu",
             (unsigned long)camera_debug_frames_sent,
             (unsigned long)camera_debug_error_count,
             (unsigned long)camera_debug_reconnect_count);
    display_line(0, text);
#endif
}

void camera_display_frame(const uint8_t *gray_image)
{
#if APP_ENABLE_IPS200
    if (gray_image != NULL)
        ips200_show_gray_image(19, 40, gray_image, MT9V03X_W, MT9V03X_H, 282, 180, 0);
#else
    (void)gray_image;
#endif
}
