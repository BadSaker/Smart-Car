#include "main.h" // 硬件参数在 config/board_config.h 中配置

/* Adapted from 参考/镜头组例程.zip for the confirmed C-chassis hardware.
 * Enables camera processing and 10 ms encoder sampling.
 * Screen, motor output and steering output are controlled by board_config.h.
 * Verify wiring, forward encoder signs and steering limits before enabling motion.
 * IPS200 SPI and Wi-Fi SPI show matching grayscale frames; no race stop logic yet.
 */

// 舵机动作角度中值
const float servo_motor_duty_middle = (SERVO_MOTOR_R_MAX + SERVO_MOTOR_L_MAX) / 2.f; 

uint8_t image[MT9V03X_H][MT9V03X_W];
short hist_gram[256];
uint8_t left_line[MT9V03X_H];
uint8_t mid_line[MT9V03X_H];
uint8_t right_line[MT9V03X_H];

static void app_init(void)
{

    camera_display_init();
    while (mt9v03x_init())
    {
        camera_display_message("Camera init failed; check CSI/power");
        system_delay_ms(1000);
    }
    camera_display_message("Camera ready");
    (void)camera_debug_init(left_line, mid_line, right_line);
    camera_display_message("PC " CAMERA_DEBUG_WIFI_SERVER_IP ":" CAMERA_DEBUG_WIFI_SERVER_PORT);

    // 编码器初始化
    encoder_quad_init(ENCODER_1, ENCODER_1_A, ENCODER_1_B); // 初始化编码器模块与引脚 正交解码编码器模式
    encoder_quad_init(ENCODER_2, ENCODER_2_A, ENCODER_2_B); // 初始化编码器模块与引脚 正交解码编码器模式

    // 电机初始化
    pwm_init(MOTOR1_PWM, 17000, 0); // PWM 通道初始化频率 17KHz 占空比初始为 0
    gpio_init(MOTOR1_DIR, GPO, GPIO_HIGH, GPO_PUSH_PULL); // GPIO 初始化为输出 默认上拉输出高
    pwm_init(MOTOR2_PWM, 17000, 0); // PWM 通道初始化频率 17KHz 占空比初始为 0
    gpio_init(MOTOR2_DIR, GPO, GPIO_HIGH, GPO_PUSH_PULL); // GPIO 初始化为输出 默认上拉输出高

    // 舵机
    pwm_init(SERVO_MOTOR_PWM, SERVO_MOTOR_FREQ, 0);

    // PID初始化
    My_Pid_Init();

    // 定时器0初始化，10ms可调
    pit_ms_init(PIT_CH0, APP_CONTROL_PERIOD_MS);
}

int main(void)
{
    clock_init(SYSTEM_CLOCK_600M); // 不可删除
    debug_init();                  // 调试端口初始化
    system_delay_ms(300);          // 等待主板其他外设上电完成

    app_init();
    interrupt_global_enable(0);

    while (1)
    {
        camera_debug_poll(app_uptime_ms);
        //  mt9v03x摄像头
        if (mt9v03x_finish_flag)
        {
            /* Acknowledge before copying so a later completed frame stays pending.
             * Use the vendor completed buffer only for this short snapshot. Both
             * display and Wi-Fi consume application-owned memory afterwards. */
            mt9v03x_finish_flag = 0;
            memcpy(image[0], mt9v03x_image[0], sizeof(image));
            camera_debug_capture_frame(image[0]);
            // 获取直方图
            get_hist_gram((uint8_t *)image, MT9V03X_H, MT9V03X_W, hist_gram);
            unsigned char threshold = get_threshold_otsu(hist_gram);
            // 二值化处理
            binaryzation_process((uint8_t *)image, MT9V03X_H, MT9V03X_W, threshold);
            // 边界线寻找
            auxiliary_process((uint8_t *)image, MT9V03X_H, MT9V03X_W, 127, left_line, mid_line, right_line);

            // 取图像下1/4处做误差判断
            float mid_err = (MT9V03X_W/2) - mid_line[MT9V03X_H-MT9V03X_H/4];
            // 舵机根据误差乘以系数打角
            float tmp_duty = servo_motor_duty_middle - mid_err * 0.5 * SERVO_DIR;
            // 限幅
            tmp_duty = MAX(tmp_duty,MIN(SERVO_MOTOR_L_MAX,SERVO_MOTOR_R_MAX));
            tmp_duty = MIN(tmp_duty,MAX(SERVO_MOTOR_L_MAX,SERVO_MOTOR_R_MAX));
#if APP_ENABLE_SERVO_OUTPUT
            pwm_set_duty(SERVO_MOTOR_PWM, (uint32)SERVO_MOTOR_DUTY(tmp_duty));
#else
            (void)tmp_duty;
#endif

            /* Send the matching raw/binary image and computed X boundaries.
             * Keep blocking communication out of the 10 ms PIT interrupt. */
            camera_debug_send_frame(image[0]);


        }
    }
}
