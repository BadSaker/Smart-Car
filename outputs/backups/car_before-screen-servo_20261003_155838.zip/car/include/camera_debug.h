#ifndef AUTOCAR_CAMERA_DEBUG_H
#define AUTOCAR_CAMERA_DEBUG_H

#include <stdint.h>
#include "camera_debug_config.h"

typedef enum
{
    CAMERA_DEBUG_DISABLED,
    CAMERA_DEBUG_READY,
    CAMERA_DEBUG_CONFIG_ERROR,
    CAMERA_DEBUG_INIT_ERROR,
    CAMERA_DEBUG_CONNECT_ERROR,
    CAMERA_DEBUG_SEND_ERROR,
    CAMERA_DEBUG_INITIALIZING,
    CAMERA_DEBUG_CONNECTING
} camera_debug_status_t;

typedef enum
{
    CAMERA_DEBUG_STAGE_NONE,
    CAMERA_DEBUG_STAGE_CONFIG,
    CAMERA_DEBUG_STAGE_WIFI,
    CAMERA_DEBUG_STAGE_TCP,
    CAMERA_DEBUG_STAGE_IMAGE_HEADER,
    CAMERA_DEBUG_STAGE_IMAGE,
    CAMERA_DEBUG_STAGE_BOUNDARY_HEADER,
    CAMERA_DEBUG_STAGE_LEFT,
    CAMERA_DEBUG_STAGE_MIDDLE,
    CAMERA_DEBUG_STAGE_RIGHT
} camera_debug_stage_t;

extern volatile camera_debug_status_t camera_debug_status;
extern volatile uint32_t camera_debug_frames_sent;
extern volatile uint32_t camera_debug_error_count;
extern volatile uint32_t camera_debug_send_retry_count;
extern volatile uint32_t camera_debug_reconnect_count;
extern volatile camera_debug_stage_t camera_debug_last_error_stage;
extern volatile uint32_t camera_debug_last_remaining;

/* 0 = initialized (or intentionally disabled); nonzero = failure.
 * Boundary arrays must remain valid and contain one X coordinate per image row. */
uint8_t camera_debug_init(uint8_t *left, uint8_t *middle, uint8_t *right);
/* Call on every main-loop iteration, including when no camera frame arrives.
 * now_ms is a monotonic uint32 millisecond clock; wraparound is supported.
 * Recovery uses the vendor's synchronous APIs and can pause the main loop.
 * Error -> wait interval -> close/reset module -> fresh TCP connection. */
void camera_debug_poll(uint32_t now_ms);
/* Main-loop only: display raw grayscale and capture a wireless snapshot before
 * modifying it. Local preview also works with a failed/disabled network. */
void camera_debug_capture_frame(const uint8_t *gray_image);
/* Main-loop only, after line extraction and before drawing into the image.
 * Binary view uses one GRAY byte per pixel (0/255), not packed 1-bit pixels.
 * Transmission blocks. Partial writes retry only the remaining suffix. A failed
 * frame is discarded; poll reconnects before any later frame can be sent. */
void camera_debug_send_frame(const uint8_t *binary_image);

#endif
