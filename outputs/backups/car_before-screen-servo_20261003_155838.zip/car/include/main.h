#ifndef AUTOCAR_MAIN_H
#define AUTOCAR_MAIN_H

#include "zf_common_headfile.h"
#include "board_config.h"
#include "img_process.h"
#include "pid.h"
#include "isr.h"
#include "camera_debug.h"
#include "camera_display.h"

extern volatile int16 encoder_data_1;
extern volatile int16 encoder_data_2;
extern volatile uint32_t app_uptime_ms;

#endif
