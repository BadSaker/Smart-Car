#ifndef AUTOCAR_CAMERA_DEBUG_CONFIG_H
#define AUTOCAR_CAMERA_DEBUG_CONFIG_H

/* SeekFree Assistant 1.2.7: Wi-Fi SPI STA/TCP client -> PC TCP server.
 * RT1064 V3.0: Wi-Fi SPI on P7, ordinary IPS200 SPI on P6.
 * No UART image transport or heartbeat diagnostic mode. */
#define CAMERA_DEBUG_GRAY            0
#define CAMERA_DEBUG_BINARY          1
#define CAMERA_DEBUG_BOUNDARIES_ONLY 2
#ifndef CAMERA_DEBUG_ENABLED
#define CAMERA_DEBUG_ENABLED         1
#endif
#ifndef CAMERA_DEBUG_IMAGE_MODE
#define CAMERA_DEBUG_IMAGE_MODE      CAMERA_DEBUG_GRAY
#endif
/* Send the first frame, then every Nth processed frame. Screen stays grayscale. */
#ifndef CAMERA_DEBUG_FRAME_DIVIDER
#define CAMERA_DEBUG_FRAME_DIVIDER   1U
#endif

/* Local credentials: do not copy passwords into logs or shared reports.
 * Vendor's 64-byte command buffer requires SSID + password <= 59 bytes.
 * Empty password means an open network. Start the PC listener before reset. */
#ifndef CAMERA_DEBUG_WIFI_SSID
#define CAMERA_DEBUG_WIFI_SSID "DESKTOP-AMQIB6T 7163"
#endif
#ifndef CAMERA_DEBUG_WIFI_PASSWORD
#define CAMERA_DEBUG_WIFI_PASSWORD "R1529k\\3"
#endif
#ifndef CAMERA_DEBUG_WIFI_SERVER_IP
#define CAMERA_DEBUG_WIFI_SERVER_IP "192.168.137.1"
#endif
#ifndef CAMERA_DEBUG_WIFI_SERVER_PORT
#define CAMERA_DEBUG_WIFI_SERVER_PORT "8080"
#endif
#ifndef CAMERA_DEBUG_WIFI_LOCAL_PORT
#define CAMERA_DEBUG_WIFI_LOCAL_PORT "0"
#endif

/* Retry only the unsent suffix of the current protocol block. */
#ifndef CAMERA_DEBUG_SEND_RETRY_LIMIT
#define CAMERA_DEBUG_SEND_RETRY_LIMIT 2U
#endif
#ifndef CAMERA_DEBUG_SEND_RETRY_DELAY_MS
#define CAMERA_DEBUG_SEND_RETRY_DELAY_MS 20U
#endif
/* Interval starts after the failed call returns, not at its start. */
#ifndef CAMERA_DEBUG_RECONNECT_INTERVAL_MS
#define CAMERA_DEBUG_RECONNECT_INTERVAL_MS 5000U
#endif
#if CAMERA_DEBUG_SEND_RETRY_LIMIT < 0 || CAMERA_DEBUG_SEND_RETRY_LIMIT > 10
#error "Send retry limit must be between 0 and 10"
#endif
#if CAMERA_DEBUG_SEND_RETRY_DELAY_MS < 1 || CAMERA_DEBUG_SEND_RETRY_DELAY_MS > 1000
#error "Send retry delay must be between 1 and 1000 ms"
#endif
#if CAMERA_DEBUG_RECONNECT_INTERVAL_MS < 1000 || CAMERA_DEBUG_RECONNECT_INTERVAL_MS > 60000
#error "Reconnect interval must be between 1000 and 60000 ms"
#endif

#if CAMERA_DEBUG_IMAGE_MODE < CAMERA_DEBUG_GRAY || CAMERA_DEBUG_IMAGE_MODE > CAMERA_DEBUG_BOUNDARIES_ONLY
#error "Unsupported camera debug image mode"
#endif
#if CAMERA_DEBUG_FRAME_DIVIDER < 1
#error "CAMERA_DEBUG_FRAME_DIVIDER must be at least 1"
#endif
#endif
