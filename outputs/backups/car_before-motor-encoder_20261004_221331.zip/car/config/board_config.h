#ifndef AUTOCAR_BOARD_CONFIG_H
#define AUTOCAR_BOARD_CONFIG_H

/* C车模、逐飞RT1064 V3.0、MT9V034、普通IPS200 SPI和Wi-Fi SPI。
 * 电机默认不输出；舵机1由servo_config.h和独立测试模块管理。
 * 编码器接线、方向以及实际机械中位仍需按实物核对。 */
#ifndef APP_ENABLE_IPS200
#define APP_ENABLE_IPS200          (1)
#endif
#define APP_IPS200_DIRECTION       IPS200_CROSSWISE
#define APP_ENABLE_MOTOR_OUTPUT    (0)
#define APP_CONTROL_PERIOD_MS     (10)
#define APP_SYSTEM_TICK_MS        (1U)
#if APP_SYSTEM_TICK_MS != 1U
#error "异步SPI保护间隔要求1ms时间基准"
#endif
#define APP_CONTROL_PERIOD_S      ((float)APP_CONTROL_PERIOD_MS / 1000.0f)
#define APP_ENCODER_LEFT_SIGN     (-1)
#define APP_ENCODER_RIGHT_SIGN    (1)
#define APP_ENCODER_LINES         (1024U)



// 编码器引脚信息
// 前进计数应为正；实际方向通过上方 APP_ENCODER_LEFT_SIGN/RIGHT_SIGN 标定。
// 左轮编码器
#define ENCODER_1 (QTIMER1_ENCODER1)
#define ENCODER_1_A (QTIMER1_ENCODER1_CH1_C0)
#define ENCODER_1_B (QTIMER1_ENCODER1_CH2_C1)
// 右轮编码器
#define ENCODER_2 (QTIMER1_ENCODER2)
#define ENCODER_2_A (QTIMER1_ENCODER2_CH1_C2)
#define ENCODER_2_B (QTIMER1_ENCODER2_CH2_C24)

// 电机参数设置
// !!! 请确保dir和pwm脚不要弄反了，否则电机会疯转 !!!
// 左轮电机
#define MOTOR1_PWM (PWM2_MODULE0_CHA_C6)
#define MOTOR1_DIR (C7)
// 左电机前进需要的DIR脚的电平 (GPIO_HIGH or GPIO_LOW) 请自行测试
#define MOTOR1_FORWARD_DIR_LEVEL (GPIO_HIGH)
// 右轮电机
#define MOTOR2_PWM (PWM2_MODULE1_CHA_C8)
#define MOTOR2_DIR (C9)
// 右电机前进需要的DIR脚的电平 (GPIO_HIGH or GPIO_LOW) 请自行测试
#define MOTOR2_FORWARD_DIR_LEVEL (GPIO_HIGH)


/* 舵机接口1的信号、脉宽和按键测试参数统一在servo_config.h维护。
 * 不再使用旧参考程序的角度到0.5–2.5ms全行程换算。 */

#endif /* AUTOCAR_BOARD_CONFIG_H */
