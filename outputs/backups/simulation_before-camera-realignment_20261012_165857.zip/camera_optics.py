"""Shared camera pose for ground sampling, calibration and scene frustum.
Body axes: forward +x, left +y, up +z. Positive yaw points left.
Positive roll rotates the camera right basis toward its down basis.
"""
import math
import numpy as np

def basis(p):
    t=math.radians(p['pitch']);a=math.radians(p.get('camera_yaw',0));r=math.radians(p.get('camera_roll',0))
    forward=np.array([math.cos(t)*math.cos(a),math.cos(t)*math.sin(a),-math.sin(t)])
    right=np.array([math.sin(a),-math.cos(a),0.])
    down=np.cross(forward,right)
    return forward,right*math.cos(r)+down*math.sin(r),down*math.cos(r)-right*math.sin(r)

def origin(p):return np.array([p['camera_offset'],p.get('camera_lateral',0),p['height']])

def ray(u,row,p):
    f=94/math.tan(math.radians(p['hfov']/2));dx=np.asarray(u)-p['cx'];dy=np.asarray(row)-p['cy']
    ux=dx.copy();uy=dy.copy();scale=math.hypot(94,60)
    for _ in range(3):
        factor=1+p['k1']*(ux*ux+uy*uy)/scale**2;ux=dx/factor;uy=dy/factor
    forward,right,down=basis(p)
    return forward+np.asarray(ux/f)[...,None]*right+np.asarray(uy/(f*p['fy_ratio']))[...,None]*down

def project_ground(points,p):
    """Points in rear-axle body coordinates (metres); return u,v and forward validity."""
    points=np.asarray(points,dtype=float).reshape(-1,2)
    q=np.column_stack((points,np.zeros(len(points))))-origin(p)
    forward,right,down=basis(p);depth=q@forward;safe=np.maximum(depth,1e-9)
    f=94/math.tan(math.radians(p['hfov']/2));dx=f*(q@right)/safe;dy=f*p['fy_ratio']*(q@down)/safe
    factor=1+p['k1']*(dx*dx+dy*dy)/(94**2+60**2)
    return np.column_stack((p['cx']+dx*factor,p['cy']+dy*factor)),depth>0

def straight_width(p,row):
    if not p.get('camera_yaw',0) and not p.get('camera_roll',0):
        f=94/math.tan(math.radians(p['hfov']/2));t=math.radians(p['pitch'])
        down=math.sin(t)+(row-p['cy'])/(f*p['fy_ratio'])*math.cos(t)
        return p['road_width']/p['height']*f*down if down>0 else None
    # Analytical intersection of each straight road side with an image row, no distortion.
    if p['k1']:return None
    f=94/math.tan(math.radians(p['hfov']/2));F,R,D=basis(p)
    d=F+(row-p['cy'])/(f*p['fy_ratio'])*D;a=R/f;columns=[]
    for y in (-p['road_width']/2,p['road_width']/2):
        k=y-p.get('camera_lateral',0);den=k*a[2]+p['height']*a[1]
        if abs(den)<1e-12:return None
        u=-(k*d[2]+p['height']*d[1])/den;direction=d+u*a
        if direction[2]>=0:return None
        columns.append(p['cx']+u)
    return abs(columns[1]-columns[0])
