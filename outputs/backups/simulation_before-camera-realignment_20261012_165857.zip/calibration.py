"""Six measured straight-road widths; fit only height and pitch at fixed HFOV."""
import itertools, math
import numpy as np
from camera_optics import straight_width

ROWS=(30,45,70,86,108,116)
WIDTHS=(44.,59.,97.,120.,156.,167.)

def references(p):
    return dict(zip(ROWS,p.get('reference_widths',WIDTHS)))

def comparison(p):
    rows=[]
    for row,target in references(p).items():
        value=straight_width(p,row)
        rows.append({'row':row,'reference':target,'predicted':value,
                     'error':None if value is None else value-target})
    errors=[r['error'] for r in rows if r['error'] is not None]
    return rows, (float(np.sqrt(np.mean(np.square(errors)))) if errors else None), (max(map(abs,errors)) if errors else None)

def fit(p,objective='maximum'):
    if p['k1'] or p['camera_yaw'] or p['camera_roll']:
        raise ValueError('六行宽度拟合要求无畸变、偏航和横滚；请先核对直道测量条件。')
    y=np.array(ROWS,float);w=np.array(p['reference_widths'],float)
    a,b=np.linalg.lstsq(np.column_stack((y,np.ones(len(y)))),w,rcond=None)[0]
    if objective=='maximum':
        best=None
        for ids in itertools.combinations(range(len(y)),3):
            for signs in itertools.product((-1,1),repeat=3):
                matrix=np.array([[y[i],1,-s] for i,s in zip(ids,signs)])
                try:aa,bb,t=np.linalg.solve(matrix,w[list(ids)])
                except np.linalg.LinAlgError:continue
                if t>=-1e-9 and np.max(np.abs(aa*y+bb-w))<=t+1e-8 and (best is None or t<best[2]):best=(aa,bb,t)
        if best is None:raise ValueError('不能求出六行最大误差拟合。')
        a,b,_=best
    f=94/math.tan(math.radians(p['hfov']/2))
    if a<=0:raise ValueError('实测宽度必须整体随行号增加。')
    angle=math.atan((b/a+p['cy'])/(f*p['fy_ratio']))
    height=p['road_width']*math.cos(angle)/(a*p['fy_ratio'])
    if not .03<=height<=1 or not 1<=math.degrees(angle)<=85:raise ValueError('拟合高度或俯角超出允许范围。')
    candidate=p.copy();candidate.update(height=height,pitch=math.degrees(angle),camera_mode='six_row_fit',fitted_pitch=math.degrees(angle),fitted_hfov=p['hfov'])
    return candidate
