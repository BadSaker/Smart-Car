@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch.ps1"
if errorlevel 1 (
    echo Startup failed. See "%~dp0reports\launcher.log".
    pause
    exit /b 1
)
exit /b 0
