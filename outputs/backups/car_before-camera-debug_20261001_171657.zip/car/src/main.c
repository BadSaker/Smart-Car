#include "main.h" // 硬件参数在 config/board_config.h 中配置

/* Adapted from 参考/镜头组例程.zip for the confirmed C-chassis hardware.
 * Camera processing and 10 ms encoder sampling are enabled.
 * Screen, motor output and steering output are controlled by board_config.h.
 * Verify wiring, forward encoder signs and steering limits before enabling motion.
 * No race element recognition or automatic finish-line stop is implemented yet.
 */

// 舵机动作角度中值
const float servo_motor_duty_middle = (SERVO_MOTOR_R_MAX + SERVO_MOTOR_L_MAX) / 2.f; 

static void app_init(void)
{

    /* The confirmed hardware has no display. UART1 supplies diagnostics. */
#if APP_ENABLE_TFT180
    tft180_init();
#endif
    while (mt9v03x_init())
    {
        printf("MT9V034 init failed; check power and CSI cable.\r\n");
        system_delay_ms(1000);
    }
    printf("MT9V034 ready. Motor=%d Servo=%d (0=disabled).\r\n",
           APP_ENABLE_MOTOR_OUTPUT, APP_ENABLE_SERVO_OUTPUT);

    // 编码器初始化
    encoder_quad_init(ENCODER_1, ENCODER_1_A, ENCODER_1_B); // 初始化编码器模块与引脚 正交解码编码器模式
    encoder_quad_init(ENCODER_2, ENCODER_2_A, ENCODER_2_B); // 初始化编码器模块与引脚 正交解码编码器模式

    // 电机初始化
    pwm_init(MOTOR1_PWM, 17000, 0); // PWM 通道初始化频率 17KHz 占空比初始为 0
    gpio_init(MOTOR1_DIR, GPO, GPIO_HIGH, GPO_PUSH_PULL); // GPIO 初始化为输出 默认上拉输出高
    pwm_init(MOTOR2_PWM, 17000, 0); // PWM 通道初始化频率 17KHz 占空比初始为 0
    gpio_init(MOTOR2_DIR, GPO, GPIO_HIGH, GPO_PUSH_PULL); // GPIO 初始化为输出 默认上拉输出高

    // 舵机
    pwm_init(SERVO_MOTOR_PWM, SERVO_MOTOR_FREQ, 0);

    // PID初始化
    My_Pid_Init();

    // 定时器0初始化，10ms可调
    pit_ms_init(PIT_CH0, APP_CONTROL_PERIOD_MS);
}

uint8_t image[MT9V03X_H][MT9V03X_W];
short hist_gram[256];
uint8_t left_line[MT9V03X_H];
uint8_t mid_line[MT9V03X_H];
uint8_t right_line[MT9V03X_H];

int main(void)
{
    clock_init(SYSTEM_CLOCK_600M); // 不可删除
    debug_init();                  // 调试端口初始化
    system_delay_ms(300);          // 等待主板其他外设上电完成

    app_init();
    interrupt_global_enable(0);

    uint32_t frame_count = 0;
    while (1)
    {
        //  mt9v03x摄像头
        if (mt9v03x_finish_flag)
        {
            // 另寻空间将图像保存下来，以免产生因读写冲突带来的未知后果
            memcpy((uint8_t *)image, (uint8_t *)mt9v03x_image, sizeof(uint8_t) * MT9V03X_H * MT9V03X_W);
            /* Acknowledge the copied frame before processing to retain later completions. */
            mt9v03x_finish_flag = 0;
            // 获取直方图
            get_hist_gram((uint8_t *)image, MT9V03X_H, MT9V03X_W, hist_gram);
            unsigned char threshold = get_threshold_otsu(hist_gram);
            // 二值化处理
            binaryzation_process((uint8_t *)image, MT9V03X_H, MT9V03X_W, threshold);
            // 边界线寻找
            auxiliary_process((uint8_t *)image, MT9V03X_H, MT9V03X_W, 127, left_line, mid_line, right_line);

            for (uint8_t _i = 0; _i < MT9V03X_H; ++_i)
            {
                // 将边界线也显示出来
                image[_i][left_line[_i]] = 0;
                image[_i][mid_line[_i]] = 0;
                image[_i][right_line[_i]] = 0;
            }
#if APP_ENABLE_TFT180
            tft180_displayimage03x((uint8_t *)image, 125, 100);
#endif

            // 取图像下1/4处做误差判断
            float mid_err = (MT9V03X_W/2) - mid_line[MT9V03X_H-MT9V03X_H/4];
            // 舵机根据误差乘以系数打角
            float tmp_duty = servo_motor_duty_middle - mid_err * 0.5 * SERVO_DIR;
            // 限幅
            tmp_duty = MAX(tmp_duty,MIN(SERVO_MOTOR_L_MAX,SERVO_MOTOR_R_MAX));
            tmp_duty = MIN(tmp_duty,MAX(SERVO_MOTOR_L_MAX,SERVO_MOTOR_R_MAX));
#if APP_ENABLE_SERVO_OUTPUT
            pwm_set_duty(SERVO_MOTOR_PWM, (uint32)SERVO_MOTOR_DUTY(tmp_duty));
#else
            (void)tmp_duty;
#endif

#if APP_ENABLE_TFT180
            tft180_show_int(0, 0, encoder_data_1, 3);
            tft180_show_int(0, 30, encoder_data_2, 3);
#endif
            if (++frame_count % 10U == 0U)
            {
                printf("frame=%lu threshold=%u error=%.1f encL=%d encR=%d pwm=%.1f\r\n",
                       (unsigned long)frame_count, (unsigned)threshold,
                       (double)mid_err, encoder_data_1, encoder_data_2, (double)speed_pwm);
            }
        }
    }
}
