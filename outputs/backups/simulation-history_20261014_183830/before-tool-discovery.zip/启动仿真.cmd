@echo off
setlocal
set "simulationPython=C:\Users\Sumi\AppData\Local\Programs\Python\Python313\pythonw.exe"
if exist "%simulationPython%" (
    set "PYTHONUTF8=1"
    set "PYTHONDONTWRITEBYTECODE=1"
    start "" "%simulationPython%" -B "%~dp0start_app.py"
    exit /b 0
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch.ps1"
if errorlevel 1 (
    echo Startup failed. See "%~dp0reports\launcher.log".
    pause
    exit /b 1
)
exit /b 0
