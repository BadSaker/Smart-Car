import json, math, os, time, traceback
import tkinter as tk
from tkinter import ttk,messagebox,filedialog,simpledialog
from PIL import Image,ImageTk
import numpy as np
from parameters import ROOT,defaults,fit_camera,validate,save,load
from engine import Simulation,STATES,FAULTS,ELEMENTS,REASONS
from geometry import predicted_width
from render import map_image,scene_image,camera_image,chart_image

def desktop_dpi():
    if os.name=='nt':
        import ctypes
        try:ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:pass

FIELDS={
 '车辆':[('length','车身长度 m'),('wheelbase','轴距 m'),('track','轮距 m'),('body_width','车身外宽 m〔假设〕'),
 ('tire_width','轮胎宽 m〔假设〕'),('wheel_diameter','轮径 m'),('steer_max_deg','满幅前轮转角 °〔假设〕'),
 ('servo_center','舵机中位 µs'),('servo_range','舵机摆幅 ±µs'),('servo_step','命令步进 µs'),
 ('servo_interval','步进间隔 s'),('servo_tau','机械响应 s〔假设〕'),('motor_gain','电机增益 mm/s/‰〔假设〕'),
 ('motor_deadzone','起转死区 ‰〔假设〕'),('motor_tau','电机响应 s〔假设〕'),('coast_tau','滑行响应 s〔假设〕')],
 '相机':[('height','镜头高度 m'),('camera_offset','相机在后轴前 m'),('pitch','向下俯角 °'),
 ('hfov','有效水平视场 °'),('fy_ratio','fy/fx 缩放比〔假设〕'),('cx','主点列 px'),('cy','主点行 px'),('k1','角点径向比例〔模型〕'),
 ('fps','相机帧率 Hz'),('gray_road','道路灰度 0–255'),('gray_edge','边线灰度 0–255'),
 ('gray_background','背景灰度 0–255'),('noise','灰度噪声 σ'),('seed','随机种子')],
 '控制':[('cruise','直道目标 mm/s'),('curve_speed','弯道目标 mm/s'),('outer_speed','外侧目标 mm/s'),
 ('kp','转向 Kp'),('ki','转向 Ki'),('kd','转向 Kd'),('speed_kp','速度 Kp'),('speed_ki','速度 Ki'),
 ('min_q','普通Q门限'),('outer_q','外侧Q门限'),('outer_enabled','外侧补线 0/1'),
 ('width_top','第30行标定宽 px'),('width_bottom','第116行标定宽 px')],
 '场景':[('road_width','道路内沿宽 m'),('edge_width','黑边宽 m〔假设〕'),('radius','圆弧中心半径 m'),
 ('offset','初始左偏 m'),('heading_error','初始左偏航 °')]
}
class App:
    def __init__(self,root):
        self.root=root;root.tk.call('tk','scaling',1.25)
        root.title('小车仿真实验室 · 完整赛道')
        width=min(1480,root.winfo_screenwidth()-60);height=min(930,root.winfo_screenheight()-90)
        root.geometry(f'{width}x{height}+25+35');root.minsize(1100,720)
        root.configure(bg='#0c1624');self.running=False;self.yaw=-55;self.elevation=48;self.zoom=1.;self.last_drag=None
        self.p=defaults();self.sim=Simulation(self.p);self.vars={};self.photos={};self.last_clock=time.perf_counter();self.accumulator=0.
        self.replay_frames=[];self.replay_index=0;self.replay_clock=0.
        style=ttk.Style(root);style.theme_use('clam')
        style.configure('.',font=('Microsoft YaHei UI',10),background='#142236',foreground='#dce6f2')
        style.configure('TFrame',background='#142236');style.configure('TLabel',background='#142236',foreground='#dce6f2')
        style.configure('TButton',padding=(10,7),background='#273d56',foreground='#eff6ff')
        style.map('TButton',background=[('active','#375a79')])
        style.configure('TEntry',fieldbackground='#0e1a2a',foreground='#f1f6fb',insertcolor='white')
        style.configure('TCombobox',fieldbackground='#0e1a2a',foreground='#f1f6fb')
        style.map('TCombobox',fieldbackground=[('readonly','#0e1a2a')],foreground=[('readonly','#f1f6fb')])
        style.configure('TNotebook.Tab',padding=(12,7),background='#203247')
        style.map('TNotebook.Tab',background=[('selected','#36536c')])
        style.configure('TCheckbutton',background='#142236',foreground='#dce6f2')
        banner=tk.Frame(root,bg='#0c1624');banner.pack(fill='x',padx=18,pady=(12,8))
        tk.Label(banner,text='小车仿真实验室',font=('Microsoft YaHei UI',22,'bold'),fg='#eff5fd',bg='#0c1624').pack(side='left')
        tk.Label(banner,text='2D / 3D  ·  原始 C 算法  ·  参数实验',font=('Microsoft YaHei UI',11),fg='#91a9c2',bg='#0c1624').pack(side='left',padx=22)
        self.mode_note=tk.Label(banner,text='条件相机拟合 · 执行机构未实测标定',fg='#f7be69',bg='#0c1624');self.mode_note.pack(side='right')
        bar=ttk.Frame(root);bar.pack(fill='x',padx=18,pady=(0,8))
        for text,method in [('▶ 启动 / 继续',self.start),('Ⅱ 暂停',self.pause),('■ 停车',self.stop),('单步 10ms',self.step),('应用并重置',self.reset)]:
            ttk.Button(bar,text=text,command=method).pack(side='left',padx=3,pady=5)
        self.speed=tk.StringVar(value='1×');ttk.Label(bar,text='速度').pack(side='left',padx=(12,3))
        ttk.Combobox(bar,textvariable=self.speed,values=['0.5×','1×','2×','4×','8×'],width=5,state='readonly').pack(side='left')
        ttk.Button(bar,text='导出实验',command=self.export).pack(side='right',padx=4)
        ttk.Button(bar,text='图像回放',command=self.replay).pack(side='right',padx=4)
        ttk.Button(bar,text='保存参数',command=self.save_params).pack(side='right',padx=4)
        ttk.Button(bar,text='读取参数',command=self.load_params).pack(side='right',padx=4)
        outer=ttk.Panedwindow(root,orient='horizontal');outer.pack(fill='both',expand=True,padx=18)
        left=ttk.Frame(outer,width=320);middle=ttk.Frame(outer);right=ttk.Frame(outer,width=390)
        outer.add(left,weight=0);outer.add(middle,weight=1);outer.add(right,weight=0)
        ttk.Label(left,text='实验参数',font=('Microsoft YaHei UI',13,'bold')).pack(anchor='w',padx=12,pady=10)
        self.scenario=tk.StringVar(value='完整赛道');self.direction=tk.StringVar(value='A→B');self.controller=tk.StringVar(value='现有 C 算法')
        for title,var,vals in [('场景',self.scenario,['完整赛道','中期 A—B','直道诊断','圆弧诊断']),('方向',self.direction,['A→B','B→A']),
                               ('控制',self.controller,['现有 C 算法','理想几何参考'])]:
            row=ttk.Frame(left);row.pack(fill='x',padx=10,pady=3);ttk.Label(row,text=title,width=5).pack(side='left')
            ttk.Combobox(row,textvariable=var,values=vals,state='readonly',width=19).pack(side='right')
        self.vars['show_ab']=tk.BooleanVar(value=True)
        ttk.Checkbutton(left,text='显示 A / B 标线〔仅可视标记〕',variable=self.vars['show_ab'],command=self.inject).pack(anchor='w',padx=10,pady=3)
        self.parameter_tabs=ttk.Notebook(left);self.parameter_tabs.pack(fill='both',expand=True,padx=8,pady=8)
        for title,fields in FIELDS.items():
            pane=ttk.Frame(self.parameter_tabs);self.parameter_tabs.add(pane,text=title)
            for i,(key,label) in enumerate(fields):
                ttk.Label(pane,text=label).grid(row=i,column=0,sticky='w',padx=(7,4),pady=5)
                v=tk.StringVar(value=f'{self.p[key]:.6g}');self.vars[key]=v
                ttk.Entry(pane,textvariable=v,width=9).grid(row=i,column=1,sticky='e',padx=(0,7),pady=5)
        ttk.Label(left,text='修改参数后点击「应用并重置」\n〔假设〕项可调，但未由实车数据校准。',foreground='#a8bbcf',wraplength=285).pack(anchor='w',padx=12,pady=8)
        self.view_tabs=ttk.Notebook(middle);self.view_tabs.pack(fill='both',expand=True,padx=8,pady=8)
        self.views={}
        for name in ('2D 赛道','3D 场景','赛道原图','相机标定'):
            pane=ttk.Frame(self.view_tabs);self.view_tabs.add(pane,text=name);self.views[name]=pane
        self.map_label=ttk.Label(self.views['2D 赛道']);self.map_label.pack(fill='both',expand=True)
        self.scene_label=ttk.Label(self.views['3D 场景']);self.scene_label.pack(fill='both',expand=True)
        self.scene_label.bind('<ButtonPress-1>',self.drag_start);self.scene_label.bind('<B1-Motion>',self.drag)
        self.scene_label.bind('<MouseWheel>',self.scroll)
        self.follow=tk.BooleanVar(value=False);ttk.Checkbutton(self.views['3D 场景'],text='跟车视角',variable=self.follow).pack(anchor='w')
        self.source_label=ttk.Label(self.views['赛道原图']);self.source_label.pack(fill='both',expand=True)
        ttk.Label(self.views['赛道原图'],text='来源：中期检查要求.docx · 完整拓扑：双环岛、十字、连续弯道。标注尺寸保留；上方闭合连接约22.16cm为建模假设。',wraplength=580).pack(pady=8)
        cal=self.views['相机标定'];ttk.Label(cal,text='相机投影与两点条件拟合',font=('Microsoft YaHei UI',16,'bold')).pack(anchor='w',padx=20,pady=20)
        self.calibration_text=tk.StringVar();ttk.Label(cal,textvariable=self.calibration_text,wraplength=560,justify='left').pack(anchor='w',padx=20,pady=10)
        ttk.Button(cal,text='按当前高度 / 道路宽度拟合44/167',command=self.fit).pack(anchor='w',padx=20,pady=10)
        ttk.Button(cal,text='采用标称安装：20° / 水平视场130°假设',command=self.nominal).pack(anchor='w',padx=20,pady=5)
        ttk.Label(cal,text='实际图像校准：在直道摆正车辆，记录地面距离及图像行位置。\n修改参数不能证明安装角度已被实测确认。',foreground='#f7be69',wraplength=540).pack(anchor='w',padx=20,pady=20)
        ttk.Label(right,text='虚拟摄像头 · 188 × 120',font=('Microsoft YaHei UI',13,'bold')).pack(anchor='w',padx=12,pady=10)
        self.camera_label=ttk.Label(right);self.camera_label.pack(padx=8)
        ttk.Label(right,text='青/橙：实测边线  绿：有效中线  紫：重建边线',foreground='#a8bbcf').pack(pady=4)
        self.status=tk.StringVar();ttk.Label(right,textvariable=self.status,justify='left',font=('Microsoft YaHei UI',10)).pack(anchor='w',padx=12,pady=5)
        self.chart_label=ttk.Label(right);self.chart_label.pack(padx=8,pady=5)
        injections=ttk.LabelFrame(right,text='故障注入 · 立即生效');injections.pack(fill='x',padx=10,pady=8)
        for key,label in [('drop_camera','停止新图像'),('drop_feedback','冻结反馈序号'),('blackout','全黑画面')]:
            v=tk.BooleanVar(value=False);self.vars[key]=v
            ttk.Checkbutton(injections,text=label,variable=v,command=self.inject).pack(anchor='w',padx=8,pady=3)
        self.message=tk.StringVar(value='已就绪。默认参数为两点条件拟合，点击启动运行现有C代码。')
        ttk.Label(root,textvariable=self.message,foreground='#91a9c2').pack(fill='x',padx=22,pady=8)
        root.protocol('WM_DELETE_WINDOW',self.close);self.refresh();root.after(40,self.loop)
    def collect(self):
        p=self.p.copy()
        for key,var in self.vars.items():
            if isinstance(var,tk.BooleanVar):p[key]=var.get()
            else:p[key]=float(var.get())
        p['scenario']={'完整赛道':'full','中期 A—B':'midterm','直道诊断':'straight','圆弧诊断':'circle'}[self.scenario.get()]
        p['direction']=self.direction.get();p['controller']='native' if self.controller.get()=='现有 C 算法' else 'reference'
        if abs(p['pitch']-p['fitted_pitch'])>1e-4 or abs(p['hfov']-p['fitted_hfov'])>1e-4:p['camera_mode']='manual'
        return validate(p)
    def set_fields(self,p):
        self.p=p
        for key,var in self.vars.items():var.set(p[key] if isinstance(var,tk.BooleanVar) else f'{p[key]:.8g}')
        self.scenario.set({'full':'完整赛道','midterm':'中期 A—B','straight':'直道诊断','circle':'圆弧诊断'}[p['scenario']])
        self.direction.set(p['direction']);self.controller.set('现有 C 算法' if p['controller']=='native' else '理想几何参考')
    def reset(self):
        self.running=False
        try:
            p=self.collect();new=Simulation(p);self.p=p;self.sim=new;self.replay_frames=[];self.accumulator=0.
            self.message.set('已重置。参数和编译产物仅写入 simulation；原工程保持只读。');self.refresh()
        except Exception as e:messagebox.showerror('参数 / 编译错误',str(e))
    def start(self):
        if self.sim.replay:
            self.running=True;self.last_clock=time.perf_counter();return
        if self.sim.data[0] in (4,5,6):
            self.message.set('当前已结束、停车或故障；请「应用并重置」后重新启动。');return
        self.sim.started=True;self.running=True;self.last_clock=time.perf_counter()
    def pause(self):self.running=False;self.message.set('已暂停，仿真时间冻结。')
    def stop(self):
        if self.sim.replay:self.pause();return
        self.sim.stop_requested=True;self.sim.tick();self.running=False;self.refresh();self.message.set('停车命令已送入控制器；继续单步可观察滑行。')
    def step(self):
        self.running=False
        if self.sim.replay:self.replay_next()
        else:self.sim.tick()
        self.refresh()
    def inject(self):
        for key in ('drop_camera','drop_feedback','blackout','show_ab'):self.sim.p[key]=self.vars[key].get()
        self.refresh()
    def fit(self):
        try:
            p=self.collect();v=fit_camera(p['height'],p['road_width'],p['cy'],p['width_top'],p['width_bottom'],p['fy_ratio'])
            p['pitch']=p['fitted_pitch']=v['pitch'];p['hfov']=p['fitted_hfov']=v['hfov'];p['k1']=0.;p['camera_mode']='two_point_fit'
            self.set_fields(p);self.reset();self.message.set('已采用两点条件拟合。结果依赖平地、道路内宽、fy/fx和主点假设。')
        except Exception as e:messagebox.showerror('拟合失败',str(e))
    def nominal(self):
        p=self.collect();p.update(pitch=20.,hfov=130.,k1=0.,camera_mode='nominal_horizontal_assumption')
        self.set_fields(p);self.reset();self.message.set('标称130°暂按水平视场解释；若第30行在地平线上方，会显示无地面投影。')
    def save_params(self):
        try:
            p=self.collect();name=simpledialog.askstring('保存参数','参数名称（文件保存在 simulation/configs）：',initialvalue='我的参数')
            if name:
                name=''.join(c for c in name if c.isalnum() or c in '-_')[:60]
                if not name:raise ValueError('参数名称为空')
                path=ROOT/'configs'/(name+'.json');save(path,p);self.message.set('已保存：'+str(path))
        except Exception as e:messagebox.showerror('保存失败',str(e))
    def load_params(self):
        path=filedialog.askopenfilename(initialdir=ROOT/'configs',filetypes=[('JSON参数','*.json')])
        if path:
            try:self.set_fields(load(path));self.reset()
            except Exception as e:messagebox.showerror('读取失败',str(e))
    def export(self):
        folder=self.sim.export('replay' if self.sim.replay else self.sim.p['controller'])
        map_image(self.sim).save(folder/'map.png');scene_image(self.sim).save(folder/'scene.png')
        camera_image(self.sim).save(folder/'vision_overlay.png');chart_image(self.sim).save(folder/'chart.png')
        self.message.set('已导出参数、结果、CSV与截图：'+str(folder))
    def replay(self):
        paths=filedialog.askopenfilenames(title='选择188×120原始帧（按文件名排序回放）',filetypes=[('图像','*.png *.bmp *.jpg *.pgm')])
        if not paths:return
        self.running=False
        try:
            frames=[]
            for path in sorted(paths):
                with Image.open(path) as im:
                    if im.size!=(188,120):raise ValueError(f'{path} 尺寸不是188×120；不自动缩放原始帧。')
                    frames.append((path,np.asarray(im.convert('L')).copy()))
            self.sim=Simulation(self.collect());self.sim.replay=True;self.sim.history=[]
            self.replay_frames=frames;self.replay_index=0;self.replay_clock=0.;self.replay_next();self.refresh()
        except Exception as e:messagebox.showerror('回放失败',str(e))
    def replay_next(self):
        if self.replay_index>=len(self.replay_frames):self.running=False;self.message.set('图像回放完成。继续仿真请应用并重置。');return
        path,gray=self.replay_frames[self.replay_index];self.replay_index+=1
        s=self.sim;s.now=round((self.replay_index-1)*1000/s.p['fps']);s.image=gray
        s.native.vision(gray,s.now,0);s.data,s.rows=s.native.data();s.record()
        self.message.set(f'图像回放 {self.replay_index}/{len(self.replay_frames)} · {path} · 无轮速/里程，元素距离转换未验证')
    def loop(self):
        try:
            clock=time.perf_counter();elapsed=min(.2,clock-self.last_clock);self.last_clock=clock
            if self.running:
                factor=float(self.speed.get().replace('×',''))
                if self.sim.replay:
                    self.replay_clock+=elapsed*factor
                    if self.replay_clock>=1/self.sim.p['fps']:
                        self.replay_clock=0;self.replay_next()
                else:
                    self.accumulator=min(.5,self.accumulator+elapsed*factor)
                    budget=time.perf_counter()+.045
                    while self.accumulator>=.01 and time.perf_counter()<budget:
                        self.sim.tick();self.accumulator-=.01
                        if self.sim.completed:
                            self.running=False;self.message.set('到达终点，已冻结仿真供检查；这不是控制器自动停车。');break
                        if self.sim.p['controller']=='native' and self.sim.data[0]==6:
                            self.running=False;self.message.set('现有C控制器触发故障，已暂停保留现场。可导出或单步观察。');break
            self.refresh()
        except Exception:
            self.running=False;log=ROOT/'reports/ui_error.log';log.write_text(traceback.format_exc(),encoding='utf-8')
            self.message.set('运行异常，已暂停。详情：'+str(log))
        self.root.after(60,self.loop)
    def show(self,key,label,image):
        photo=ImageTk.PhotoImage(image);self.photos[key]=photo;label.configure(image=photo)
    def refresh(self):
        s=self.sim;tab=self.view_tabs.tab(self.view_tabs.select(),'text')
        if tab=='2D 赛道':
            size=(max(430,self.map_label.winfo_width()),max(400,self.map_label.winfo_height()));self.show('map',self.map_label,map_image(s,size))
        elif tab=='3D 场景':
            size=(max(430,self.scene_label.winfo_width()),max(400,self.scene_label.winfo_height()))
            self.show('scene',self.scene_label,scene_image(s,size,self.yaw,self.elevation,self.zoom,self.follow.get()))
        elif tab=='赛道原图':
            im=Image.open(ROOT/'assets/image1.png').convert('RGB');im.thumbnail((max(430,self.source_label.winfo_width()),max(400,self.source_label.winfo_height())))
            self.show('source',self.source_label,im)
        self.show('camera',self.camera_label,camera_image(s));self.show('chart',self.chart_label,chart_image(s,(376,120)))
        data=s.data;_,error,progress=s.track.nearest(s.x,s.y,getattr(s,'route_progress',0))
        state='图像回放（无控制）' if s.replay else ('理想几何参考（读取真实路径）' if s.p['controller']=='reference' else STATES[int(data[0])])
        self.status.set(f"{state}  ·  {'已达终点' if s.completed else '未达终点'}\n"
          f"{'旁路C诊断' if s.p['controller']=='reference' or s.replay else '故障'}：{FAULTS[int(data[1])]} / 路径：{REASONS[int(data[10])]}\n"
          f"时间 {s.now/1000:6.2f}s   里程 {s.distance:6.3f}m\n"
          f"Q {int(data[3]):3d} / 门限 {int(data[16]):2d}   V {int(data[4])}   {ELEMENTS[int(data[7])]}\n"
          f"近 / 远误差 {int(data[5]):+4d} / {int(data[6]):+4d}px\n"
          f"外侧 {int(data[8])}  支持 {int(data[9])}  行数 {int(data[18])}/{int(data[19])}\n"
          f"转角 {math.degrees(s.steer):+6.2f}°   脉宽 {s.pulse:7.1f}µs\n"
          f"轮速 L/R {s.left_v*1000:5.1f} / {s.right_v*1000:5.1f}mm/s\n"
          f"PWM L/R {s.applied_duties[0]:3.0f} / {s.applied_duties[1]:3.0f}‰\n"
          f"横偏 {error*100:+6.2f}cm   进度 {progress:5.2f}m\n"
          f"出界轮数〔近似〕{s.outside_wheels()}  最大 {s.max_outside}")
        p=s.p;w30=predicted_width(p,30);w116=predicted_width(p,116)
        def val(v):return '无地面投影' if v is None else f'{v:.2f}px'
        self.calibration_text.set(f"当前高度：{p['height']:.3f}m\n当前向下俯角：{p['pitch']:.3f}°\n有效水平视场：{p['hfov']:.3f}°\n"
          f"主点：({p['cx']:.2f}, {p['cy']:.2f})\n\n"
          f"第30行预测宽度：{val(w30)}；标定 {p['width_top']}px\n第116行预测宽度：{val(w116)}；标定 {p['width_bottom']}px\n\n"
          "镜头标称130°、几何畸变≤1%。视角方向及裁剪范围未确认。\n\n"
          "两点拟合假设：高度和道路内宽正确、平地、fy/fx已知（默认1）、主点已知、忽略畸变。"
          "拟合可以满足两行宽度，但不能唯一证明真实俯角或镜头视场。")
        self.mode_note.configure(text='理想几何参考 · 使用路径真值' if p['controller']=='reference' else '现有 C 算法 · 执行机构未实测标定')
    def drag_start(self,event):self.last_drag=(event.x,event.y)
    def drag(self,event):
        if self.last_drag:
            self.yaw+=(event.x-self.last_drag[0])*.4;self.elevation=float(np.clip(self.elevation+(event.y-self.last_drag[1])*.3,15,80))
            self.last_drag=(event.x,event.y);self.refresh()
    def scroll(self,event):self.zoom=float(np.clip(self.zoom*(1.1 if event.delta>0 else 1/1.1),.5,3));self.refresh()
    def close(self):self.running=False;self.root.destroy()

def main():
    desktop_dpi()
    root=tk.Tk()
    try:App(root);root.mainloop()
    except Exception:
        log=ROOT/'reports/startup_error.log';log.write_text(traceback.format_exc(),encoding='utf-8')
        messagebox.showerror('启动失败','详情：'+str(log));root.destroy();raise
if __name__=='__main__':main()
