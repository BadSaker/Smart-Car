"""Read-only measured-frame comparison. Never fits or applies camera parameters."""
import csv,json,math
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from camera_optics import project_ground
from geometry import predicted_width
from render import font

class Comparison:
    def __init__(self):
        self.real=None;self.source=None;self.points=[];self.widths={30:44.,116:167.};self.version=0
    def load_image(self,path):
        with Image.open(path) as im:
            if im.size!=(188,120):raise ValueError('请使用未缩放的188×120原始灰度帧。')
            self.real=np.asarray(im.convert('L')).copy()
        self.source=str(path);self.version+=1
    def add_point(self,x_mm,y_mm,u_px,v_px):
        values=[float(x_mm),float(y_mm),float(u_px),float(v_px)]
        if not all(math.isfinite(v) for v in values):raise ValueError('标定点必须为有限数值。')
        if not (0<=values[2]<=187 and 0<=values[3]<=119):raise ValueError('实测像素坐标超出188×120图像。')
        self.points.append(dict(zip(('x_mm','y_mm','u_px','v_px'),values)));self.version+=1
    def load_points(self,path):
        with Path(path).open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
        previous=self.points.copy()
        try:
            self.points=[]
            for row in rows:self.add_point(*(row[k] for k in ('x_mm','y_mm','u_px','v_px')))
        except Exception:self.points=previous;raise
        self.version+=1
    def result(self,p):
        results=[]
        if self.points:
            positions=np.array([[v['x_mm']/1000,v['y_mm']/1000] for v in self.points])
            pixels,visible=project_ground(positions,p)
            for n,(point,pixel,valid) in enumerate(zip(self.points,pixels,visible),1):
                predicted=pixel.tolist() if valid else None
                residual=(pixel-np.array([point['u_px'],point['v_px']])).tolist() if valid else None
                results.append({'id':n,**point,'predicted_px':predicted,'error_px':residual,
                  'in_front':bool(valid),'in_image':bool(valid and 0<=pixel[0]<188 and 0<=pixel[1]<120)})
        errors=[v['error_px'] for v in results if v['error_px'] is not None]
        rmse=float(np.sqrt(np.mean(np.sum(np.square(errors),axis=1)))) if errors else None
        widths=[]
        for row,reference in self.widths.items():
            predicted=predicted_width(p,row)
            widths.append({'row':row,'reference_px':reference,'predicted_px':predicted,
                           'error_px':predicted-reference if predicted is not None else None})
        return {'source_image':self.source,'points':results,'rmse_px':rmse,'straight_widths':widths,
                'coordinate_system':'rear axle origin; x forward/y left, ground in mm',
                'width_note':'ideal centered straight road, reference widths entered manually; not fitted'}
    def image(self,sim,size):
        w,h=size;im=Image.new('RGB',size,'#101d2d');d=ImageDraw.Draw(im);result=self.result(sim.p)
        stacked=w<460;gap=16;cell_w=w-2*gap if stacked else (w-3*gap)//2
        available=(h-160)//2 if stacked else h-155
        scale=max(.2,min(cell_w/188,max(60,available)/120));iw=round(188*scale);ih=round(120*scale)
        panels=[('实测',self.real),('仿真',sim.image)]
        for index,(title,data) in enumerate(panels):
            x=gap if stacked else gap+index*(cell_w+gap);y=40+index*(ih+36) if stacked else 40
            d.text((x,y-26),title,font=font(14),fill='#dce6f2')
            if data is not None:
                image=Image.fromarray(data).convert('RGB').resize((iw,ih),Image.Resampling.NEAREST);im.paste(image,(x,y))
            else:
                d.rectangle((x,y,x+iw,y+ih),fill='#1d2b3d');d.text((x+8,y+12),'导入原始灰度帧',font=font(12),fill='#a8bbcf')
            for point in result['points']:
                position=[point['u_px'],point['v_px']] if index==0 else point['predicted_px']
                if position is None or not (0<=position[0]<188 and 0<=position[1]<120):continue
                px=x+position[0]*scale;py=y+position[1]*scale
                d.line((px-4,py,px+4,py),fill='#ffae56',width=2);d.line((px,py-4,px,py+4),fill='#ffae56',width=2)
                d.text((px+5,py-12),str(point['id']),font=font(11),fill='#ffae56')
            for row in self.widths:
                py=y+row*scale;d.line((x,py,x+iw,py),fill='#62cbbd',width=1)
        y=92+2*ih if stacked else 60+ih
        for v in result['straight_widths']:
            actual='无地面交点' if v['predicted_px'] is None else f"{v['predicted_px']:.2f}px，差 {v['error_px']:+.2f}px"
            d.text((gap,y),f"第{v['row']}行  参考 {v['reference_px']:g}px  直道预测 {actual}",font=font(11),fill='#dce6f2');y+=22
        text='尚未添加标定点' if result['rmse_px'] is None else f"标定点 {len(result['points'])} 个，像素误差 RMSE {result['rmse_px']:.2f}"
        d.text((gap,y),text,font=font(11),fill='#a8bbcf')
        return im
    def export(self,folder,p,sim):
        folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
        (folder/'comparison.json').write_text(json.dumps(self.result(p),ensure_ascii=False,indent=2),encoding='utf-8')
        (folder/'parameters.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
        if self.real is not None:Image.fromarray(self.real).save(folder/'measured.png')
        Image.fromarray(sim.image).save(folder/'simulated.png');self.image(sim,(960,620)).save(folder/'comparison.png')
        with (folder/'points.csv').open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=['x_mm','y_mm','u_px','v_px']);writer.writeheader();writer.writerows(self.points)
        return folder
