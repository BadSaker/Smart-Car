import os,sys,json,time,argparse
from pathlib import Path
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--direction',required=True);args=parser.parse_args()
sys.path.insert(0,str(ROOT/'baseline'))
from parameters import load
from engine import Simulation
from render import camera_image,map_image
p=load(ROOT/'baseline/configs/我的参数.json');p['direction']=args.direction
s=Simulation(p);s.started=True;start=time.perf_counter();events=[];previous=None
output=ROOT/('baseline-'+('AB' if args.direction=='A→B' else 'BA'));output.mkdir(exist_ok=True)
for index in range(18000):
    s.tick()
    signature=(int(s.data[7]),int(s.data[0]),int(s.data[1]))
    if signature!=previous:
        entry={'time_s':s.now/1000,'progress_m':s.route_progress,'distance_m':s.distance,
          'element':signature[0],'state':signature[1],'fault':signature[2],
          'q':int(s.data[3]),'near':int(s.data[5]),'far':int(s.data[6]),
          'steering':int(s.data[11]),'target_speed':float(s.data[14])}
        events.append(entry)
        if signature[0]>=3 or signature[2]:
            name=f'event-{len(events):04d}'
            Image.fromarray(s.image).save(output/(name+'.png'))
            camera_image(s).save(output/(name+'-overlay.png'))
        previous=signature
    if s.completed or s.stop_capture_complete:break
result=s.result();result.update(progress_m=s.route_progress,wall_s=time.perf_counter()-start)
(output/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
(output/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2),encoding='utf-8')
(output/'history.json').write_text(json.dumps(s.history,ensure_ascii=False),encoding='utf-8')
Image.fromarray(s.image).save(output/'last-frame.png');camera_image(s).save(output/'last-overlay.png');map_image(s,(1100,800)).save(output/'map.png')
print(json.dumps({'direction':args.direction,**{k:result[k] for k in ('completed','time_s','distance_m','progress_m','max_error_m','max_outside_wheels','state','fault','wall_s')},'ring_events':[e for e in events if e['element']>=3][:20]},ensure_ascii=False),flush=True)
