#ifndef AUTOCAR_MOTOR_CONTROL_H
#define AUTOCAR_MOTOR_CONTROL_H

#include <stdint.h>

typedef enum
{
    MOTOR_TEST_IDLE = 0,
    MOTOR_TEST_CHANNEL1,
    MOTOR_TEST_GAP1,
    MOTOR_TEST_CHANNEL2,
    MOTOR_TEST_GAP2,
    MOTOR_TEST_BOTH,
    MOTOR_TEST_COMPLETE,
    MOTOR_TEST_STOPPED,
    MOTOR_TEST_CONFIG_ERROR
} motor_test_state_t;

typedef struct
{
    motor_test_state_t state;
    uint8_t ready;
    uint8_t telemetry_visible;
    uint16_t duty_permille;
    uint32_t elapsed_ms;
    uint32_t run_id;
} motor_control_status_t;

/* 主循环初始化时调用一次：参考DIR、17kHz零占空比、S5/S3上拉。
 * 此时未开放启动。配置无效时保持零命令并进入CONFIG_ERROR。 */
void motor_control_init(void);

/* 摄像头及外设初始化完成后由主循环调用；重复调用无副作用。
 * 只开放按键测试，仍须此后稳定释放S5再新按下；不直接产生运动命令。 */
void motor_control_enable_test(void);

/* 仅PIT0每10ms调用：按键消抖、阶段计时、PWM更新均在此推进。
 * S3低电平不消抖，优先发出零PWM；C12新按下启动或取消当前测试。
 * 主循环阻塞不会暂停计时，关中断或更高优先级阻塞仍会延后处理。
 * 零PWM不是供电切断，可能制动，不能据此保证滑行、高阻或物理停转。 */
void motor_control_tick_10ms(void);

/* 主循环原子地取走S3停止标志；短按后主循环才恢复时仍能收到一次。
 * 返回1时调用原舵机停止接口；舵机动作仍取决于主循环恢复时刻。 */
uint8_t motor_control_take_servo_stop(void);

/* 主循环获取一致快照；out为空时不操作。短临界区保留调用前PRIMASK。
 * duty_permille表示命令值，间隔与结束为0；elapsed_ms为本轮总时长。
 * 运行中及完成/停止后5s展示遥测；run_id仅在新一轮启动时递增。 */
void motor_control_get_status(motor_control_status_t *out);

#endif /* AUTOCAR_MOTOR_CONTROL_H */
