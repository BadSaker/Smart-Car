#include "motor_control.h"
#include "motor_test_config.h"
#include "encoder_feedback.h"
#include "zf_driver_gpio.h"
#include "zf_driver_pwm.h"

static volatile motor_control_status_t motor_status;
static volatile uint8_t motor_initialized;
static volatile uint8_t motor_servo_stop_pending;
static volatile uint8_t motor_start_sample;
static volatile uint8_t motor_start_stable;
static volatile uint8_t motor_start_armed;
static volatile uint16_t motor_key_stable_ms;
static uint16_t motor_phase_elapsed_ms;
static uint16_t motor_result_remaining_ms;
static uint32_t motor_test_pwm_duty;

static uint8_t motor_config_is_valid(void)
{
    return (MOTOR_CONTROL_TICK_MS == 10U &&
            MOTOR_TEST_DUTY_PERMILLE >= 1 &&
            MOTOR_TEST_DUTY_PERMILLE <= MOTOR_TEST_MAX_DUTY_PERMILLE) ? 1U : 0U;
}

static void motor_reset_start_key(void)
{
    /* 撤销旧按下和释放历史；上电按住或初始化期间按住都不能自动启动。 */
    motor_start_sample = MOTOR_TEST_KEY_ACTIVE_LEVEL;
    motor_start_stable = MOTOR_TEST_KEY_ACTIVE_LEVEL;
    motor_start_armed = 0U;
    motor_key_stable_ms = 0U;
}

static uint8_t motor_test_is_running(void)
{
    return (motor_status.state >= MOTOR_TEST_CHANNEL1 &&
            motor_status.state <= MOTOR_TEST_BOTH) ? 1U : 0U;
}

static void motor_write_output(uint8_t channel1, uint8_t channel2)
{
    pwm_set_duty(MOTOR_CHANNEL1_PWM, channel1 ? motor_test_pwm_duty : 0U);
    pwm_set_duty(MOTOR_CHANNEL2_PWM, channel2 ? motor_test_pwm_duty : 0U);
    motor_status.duty_permille = (channel1 || channel2) ? (uint16_t)MOTOR_TEST_DUTY_PERMILLE : 0U;
}

static void motor_finish(motor_test_state_t state)
{
    motor_write_output(0U, 0U);
    motor_status.state = state;
    motor_phase_elapsed_ms = 0U;
    motor_reset_start_key();
    if (motor_status.run_id != 0U)
    {
        motor_status.telemetry_visible = 1U;
        motor_result_remaining_ms = MOTOR_TEST_RESULT_HOLD_MS;
    }
}

void motor_control_init(void)
{
    uint32_t interrupt_mask = __get_PRIMASK();
    __disable_irq();
    motor_initialized = 0U;
    __set_PRIMASK(interrupt_mask);

    /* 初始化外设不持有全局中断屏蔽；门控使并发PIT不能更新未初始化PWM。 */
    gpio_init(MOTOR_CHANNEL1_PWM_PIN, GPO, GPIO_LOW, GPO_PUSH_PULL);
    gpio_init(MOTOR_CHANNEL2_PWM_PIN, GPO, GPIO_LOW, GPO_PUSH_PULL);
    gpio_init(MOTOR_CHANNEL1_DIRECTION_PIN, GPO, MOTOR_CHANNEL1_REFERENCE_LEVEL, GPO_PUSH_PULL);
    gpio_init(MOTOR_CHANNEL2_DIRECTION_PIN, GPO, MOTOR_CHANNEL2_REFERENCE_LEVEL, GPO_PUSH_PULL);
    pwm_init(MOTOR_CHANNEL1_PWM, MOTOR_TEST_PWM_FREQUENCY_HZ, 0U);
    pwm_init(MOTOR_CHANNEL2_PWM, MOTOR_TEST_PWM_FREQUENCY_HZ, 0U);
    gpio_init(MOTOR_TEST_START_KEY_PIN, GPI, GPIO_HIGH, GPI_PULL_UP);
    gpio_init(MOTOR_TEST_STOP_KEY_PIN, GPI, GPIO_HIGH, GPI_PULL_UP);

    motor_test_pwm_duty = motor_config_is_valid() ?
        (uint32_t)((uint64_t)PWM_DUTY_MAX * MOTOR_TEST_DUTY_PERMILLE / 1000U) : 0U;
    interrupt_mask = __get_PRIMASK();
    __disable_irq();
    motor_status.state = motor_config_is_valid() ? MOTOR_TEST_IDLE : MOTOR_TEST_CONFIG_ERROR;
    motor_status.ready = 0U;
    motor_status.telemetry_visible = motor_config_is_valid() ? 0U : 1U;
    motor_status.duty_permille = 0U;
    motor_status.elapsed_ms = 0U;
    motor_status.run_id = 0U;
    motor_servo_stop_pending = 0U;
    motor_phase_elapsed_ms = 0U;
    motor_result_remaining_ms = 0U;
    motor_reset_start_key();
    motor_initialized = 1U;
    __set_PRIMASK(interrupt_mask);
}

void motor_control_enable_test(void)
{
    uint32_t interrupt_mask = __get_PRIMASK();
    __disable_irq();
    if (motor_initialized && motor_config_is_valid() && !motor_status.ready)
    {
        motor_reset_start_key();
        motor_status.ready = 1U;
    }
    __set_PRIMASK(interrupt_mask);
}

static uint8_t motor_start_key_pressed(void)
{
    uint8_t sample = gpio_get_level(MOTOR_TEST_START_KEY_PIN);
    if (sample != motor_start_sample)
    {
        motor_start_sample = sample;
        motor_key_stable_ms = 0U;
    }
    else if (motor_key_stable_ms < MOTOR_TEST_KEY_DEBOUNCE_MS)
    {
        motor_key_stable_ms += 10U;
    }
    if (motor_key_stable_ms < MOTOR_TEST_KEY_DEBOUNCE_MS) return 0U;
    if (sample != MOTOR_TEST_KEY_ACTIVE_LEVEL)
    {
        motor_start_stable = sample;
        motor_start_armed = 1U;
    }
    else if (motor_start_stable != MOTOR_TEST_KEY_ACTIVE_LEVEL)
    {
        motor_start_stable = sample;
        if (motor_start_armed)
        {
            motor_start_armed = 0U;
            return 1U;
        }
    }
    return 0U;
}

static void motor_begin_test(void)
{
    motor_status.state = MOTOR_TEST_CHANNEL1;
    motor_status.elapsed_ms = 0U;
    ++motor_status.run_id;
    motor_status.telemetry_visible = 1U;
    motor_phase_elapsed_ms = 0U;
    motor_result_remaining_ms = 0U;
    /* 只复位编码器软件累计；硬件计数器持续运行。必须先于非零PWM。 */
    encoder_feedback_reset_totals();
    motor_write_output(1U, 0U);
}

void motor_control_tick_10ms(void)
{
    if (!motor_initialized) return;
    if (motor_result_remaining_ms != 0U)
    {
        motor_result_remaining_ms -= 10U;
        if (motor_result_remaining_ms == 0U) motor_status.telemetry_visible = 0U;
    }

    /* 停止优先且不消抖。持续按住也只保持命令为零，不重复刷新结果保留时间。 */
    if (gpio_get_level(MOTOR_TEST_STOP_KEY_PIN) == MOTOR_TEST_KEY_ACTIVE_LEVEL)
    {
        motor_servo_stop_pending = 1U;
        motor_reset_start_key();
        if (motor_status.state != MOTOR_TEST_STOPPED && motor_status.state != MOTOR_TEST_CONFIG_ERROR)
            motor_finish(MOTOR_TEST_STOPPED);
        return;
    }
    if (!motor_status.ready) return;

    if (motor_start_key_pressed())
    {
        if (motor_test_is_running())
        {
            motor_finish(MOTOR_TEST_STOPPED);
            return;
        }
        if (motor_status.state == MOTOR_TEST_IDLE || motor_status.state == MOTOR_TEST_COMPLETE ||
            motor_status.state == MOTOR_TEST_STOPPED)
        {
            motor_begin_test();
            return;
        }
    }
    if (motor_test_is_running())
    {
        motor_status.elapsed_ms += 10U;
        motor_phase_elapsed_ms += 10U;
    }
    switch (motor_status.state)
    {
        case MOTOR_TEST_CHANNEL1:
            if (motor_phase_elapsed_ms >= MOTOR_TEST_CHANNEL_DURATION_MS)
            {
                motor_write_output(0U, 0U);
                motor_status.state = MOTOR_TEST_GAP1;
                motor_phase_elapsed_ms = 0U;
            }
            break;
        case MOTOR_TEST_GAP1:
            if (motor_phase_elapsed_ms >= MOTOR_TEST_GAP_DURATION_MS)
            {
                motor_write_output(0U, 1U);
                motor_status.state = MOTOR_TEST_CHANNEL2;
                motor_phase_elapsed_ms = 0U;
            }
            break;
        case MOTOR_TEST_CHANNEL2:
            if (motor_phase_elapsed_ms >= MOTOR_TEST_CHANNEL_DURATION_MS)
            {
                motor_write_output(0U, 0U);
                motor_status.state = MOTOR_TEST_GAP2;
                motor_phase_elapsed_ms = 0U;
            }
            break;
        case MOTOR_TEST_GAP2:
            if (motor_phase_elapsed_ms >= MOTOR_TEST_GAP_DURATION_MS)
            {
                motor_write_output(1U, 1U);
                motor_status.state = MOTOR_TEST_BOTH;
                motor_phase_elapsed_ms = 0U;
            }
            break;
        case MOTOR_TEST_BOTH:
            if (motor_phase_elapsed_ms >= MOTOR_TEST_CHANNEL_DURATION_MS)
                motor_finish(MOTOR_TEST_COMPLETE);
            break;
        case MOTOR_TEST_IDLE:
        case MOTOR_TEST_COMPLETE:
        case MOTOR_TEST_STOPPED:
        case MOTOR_TEST_CONFIG_ERROR:
            break;
        default:
            motor_write_output(0U, 0U);
            motor_status.state = MOTOR_TEST_CONFIG_ERROR;
            motor_status.ready = 0U;
            motor_status.telemetry_visible = 1U;
            motor_reset_start_key();
            break;
    }
}

uint8_t motor_control_take_servo_stop(void)
{
    uint8_t pending;
    uint32_t interrupt_mask = __get_PRIMASK();
    __disable_irq();
    pending = motor_servo_stop_pending;
    motor_servo_stop_pending = 0U;
    __set_PRIMASK(interrupt_mask);
    return pending;
}

void motor_control_get_status(motor_control_status_t *out)
{
    uint32_t interrupt_mask;
    if (out == 0) return;
    interrupt_mask = __get_PRIMASK();
    __disable_irq();
    *out = motor_status;
    __set_PRIMASK(interrupt_mask);
}
