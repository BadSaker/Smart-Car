import sys,json,zipfile,os
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parent;project=root.parents[1]
os.environ['SIMULATION_CC']=str(project/'simulation/toolchain/mingw64/bin/gcc.exe')
sys.path.insert(0,str(root/sys.argv[1]))
from parameters import load
from native import Native
p=load(root/sys.argv[1]/'configs/我的参数.json');p.update(kp=28.,kd=.5,cruise=250.,curve_speed=160.,outer_speed=120.)
n=Native(p)
with zipfile.ZipFile(project/'car/tests/fixtures/element-sequences.zip') as z:
 meta=json.loads(z.read('metadata.json'));info=meta['segments'][sys.argv[2]];frames=np.frombuffer(z.read(info['file']),np.uint8).reshape(-1,120,188)
for i,frame in enumerate(frames):
 n.vision(frame,i*20,info['distances_mm'][i]);v,rows=n.data()
 if i%25==0 or i==len(frames)-1:
  print(i*20,info['distances_mm'][i],int(v[7]),int(v[4]),int(v[3]),int(v[5]),int(v[6]),n.features['element_bridged'],sum(rows[3,86:109]&3==3))
im=Image.fromarray(frame).convert('RGB');d=ImageDraw.Draw(im)
for r in range(30,117):
 d.point((int(rows[2,r]),r),fill=(0,255,0) if rows[3,r]&16 else (255,0,0))
 if rows[3,r]&1:d.point((int(rows[0,r]),r),fill=(255,0,255))
 if rows[3,r]&2:d.point((int(rows[1,r]),r),fill=(0,120,255))
im.resize((752,480)).save(root/'fixture-overlay.png')
for r in range(30,117,5):print(r,rows[:,r].tolist(),int(frame[r,rows[2,r]]),np.where(np.diff((frame[r]>v[17]).astype(int))!=0)[0].tolist())
