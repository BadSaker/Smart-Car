import os,sys,json,re,shutil,time
from pathlib import Path
os.environ['OPENBLAS_NUM_THREADS']='1'
ROOT=Path(__file__).resolve().parent;folder=ROOT/'speed-bench'
shutil.copytree(ROOT/'baseline',folder,dirs_exist_ok=True)
sys.path.insert(0,str(folder));os.environ['SIMULATION_CC']=str(ROOT.parents[1]/'simulation/toolchain/mingw64/bin/gcc.exe')
import numpy as np
from parameters import load
from engine import Simulation
original=(folder/'vendor/config/autonomous_config.h').read_text(encoding='utf-8')
results=[]
for target,cap in ((180,200),(250,250),(300,300),(350,300),(400,300)):
 text=re.sub(r'(^#define\s+AUTO_MAX_DUTY_PERMILLE\s+)[^\r\n]+',lambda m:m[1]+str(cap)+'U',original,flags=re.M)
 (folder/'vendor/config/autonomous_config.h').write_text(text,encoding='utf-8')
 p=load(folder/'configs/我的参数.json');p.update(scenario='straight',cruise=target)
 s=Simulation(p);s.started=True;start=time.perf_counter()
 for _ in range(1500):s.tick()
 samples=s.history[-60:]
 r={'target_mm_s':target,'duty_cap_permille':cap,'steady_speed_mm_s':float(np.mean([v['speed_mm_s'] for v in samples])),
 'steady_pwm':float(np.mean([v['left_pwm'] for v in samples])),
 'theoretical_model_cap_mm_s':(cap-p['motor_deadzone'])*p['motor_gain'],
 'state':s.result()['state'],'fault':s.result()['fault'],'wall_s':time.perf_counter()-start}
 results.append(r);print(json.dumps(r,ensure_ascii=False),flush=True)
(ROOT/'speed-probe.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
