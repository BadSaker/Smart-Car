import sys,json,os
from pathlib import Path
root_path=Path(__file__).resolve().parent
os.environ['SIMULATION_CC']=str(root_path.parents[1]/'simulation/toolchain/mingw64/bin/gcc.exe')
sys.path.insert(0,str(root_path/'ui-simulation'))
import tkinter as tk
from tkinter import messagebox
from app import App
from parameters import save,load
root=tk.Tk();root.withdraw();errors=[]
messagebox.showerror=lambda title,message:errors.append(str(message))
try:
 app=App(root);root.update_idletasks()
 assert 'element_speed' in app.vars and 'max_duty' in app.vars
 app.parameter_name.set('提速验证_350');app.select_params()
 assert app.sim.p['cruise']==350. and app.sim.p['element_speed']==180.
 app.vars['element_speed'].set('120');app.vars['max_duty'].set('250');app.reset()
 assert app.sim.p['element_speed']==120. and app.sim.p['max_duty']==250
 path=root_path/'ui-control-roundtrip.json';save(path,app.collect());p=load(path)
 assert p['element_speed']==120. and p['max_duty']==250
 app.parameter_name.set('我的参数');app.select_params();app.start()
 for _ in range(220):app.sim.tick()
 app.pause();assert app.sim.data[0]==2 and app.sim.distance>0
 app.vars['drop_camera'].set(True);app.inject()
 for _ in range(20):app.sim.tick()
 assert app.sim.data[1]==2
 assert not errors,errors
 report={'new_fields':True,'profile_load':True,'c_parameter_reset':True,'save_reload':True,'native_started':True,'camera_loss_from_ui':True}
 (root_path/'ui-verification.json').write_text(json.dumps(report),encoding='utf-8');print(report)
finally:root.destroy()
