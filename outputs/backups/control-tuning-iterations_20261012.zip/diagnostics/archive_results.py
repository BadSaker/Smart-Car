"""归档可复现实验、发布源码和结果；不收集工具链或其他任务目录。"""
from pathlib import Path
import json,re,zipfile
root=Path(__file__).resolve().parents[2]
task=root/'tmp/control-tuning'
assert task.resolve()==Path(__file__).resolve().parent
archive=root/'outputs/backups/control-tuning-iterations_20261012.zip'
items={}
def add(path,name):
    if path.is_file():items[name]=path
for path in task.iterdir():
    if path.is_file() and path.suffix in ('.py','.json','.log','.png','.md'):
        add(path,'diagnostics/'+path.name)
for name in ('candidates','segments','validation'):
    for path in (task/name).rglob('*'):
        if 'workspace' not in path.relative_to(task/name).parts and path.suffix in ('.json','.csv','.png'):
            add(path,'diagnostics/'+path.relative_to(task).as_posix())
for directory in task.iterdir():
    if directory.is_dir() and (directory/'native_bridge.c').exists() and directory.name!='ui-simulation':
        for path in directory.iterdir():
            if path.suffix in ('.py','.c'):add(path,'iterations/'+path.relative_to(task).as_posix())
        for category in ('src','include','config'):
            for path in (directory/'vendor'/category).glob('*'):
                add(path,'iterations/'+path.relative_to(task).as_posix())
        for path in (directory/'configs').glob('*.json'):add(path,'iterations/'+path.relative_to(task).as_posix())
for name in ('car/src/track_vision.c','car/src/autonomous_drive.c','car/include/track_vision.h',
             'car/config/vision_config.h','car/config/autonomous_config.h'):
    add(root/name,'release/'+name)
for path in (root/'car/tests').rglob('*'):
    if '__pycache__' not in path.parts:add(path,'release/'+path.relative_to(root).as_posix())
for path in (root/'simulation').iterdir():
    if path.is_file() and path.suffix in ('.py','.c','.md','.txt','.cmd','.ps1'):
        add(path,'release/'+path.relative_to(root).as_posix())
for name in ('configs','docs','assets','tests','tools','vendor'):
    for path in (root/'simulation'/name).rglob('*'):
        if '__pycache__' not in path.parts:add(path,'release/'+path.relative_to(root).as_posix())
for name in ('docs/autonomous-driving.md','docs/known-issues.md','docs/environment-and-build.md',
             'outputs/reports/control-tuning-final-2026-10-12.md',
             'logs/control-tuning-tests-2026-10-12.log','logs/control-tuning-simulator-2026-10-12.log',
             'logs/control-tuning-build-2026-10-12.log'):
    add(root/name,'release/'+name)
for path in (root/'outputs/reports/control-tuning-2026-10-12').iterdir():
    add(path,'release/'+path.relative_to(root).as_posix())
for extension in ('axf','hex','bin'):
    name='outputs/firmware/autocar.'+extension;add(root/name,'release/'+name)
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as package:
    for name,path in sorted(items.items()):package.write(path,name)
    package.writestr('README.txt','2026-10-12 控制优化证据包。release为最终源码/固件/报告；iterations为隔离试验版本；diagnostics含失败与成功闭环、灰度夹具生成及完整遥测。初始6005帧缓存另在control-tuning-diagnostics_20261012_175808.zip。未归档第三方编译器，使用本机simulation/toolchain及D:/anaconda3/python.exe可复现。实车及3.6m/s未验收。')
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
print(json.dumps({'archive':str(archive),'files':len(items)+1,'bytes':archive.stat().st_size,'crc':'pass'},ensure_ascii=True))
