import json, shutil, sys, os, re
from pathlib import Path
root=Path(__file__).resolve().parent
project=root.parents[1]
name=sys.argv[1]
dest=root/name
if not dest.exists():shutil.copytree(root/'baseline',dest)
for name in ('src/track_vision.c','src/autonomous_drive.c','include/track_vision.h','config/vision_config.h','config/autonomous_config.h'):
 shutil.copy2(project/'car'/name,dest/'vendor'/name)
for name in ('native.py','native_bridge.c','engine.py','parameters.py'):
 shutil.copy2(project/'simulation'/name,dest/name)
config=dest/'vendor/config/autonomous_config.h'
data=config.read_text(encoding='utf-8')
for key,value in {'AUTO_MAX_DUTY_PERMILLE':'300U','AUTO_ELEMENT_SPEED_MM_S':'140.0f','AUTO_MAX_RUN_TIME_MS':'480000U','AUTO_SERVO_STEP_US':'12U'}.items():
 data=re.sub(r'(#define\s+'+key+r'\s+)\S+',lambda m:m[1]+value,data)
config.write_text(data,encoding='utf-8')
pfile=dest/'configs/我的参数.json';p=json.loads(pfile.read_text(encoding='utf-8-sig'));p.update(servo_step=12.,element_speed=140.,max_duty=300);pfile.write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
os.environ['SIMULATION_CC']=str(project/'simulation/toolchain/mingw64/bin/gcc.exe')
sys.path.insert(0,str(dest))
from parameters import load
from native import Native
p=load(pfile);p.update(kp=28.,kd=.5,cruise=250.,curve_speed=160.,outer_speed=120.)
Native(p)
print(dest)
