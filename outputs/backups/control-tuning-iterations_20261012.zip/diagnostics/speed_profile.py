import shutil,sys,os,re,json
from pathlib import Path
root=Path(__file__).resolve().parent;project=root.parents[1]
name=sys.argv[1];cruise,curve,outer,element,duty=map(float,sys.argv[2:])
dest=root/name;shutil.copytree(root/'v23',dest,dirs_exist_ok=True)
file=dest/'vendor/config/autonomous_config.h';text=file.read_text(encoding='utf-8')
for key,value in {'AUTO_ELEMENT_SPEED_MM_S':f'{element}f','AUTO_MAX_DUTY_PERMILLE':f'{int(duty)}U'}.items():
 text=re.sub(r'(#define\s+'+key+r'\s+)\S+',lambda m:m[1]+value,text)
file.write_text(text,encoding='utf-8')
os.environ['SIMULATION_CC']=str(project/'simulation/toolchain/mingw64/bin/gcc.exe');sys.path.insert(0,str(dest))
from parameters import load
from native import Native
p=load(dest/'configs/我的参数.json');p.update(kp=28.,kd=.5,cruise=cruise,curve_speed=curve,outer_speed=outer,element_speed=element,max_duty=int(duty))
(dest/'configs/我的参数.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
Native(p);print(name)
