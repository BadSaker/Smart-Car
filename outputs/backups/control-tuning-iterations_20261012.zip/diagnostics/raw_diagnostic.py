import ctypes as C,json,zipfile,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent;project=root.parents[1]
wrapper=root/'raw-diagnostic.c';dll=root/'raw-diagnostic.dll'
wrapper.write_text('#include "'+(project/'car/src/track_vision.c').as_posix()+'''"
__declspec(dllexport) void frame(const unsigned char *p,unsigned ms,unsigned mm,int *v) {
 track_vision_result_t o;vision_features_t f;
 track_vision_process(p,ms,mm,&o);v[0]=o.element;v[1]=o.valid;v[2]=mm-vision.phase_mm;
 memset(&o,0,sizeof o);o.threshold=200;o.zebra_near_row=255;
 vision_scan(p,&o,&f,TRACK_SIDE_NONE);vision_path_quality(&o,&f);
 v[3]=o.valid;v[4]=o.confidence;v[5]=o.near_path_supported;v[6]=f.measured_rows;v[7]=f.paired_rows;
 v[8]=vision_gap(f.left_open,&o,1,&f.left_bottom);v[9]=vision_gap(f.right_open,&o,2,&f.right_bottom);
 v[10]=vision_opposite_continuous(f.left_open,&o,TRACK_SIDE_LEFT);v[11]=vision_opposite_continuous(f.right_open,&o,TRACK_SIDE_RIGHT);
 v[12]=f.left_bottom;v[13]=f.right_bottom;v[14]=vision.exit_seen;v[15]=vision.exit_seen_mm;v[16]=vision.ring_path_valid;
}
''',encoding='utf-8')
subprocess.run([str(project/'simulation/toolchain/mingw64/bin/gcc.exe'),'-shared','-O2','-I'+str(project/'car/include'),'-I'+str(project/'car/config'),str(wrapper),'-o',str(dll)],check=True)
lib=C.CDLL(str(dll));lib.frame.argtypes=[C.POINTER(C.c_ubyte),C.c_uint,C.c_uint,C.POINTER(C.c_int)]
with zipfile.ZipFile(project/'car/tests/fixtures/element-sequences.zip') as z:meta=json.loads(z.read('metadata.json'));info=meta['segments'][sys.argv[1]];data=bytearray(z.read(info['file']))
v=(C.c_int*17)()
for i,mm in enumerate(info['distances_mm']):
 pixels=(C.c_ubyte*(188*120)).from_buffer(data,i*188*120);lib.frame(pixels,i*20,mm,v)
 if i%10==0 and i*20>19000:print(i*20,list(v))
