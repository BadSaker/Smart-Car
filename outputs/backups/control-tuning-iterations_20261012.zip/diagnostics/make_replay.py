import os,sys,json,time
from pathlib import Path
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'baseline'))
from parameters import load
from geometry import Track
p=load(ROOT/'baseline/configs/我的参数.json');p['noise']=0;p['disturbance_level']=0
t=Track(p);angles=np.unwrap(t.samples[:,2])
distances=np.arange(0,t.length,.005)
positions=np.column_stack([np.interp(distances,t.samples[:,3],t.samples[:,j]) for j in (0,1)])
headings=np.interp(distances,t.samples[:,3],angles)
out=ROOT/'reference-frames.npy';frames=np.lib.format.open_memmap(out,mode='w+',dtype=np.uint8,shape=(len(distances),120,188))
start=time.perf_counter()
for i,(xy,h) in enumerate(zip(positions,headings)):
 frames[i]=t.camera(xy[0],xy[1],h,p)
 if i%1000==0:print(i,len(distances),round(time.perf_counter()-start,1),flush=True)
frames.flush()
np.save(ROOT/'reference-distances.npy',distances)
(ROOT/'reference-parts.json').write_text(json.dumps(t.parts,indent=2),encoding='utf-8')
print('done',len(distances),time.perf_counter()-start)
