import os,sys,json,argparse,time,math
from pathlib import Path
os.environ['OPENBLAS_NUM_THREADS']='1'
ROOT=Path(__file__).resolve().parent
os.environ['SIMULATION_CC']=str(ROOT.parents[1]/'simulation/toolchain/mingw64/bin/gcc.exe')
import numpy as np
from PIL import Image
parser=argparse.ArgumentParser()
parser.add_argument('--workspace',default='v8');parser.add_argument('--direction',default='AB')
parser.add_argument('--start',type=float,required=True);parser.add_argument('--length',type=float,required=True)
parser.add_argument('--offset',type=float,default=0);parser.add_argument('--heading',type=float,default=0)
parser.add_argument('--kp',type=float,default=28);parser.add_argument('--kd',type=float,default=.5)
parser.add_argument('--cruise',type=float,default=250);parser.add_argument('--curve',type=float,default=160);parser.add_argument('--outer',type=float,default=120)
args=parser.parse_args();sys.path.insert(0,str(ROOT/args.workspace))
from parameters import load
from engine import Simulation
p=load(ROOT/args.workspace/'configs/我的参数.json');p.update(kp=float(args.kp),kd=float(args.kd),cruise=float(args.cruise),curve_speed=float(args.curve),outer_speed=float(args.outer),direction='A→B' if args.direction=='AB' else 'B→A')
s=Simulation(p);points=s.track.samples
h=float(np.interp(args.start,points[:,3],np.unwrap(points[:,2])))
s.x=float(np.interp(args.start,points[:,3],points[:,0]))-math.sin(h)*args.offset
s.y=float(np.interp(args.start,points[:,3],points[:,1]))+math.cos(h)*args.offset
s.h=h+math.radians(args.heading);s.route_progress=args.start
# 已知赛道位置只用来摆放测试车辆和评分，不传给C算法。
s.native.lib.sim_reset();s.frame_id=0;s.frame_buffer.clear();s.history=[];s.trajectory=[(s.x,s.y)]
s._frame();s.data,s.rows=s.native.data();s.capture_frame();s.record();s.started=True
start=time.perf_counter();events=[];last=None;captures=[]
for _ in range(18000):
 s.tick();phase=int(s.data[7])
 if phase!=last:
  if phase>=2:
   events.append({'t':s.now/1000,'s':s.route_progress,'element':phase,'pose':[s.x,s.y,s.h],'distance_m':s.distance,**s.native.features})
   captures.append(s.image.copy())
  last=phase
 if s.stop_capture_complete or s.route_progress>=args.start+args.length or s.max_outside>=2 or s.max_error>.4:break
r=s.result();r={k:r[k] for k in ('time_s','distance_m','max_error_m','max_outside_wheels','state','fault')}
r.update(parameters=vars(args),progress_m=s.route_progress,segment_pass=s.route_progress>=args.start+args.length and s.max_outside<2 and s.max_error<=.25,wall_s=time.perf_counter()-start,events=events)
name=f'{args.workspace}-{args.direction}-s{args.start:g}-l{args.length:g}-o{args.offset:g}-h{args.heading:g}-k{args.kp:g}-d{args.kd:g}'
folder=ROOT/'segments'/name;folder.mkdir(parents=True,exist_ok=True)
(folder/'result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/'history.json').write_text(json.dumps(s.history,ensure_ascii=False),encoding='utf-8')
Image.fromarray(s.stop_image if s.stop_event else s.image).save(folder/'last-frame.png')
for i,im in enumerate(captures):Image.fromarray(im).save(folder/f'event-{i:03d}.png')
print(json.dumps(r,ensure_ascii=False),flush=True)
