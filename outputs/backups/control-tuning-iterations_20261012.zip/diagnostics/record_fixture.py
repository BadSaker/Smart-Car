import sys,json,zipfile,math
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent;project=root.parents[1]
sys.path.insert(0,str(root/'v9'))
from parameters import load
from geometry import Track
p=load(root/'v9/configs/我的参数.json')
name,folder,end=sys.argv[1],sys.argv[2],float(sys.argv[3])
h=json.loads((root/'segments'/folder/'history.json').read_text())
p['direction']='B→A' if '-BA-' in folder else 'A→B'
track=Track(p);times=np.array([r['time_s'] for r in h]);frames=[];distances=[]
for t in np.arange(0,end+.001,.02):
 vals=[np.interp(t,times,[r[k] for r in h]) for k in ('x_m','y_m','heading_deg','distance_m')]
 frames.append(track.camera(vals[0],vals[1],math.radians(vals[2]),p,np.random.default_rng(42)).tobytes());distances.append(round(vals[3]*1000))
path=project/'car/tests/fixtures/element-sequences.zip'
with zipfile.ZipFile(path) as z:contents={n:z.read(n) for n in z.namelist()}
meta=json.loads(contents['metadata.json']);meta['segments'][name]={'file':name+'.gray','frames':len(frames),'distances_mm':distances,'source':folder,'description':'实际闭环轨迹按20ms插值重投影，仅作为冻结图像回归输入'}
contents['metadata.json']=json.dumps(meta,ensure_ascii=False).encode();contents[name+'.gray']=b''.join(frames)
with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
 for n,data in contents.items():z.writestr(n,data)
print(name,len(frames))
