import os,sys,json,re,ctypes as C,time
from pathlib import Path
os.environ['OPENBLAS_NUM_THREADS']='1'
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'bench'))
os.environ['SIMULATION_CC']=str(ROOT.parents[1]/'simulation/toolchain/mingw64/bin/gcc.exe')
import numpy as np
from parameters import load
from native import Native
p=load(ROOT/'bench/configs/我的参数.json')
frames=np.load(ROOT/'reference-frames.npy',mmap_mode='r');distance=np.load(ROOT/'reference-distances.npy')
original=(ROOT/'baseline/vendor/config/vision_config.h').read_text(encoding='utf-8')
cases=[('baseline',{}),('confirm6',{'VISION_RING_CONFIRM_FRAMES':6}),
 ('confirm12',{'VISION_RING_CONFIRM_FRAMES':12}),
 ('opening18',{'VISION_OPENING_MIN_ROWS':18}),('opening24',{'VISION_OPENING_MIN_ROWS':24}),
 ('opening32',{'VISION_OPENING_MIN_ROWS':32}),
 ('window34',{'VISION_EDGE_WINDOW_PX':34}),('window42',{'VISION_EDGE_WINDOW_PX':42}),
 ('opposite95',{'VISION_OPPOSITE_CONTINUITY_PERCENT':95}),
 ('balanced',{'VISION_OPENING_MIN_ROWS':18,'VISION_EDGE_WINDOW_PX':34,'VISION_OPPOSITE_CONTINUITY_PERCENT':90,'VISION_RING_CONFIRM_FRAMES':5}),
 ('strict',{'VISION_OPENING_MIN_ROWS':24,'VISION_EDGE_WINDOW_PX':42,'VISION_OPPOSITE_CONTINUITY_PERCENT':95,'VISION_RING_CONFIRM_FRAMES':6}),
 ('entry_early',{'VISION_RING_ENTRY_ROW':80}),('match_projection',{})]
segments=[('curve_entry',0.,2.5,False),('u_curves',3.3,7.5,False),('s_bends',25.7,29.8,False),
          ('ring_center',12.6,16.5,True),('ring_right',20.3,25.,True)]
all_results=[];start=time.perf_counter()
for name,overrides in cases:
 text=original
 for key,value in overrides.items():
  text,count=re.subn(r'(^#define\s+'+key+r'\s+)[^\r\n]+',lambda m:m[1]+str(value),text,flags=re.M);assert count==1,key
 (ROOT/'bench/vendor/config/vision_config.h').write_text(text,encoding='utf-8')
 q=p.copy()
 if name=='match_projection':q.update(width_top=41,width_bottom=164)
 native=Native(q);debug=(C.c_float*16)();native.lib.tuning_data.argtypes=[C.POINTER(C.c_float)]
 report={'name':name,'overrides':overrides,'segments':[]}
 for title,lo,hi,expected_ring in segments:
  native.lib.sim_reset();indices=np.flatnonzero((distance>=lo)&(distance<hi));transitions=[];last=None;phases=[];faults=0;evidence=[]
  for step,i in enumerate(indices):
   native.vision(frames[i],step*20,round(distance[i]*1000));data,rows=native.data();native.lib.tuning_data(debug)
   phase=int(data[7]);phases.append(phase);faults+=int(bool(data[20]))
   if phase!=last:
    transitions.append({'s':round(float(distance[i]),3),'element':phase,'q':int(data[3]),'debug':list(debug)});last=phase
   if (debug[0] or debug[1]) and len(evidence)<8:evidence.append({'s':round(float(distance[i]),3),'debug':list(debug)})
  item={'segment':title,'expected_ring':expected_ring,'ring_candidate_fraction':sum(v>=3 for v in phases)/len(phases),
    'entered':4 in phases,'inside':5 in phases,'exit':6 in phases,'fault_frames':faults,
    'transitions':transitions,'opening_samples':evidence}
  report['segments'].append(item)
 all_results.append(report)
 (ROOT/'parameter-probe.json').write_text(json.dumps(all_results,ensure_ascii=False,indent=2),encoding='utf-8')
 print(name,[(r['segment'],round(r['ring_candidate_fraction'],2),r['entered'],r['inside'],r['exit']) for r in report['segments']],flush=True)
print('wall_s',time.perf_counter()-start)
