import os,sys,json,argparse,time
from pathlib import Path
os.environ['OPENBLAS_NUM_THREADS']='1'
ROOT=Path(__file__).resolve().parent
os.environ['SIMULATION_CC']=str(ROOT.parents[1]/'simulation/toolchain/mingw64/bin/gcc.exe')
parser=argparse.ArgumentParser();parser.add_argument('--kp',type=float,required=True);parser.add_argument('--kd',type=float,required=True)
parser.add_argument('--workspace',default='v2');parser.add_argument('--direction',default='AB');parser.add_argument('--checkpoint',type=float,default=4.5)
parser.add_argument('--seconds',type=float,default=180);parser.add_argument('--cruise',type=float,default=180);parser.add_argument('--curve',type=float,default=120);parser.add_argument('--outer',type=float,default=80)
args=parser.parse_args();sys.path.insert(0,str(ROOT/args.workspace))
from parameters import load
from engine import Simulation
p=load(ROOT/args.workspace/'configs/我的参数.json')
p.update(kp=args.kp,kd=args.kd,cruise=args.cruise,curve_speed=args.curve,outer_speed=args.outer,direction='A→B' if args.direction=='AB' else 'B→A')
s=Simulation(p);s.started=True;start=time.perf_counter();events=[];last=None
for _ in range(int(args.seconds*100)):
 s.tick();phase=int(s.data[7])
 if phase!=last:
  if phase>=2:events.append({'t':s.now/1000,'s':s.route_progress,'element':phase,'pose':[s.x,s.y,s.h],'distance_m':s.distance,**getattr(s.native,'features',{})})
  last=phase
 if s.completed or s.stop_capture_complete or s.route_progress>=args.checkpoint or s.max_outside>=2:break
r=s.result();r={k:r[k] for k in ('completed','time_s','distance_m','max_error_m','max_outside_wheels','state','fault')}
r.update(parameters=vars(args),progress_m=s.route_progress,wall_s=time.perf_counter()-start,ring_events=events)
name=f'{args.workspace}-{args.direction}-kp{args.kp:g}-kd{args.kd:g}-v{args.cruise:g}-c{args.curve:g}-s{args.checkpoint:g}'
folder=ROOT/'candidates';folder.mkdir(exist_ok=True)
(folder/(name+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
(folder/(name+'-history.json')).write_text(json.dumps(s.history[-200:],ensure_ascii=False),encoding='utf-8')
from PIL import Image
Image.fromarray(s.stop_image if s.stop_event else s.image).save(folder/(name+'-frame.png'))
print(json.dumps(r,ensure_ascii=False),flush=True)
