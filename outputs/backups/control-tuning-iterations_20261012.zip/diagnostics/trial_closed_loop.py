import os,sys,json,re,shutil,time,argparse
from pathlib import Path
os.environ['OPENBLAS_NUM_THREADS']='1'
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--variant',required=True);parser.add_argument('--direction',required=True);args=parser.parse_args()
folder=ROOT/('trial-'+args.variant+'-'+args.direction)
shutil.copytree(ROOT/'baseline',folder,dirs_exist_ok=True)
sys.path.insert(0,str(folder));os.environ['SIMULATION_CC']=str(ROOT.parents[1]/'simulation/toolchain/mingw64/bin/gcc.exe')
settings={
 'confirm40':({'VISION_RING_CONFIRM_FRAMES':40},{},{}),
 'strict':({'VISION_OPENING_MIN_ROWS':40,'VISION_RING_CONFIRM_FRAMES':12},{},{}),
 'fast':({'VISION_RING_CONFIRM_FRAMES':40},{'AUTO_MAX_DUTY_PERMILLE':300},{'cruise':300.,'curve_speed':220.,'outer_speed':160.}),
 'fast_pd':({'VISION_RING_CONFIRM_FRAMES':40},{'AUTO_MAX_DUTY_PERMILLE':300},{'cruise':300.,'curve_speed':220.,'outer_speed':160.,'kp':36.,'kd':.8})}
vision,control,params=settings[args.variant]
for name,values in (('vision_config.h',vision),('autonomous_config.h',control)):
 path=folder/'vendor/config'/name;text=path.read_text(encoding='utf-8')
 for key,value in values.items():
  text,n=re.subn(r'(^#define\s+'+key+r'\s+)[^\r\n]+',lambda m:m[1]+str(value)+'U',text,flags=re.M);assert n==1,key
 path.write_text(text,encoding='utf-8')
from parameters import load
from engine import Simulation
p=load(folder/'configs/我的参数.json');p.update(params);p['direction']='A→B' if args.direction=='AB' else 'B→A'
s=Simulation(p);s.started=True;start=time.perf_counter();events=[];last=None
for _ in range(18000):
 s.tick();phase=int(s.data[7])
 if phase!=last:
  if phase>=3:events.append({'time_s':s.now/1000,'progress':s.route_progress,'element':phase})
  last=phase
 if s.completed or s.stop_capture_complete:break
r=s.result();r={k:r[k] for k in ('completed','time_s','distance_m','max_error_m','max_outside_wheels','state','fault')}
r.update(variant=args.variant,direction=args.direction,progress_m=s.route_progress,wall_s=time.perf_counter()-start,ring_events=events)
(ROOT/f'closed-{args.variant}-{args.direction}.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(r,ensure_ascii=False),flush=True)
