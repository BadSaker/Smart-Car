#ifndef AUTOCAR_CAMERA_DEBUG_H
#define AUTOCAR_CAMERA_DEBUG_H

#include <stdint.h>
#include "camera_debug_config.h"

typedef enum
{
    CAMERA_DEBUG_DISABLED,
    CAMERA_DEBUG_READY,
    CAMERA_DEBUG_CONFIG_ERROR,
    CAMERA_DEBUG_INIT_ERROR,
    CAMERA_DEBUG_CONNECT_ERROR,
    CAMERA_DEBUG_SEND_ERROR,
    CAMERA_DEBUG_INITIALIZING,
    CAMERA_DEBUG_CONNECTING
} camera_debug_status_t;

typedef enum
{
    CAMERA_DEBUG_STAGE_NONE,
    CAMERA_DEBUG_STAGE_CONFIG,
    CAMERA_DEBUG_STAGE_WIFI,
    CAMERA_DEBUG_STAGE_TCP,
    CAMERA_DEBUG_STAGE_IMAGE_HEADER,
    CAMERA_DEBUG_STAGE_IMAGE,
    CAMERA_DEBUG_STAGE_BOUNDARY_HEADER,
    CAMERA_DEBUG_STAGE_LEFT,
    CAMERA_DEBUG_STAGE_MIDDLE,
    CAMERA_DEBUG_STAGE_RIGHT,
    CAMERA_DEBUG_STAGE_RECEIVE
} camera_debug_stage_t;

extern volatile camera_debug_status_t camera_debug_status;
extern volatile uint32_t camera_debug_frames_sent;
extern volatile uint32_t camera_debug_frames_dropped;
extern volatile uint32_t camera_debug_error_count;
extern volatile uint32_t camera_debug_reconnect_count;
extern volatile camera_debug_stage_t camera_debug_last_error_stage;
extern volatile uint32_t camera_debug_last_remaining;

/* 只登记配置和缓冲区，不等待Wi-Fi；0为配置有效，1为配置错误。
 * 三条边线数组需始终有效，每行一个8位横坐标。网络建立由poll分步推进。 */
uint8_t camera_debug_init(uint8_t *left, uint8_t *middle, uint8_t *right);
/* 每圈主循环调用一次，且放在摄像头/屏幕和舵机处理之后。
 * now_ms是允许回绕的毫秒计数；每轮最多一笔有界长度的网络SPI事务。 */
void camera_debug_poll(uint32_t now_ms);
typedef uint32_t (*camera_debug_clock_fn_t)(void);
typedef void (*camera_debug_control_fn_t)(uint32_t now_ms);
/* 主循环使用的有界连续发送入口：默认最多6笔、16ms预算。
 * 每块前服务舵机等控制任务；模块忙、握手等待、队列空或出错即返回。
 * 时钟需即时读取；控制回调不得阻塞或递归调用本模块。 */
void camera_debug_service(camera_debug_clock_fn_t clock_ms, camera_debug_control_fn_t service_controls);
/* 每个完成帧先调用本函数：始终显示原始灰度。
 * 图传队列空闲且连接就绪时才保存待序列化图像，网络拥塞不拖住本地显示。 */
void camera_debug_capture_frame(const uint8_t *gray_image);
/* 边线计算后调用，只把完整协议帧写入应用队列，不在这里传输SPI。
 * 二值模式仍为每像素一个0/255字节。队列内容在分块发送完成前不可覆盖。 */
void camera_debug_send_frame(const uint8_t *binary_image);

#endif
