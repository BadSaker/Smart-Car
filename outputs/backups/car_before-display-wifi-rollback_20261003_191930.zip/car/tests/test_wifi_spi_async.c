/* 真实状态机的主机回归：替换电气访问，捕获线上字节与每次轮询预算。 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "wifi_spi_async.h"
#include "platform.h"

/* 在主机直接报告失败并退出，避免触发Windows运行库断言窗口。 */
#undef assert
#define assert(condition) do { if (!(condition)) { \
    fprintf(stderr, "FAIL: line %d: %s\n", __LINE__, #condition); exit(1); \
} } while (0)

typedef struct
{
    uint8_t data[4100];
    uint32_t length;
} transaction_t;

static transaction_t transactions[256];
static uint32_t transaction_count, gpio_reads, spi_initializations, reset_lows, reset_highs;
static uint32_t transaction_offset, now;
static uint32_t transaction_elapsed_ms;
static int in_transaction, int_high = 1, control_guard_pending;
static uint8_t reply_command = 0x91;
static uint16_t reply_length;
static uint8_t payload[22936];

int gpio_get_level(int pin)
{
    assert(pin == 17);
    ++gpio_reads;
    return int_high;
}

void gpio_low(int pin)
{
    assert(pin == 13 && !in_transaction && transaction_count < 256);
    in_transaction = 1;
    control_guard_pending = wifi_spi_async_get_status()->state != WIFI_SPI_ASYNC_READY;
    transaction_offset = 0;
    transactions[transaction_count].length = 0;
}

void gpio_high(int pin)
{
    assert(pin == 13 && in_transaction);
    in_transaction = 0;
    ++transaction_count;
    /* 模拟SPI执行或中断抢占经过的时间，函数入参仍是开始前的旧tick。 */
    now += transaction_elapsed_ms;
}

void gpio_init(int pin, int direction, int level, int mode)
{
    (void)mode;
    assert((pin == 13 || pin == 16 || pin == 17));
    assert(pin == 17 ? (direction == 0 && level == 0) : (direction == 1 && level == 1));
}

void gpio_set_level(int pin, int level)
{
    assert(pin == 16);
    if (level) ++reset_highs;
    else ++reset_lows;
}

void spi_init(int bus, int mode, uint32 speed, int sck, int mosi, int miso, int cs)
{
    assert(bus == 1 && mode == 3 && speed == 50000000);
    assert(sck == 12 && mosi == 14 && miso == 15 && cs == 0);
    ++spi_initializations;
}

static void capture(const uint8_t *data, uint32_t length)
{
    transaction_t *transaction = &transactions[transaction_count];
    assert(in_transaction && data && transaction->length + length <= sizeof(transaction->data));
    memcpy(transaction->data + transaction->length, data, length);
    transaction->length += length;
    transaction_offset += length;
}

void spi_write_8bit_array(int bus, const uint8 *data, uint32 length)
{
    assert(bus == 1);
    capture(data, length);
}

void spi_transfer_8bit(int bus, const uint8 *out, uint8 *in, uint32 length)
{
    uint32_t offset = transaction_offset;
    assert(bus == 1 && in);
    capture(out, length);
    memset(in, 0, length);
    if (offset == 0)
    {
        assert(length == 4);
        in[0] = reply_command;
        in[2] = (uint8_t)reply_length;
        in[3] = (uint8_t)(reply_length >> 8);
    }
    else if (reply_command == 0xa0 && length >= 4)
    {
        memcpy(in, "V2.0", 4);
    }
}

static uint32_t poll_at(uint32_t tick, const uint8_t *data, uint32_t length)
{
    uint32_t old_transactions = transaction_count;
    uint32_t old_reads = gpio_reads;
    uint32_t sent;
    now = tick;
    sent = wifi_spi_async_poll(tick, data, length);
    assert(transaction_count - old_transactions <= 1);
    assert(gpio_reads - old_reads <= 1);
    assert(!in_transaction && sent <= 4088 && sent <= length);
    return sent;
}

/* 控制事务保留两个tick；数据事务按模块就绪信号立即推进。 */
static uint32_t poll_after_guard(const uint8_t *data, uint32_t length)
{
    uint32_t tick = now;
    uint32_t count = transaction_count;
    if (!control_guard_pending) return poll_at(tick, data, length);
    control_guard_pending = 0;
    assert(poll_at(tick, data, length) == 0 && transaction_count == count);
    assert(poll_at(tick + 1, data, length) == 0 && transaction_count == count);
    return poll_at(tick + 2, data, length);
}

static void initialize(const char *password)
{
    uint32_t i;
    assert(wifi_spi_async_init("track", password, "192.168.137.1", "8080", "0") == 0);
    for (i = 0; i < sizeof(payload); ++i) payload[i] = (uint8_t)(i % 251);
}

static void wait_for_transaction(uint32_t expected)
{
    uint32_t i;
    for (i = 0; i < 130 && transaction_count < expected; ++i)
        assert(poll_at(now + 1, NULL, 0) == 0);
    assert(transaction_count == expected);
}

static void expect_bytes(uint32_t index, const uint8_t *bytes, uint32_t length)
{
    assert(index < transaction_count);
    assert(transactions[index].length == length);
    assert(memcmp(transactions[index].data, bytes, length) == 0);
}

static void handshake_until(uint32_t target)
{
    static const uint8_t wifi[] = {0x10, 0, 15, 0, 't','r','a','c','k',13,10,'s','e','c','r','e','t',13,10};
    static const uint8_t socket[] = "\x11\0\x1d\0TCP\r\n192.168.137.1\r\n8080\r\n0\r\n";
    static const uint8_t ack[] = {2, 0, 0, 0};
    uint8_t version_request[32] = {0x20};
    wait_for_transaction(1);
    expect_bytes(0, version_request, 32);
    assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_INITIALIZING);
    if (target == 1) return;
    reply_command = 0xa0; reply_length = 4;
    assert(poll_at(now, NULL, 0) == 0 && transaction_count == 1);
    wait_for_transaction(2);
    assert(transactions[1].length == 36 && transactions[1].data[0] == 2);
    assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_JOINING);
    if (target == 2) return;
    wait_for_transaction(3);
    expect_bytes(2, wifi, sizeof(wifi));
    if (target == 3) return;
    reply_command = 0x80; reply_length = 0;
    wait_for_transaction(4);
    expect_bytes(3, ack, 4);
    assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_CONNECTING);
    if (target == 4) return;
    wait_for_transaction(5);
    expect_bytes(4, socket, sizeof(socket) - 1);
    if (target == 5) return;
    wait_for_transaction(6);
    expect_bytes(5, ack, 4);
    assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_READY);
    reply_command = 0x91;
}

static void assert_fault(wifi_spi_async_error_phase_t phase)
{
    const wifi_spi_async_status_t *status = wifi_spi_async_get_status();
    assert(status->state == WIFI_SPI_ASYNC_BACKOFF);
    assert(status->last_error_phase == phase && status->error_count == 1);
}

static void test_configuration(void)
{
    char long_ssid[34], long_password[61];
    memset(long_ssid, 's', 33); long_ssid[33] = 0;
    memset(long_password, 'p', 60); long_password[60] = 0;
#define INVALID_CONFIG(s,p,i,r,l) do { \
    assert(wifi_spi_async_init(s,p,i,r,l) == 1); \
    assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_CONFIG_ERROR); \
    assert(wifi_spi_async_get_status()->last_error_phase == WIFI_SPI_ASYNC_ERROR_CONFIG); \
    assert(poll_at(now + 1, payload, 2) == 0); \
    assert(transaction_count == 0 && spi_initializations == 0 && gpio_reads == 0); \
} while (0)
    INVALID_CONFIG(NULL, "", "1.2.3.4", "1", "0");
    INVALID_CONFIG("", "", "1.2.3.4", "1", "0");
    INVALID_CONFIG(long_ssid, "", "1.2.3.4", "1", "0");
    INVALID_CONFIG("a", long_password, "1.2.3.4", "1", "0");
    INVALID_CONFIG("a\r\nb", "", "1.2.3.4", "1", "0");
    INVALID_CONFIG("a", "b\nc", "1.2.3.4", "1", "0");
    INVALID_CONFIG("a", "", "256.2.3.4", "1", "0");
    INVALID_CONFIG("a", "", "1.2.3", "1", "0");
    INVALID_CONFIG("a", "", "1.2.3.4.5", "1", "0");
    INVALID_CONFIG("a", "", "1.2.3.4", "65536", "0");
    INVALID_CONFIG("a", "", "1.2.3.4", "0", "0");
    INVALID_CONFIG("a", "", "1.2.3.4", "80x", "0");
    INVALID_CONFIG("a", "", "1.2.3.4", "80", "2047");
    assert(wifi_spi_async_init("a", NULL, "1.2.3.4", "65535", "2048") == 0);
}

int main(int argc, char **argv)
{
    uint32_t i, baseline, tick, sent;
    const char *scenario;
    assert(argc == 2);
    scenario = argv[1];
    assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_DISABLED);
    assert(poll_at(0, NULL, 0) == 0 && transaction_count == 0);
    if (!strcmp(scenario, "configuration"))
    {
        test_configuration();
        goto passed;
    }
    if (!strcmp(scenario, "copied-configuration"))
    {
        char ssid[] = "track", password[] = "secret", ip[] = "192.168.137.1";
        char port[] = "8080", local[] = "0";
        assert(wifi_spi_async_init(ssid, password, ip, port, local) == 0);
        memset(ssid, 'x', sizeof(ssid)); memset(password, 'x', sizeof(password));
        memset(ip, 'x', sizeof(ip)); memset(port, 'x', sizeof(port)); memset(local, 'x', sizeof(local));
        handshake_until(6);
        goto passed;
    }
    initialize(!strcmp(scenario, "open-network") ? "" : "secret");
    if (!strcmp(scenario, "guard-cross-tick") || !strcmp(scenario, "guard-long-isr") ||
        !strcmp(scenario, "guard-wrap"))
    {
        if (!strcmp(scenario, "guard-wrap"))
        {
            now = UINT32_MAX - 114;
            transaction_elapsed_ms = 2;
        }
        else
            transaction_elapsed_ms = !strcmp(scenario, "guard-long-isr") ? 120000U : 1U;
        handshake_until(1);
        transaction_elapsed_ms = 0;
        tick = now;
        if (!strcmp(scenario, "guard-wrap")) assert(tick == UINT32_MAX);
        reply_command = 0xa0; reply_length = 4;
        baseline = gpio_reads;
        assert(poll_at(tick, NULL, 0) == 0 && transaction_count == 1);
        for (i = 0; i < 10; ++i)
            assert(poll_at(tick, NULL, 0) == 0 && transaction_count == 1);
        assert(poll_at(tick + 1, NULL, 0) == 0 && transaction_count == 1);
        assert(gpio_reads == baseline);
        assert(poll_at(tick + 2, NULL, 0) == 0 && transaction_count == 2);
        assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_JOINING);
    }
    else if (!strcmp(scenario, "guard-timeout-stability"))
    {
        handshake_until(1);
        int_high = 0;
        tick = now;
        for (i = 0; i < 1000; ++i)
        {
            poll_at(tick + i, NULL, 0);
            assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_INITIALIZING);
        }
        poll_at(tick + 1000, NULL, 0);
        assert_fault(WIFI_SPI_ASYNC_ERROR_VERSION);
        assert(transaction_count == 1);
    }
    else if (!strcmp(scenario, "registration"))
    {
        assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_INITIALIZING);
        assert(transaction_count == 0 && gpio_reads == 0 && spi_initializations == 0);
        assert(reset_lows == 0 && reset_highs == 0);
    }
    else if (!strcmp(scenario, "reset-wrap"))
    {
        poll_at(UINT32_MAX - 4, NULL, 0);
        assert(reset_lows == 1 && reset_highs == 0);
        poll_at(4, NULL, 0);
        assert(reset_highs == 0);
        poll_at(5, NULL, 0);
        assert(reset_highs == 1 && transaction_count == 0);
        poll_at(104, NULL, 0);
        assert(transaction_count == 0);
        poll_at(105, NULL, 0);
        poll_at(106, NULL, 0);
        assert(transaction_count == 1);
    }
    else if (!strcmp(scenario, "open-network"))
    {
        static const uint8_t open_wifi[] = {0x10,0,7,0,'t','r','a','c','k',13,10};
        handshake_until(2);
        wait_for_transaction(3);
        expect_bytes(2, open_wifi, sizeof(open_wifi));
    }
    else if (!strcmp(scenario, "version-timeout"))
    {
        int_high = 0;
        for (i = 0; i <= 2000; ++i) poll_at(i, NULL, 0);
        assert_fault(WIFI_SPI_ASYNC_ERROR_VERSION);
        assert(transaction_count == 0);
    }
    else if (!strcmp(scenario, "version-ack-timeout"))
    {
        handshake_until(1);
        tick = now;
        int_high = 0;
        poll_at(tick, NULL, 0);
        poll_at(tick + 999, NULL, 0);
        assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_INITIALIZING);
        poll_at(tick + 1000, NULL, 0);
        assert_fault(WIFI_SPI_ASYNC_ERROR_VERSION);
        assert(transaction_count == 1);
    }
    else if (!strcmp(scenario, "version-error") || !strcmp(scenario, "version-length"))
    {
        handshake_until(1);
        reply_command = !strcmp(scenario, "version-error") ? 0x80 : 0xa0;
        reply_length = 33;
        wait_for_transaction(2);
        assert_fault(WIFI_SPI_ASYNC_ERROR_VERSION);
    }
    else if (!strcmp(scenario, "no-frame-reconnect"))
    {
        int_high = 0;
        for (i = 0; i < 18000; ++i) poll_at(i, NULL, 0);
        assert(transaction_count == 0);
        assert(wifi_spi_async_get_status()->error_count == 3);
        assert(wifi_spi_async_get_status()->reconnect_count == 2);
        assert(reset_lows == 3);
    }
    else if (!strcmp(scenario, "join-timeout") || !strcmp(scenario, "socket-timeout"))
    {
        int socket_case = !strcmp(scenario, "socket-timeout");
        handshake_until(socket_case ? 5 : 3);
        tick = now;
        int_high = 0;
        poll_at(tick, NULL, 0);
        poll_at(tick + (socket_case ? 49999 : 9999), NULL, 0);
        assert(wifi_spi_async_get_status()->state != WIFI_SPI_ASYNC_BACKOFF);
        poll_at(tick + (socket_case ? 50000 : 10000), NULL, 0);
        assert_fault(socket_case ? WIFI_SPI_ASYNC_ERROR_SOCKET : WIFI_SPI_ASYNC_ERROR_WIFI);
    }
    else if (!strcmp(scenario, "ack-error") || !strcmp(scenario, "socket-ack-error"))
    {
        int socket_case = !strcmp(scenario, "socket-ack-error");
        handshake_until(socket_case ? 5 : 3);
        reply_command = 0x81; reply_length = 0;
        wait_for_transaction(socket_case ? 6 : 4);
        assert_fault(socket_case ? WIFI_SPI_ASYNC_ERROR_SOCKET : WIFI_SPI_ASYNC_ERROR_WIFI);
    }
    else
    {
        handshake_until(6);
        baseline = transaction_count;
        if (!strcmp(scenario, "handshake"))
        {
            assert(poll_at(now, payload, 3) == 0 && transaction_count == baseline);
            assert(poll_after_guard(payload, 3) == 3);
        }
        else if (!strcmp(scenario, "send-timeout") || !strcmp(scenario, "reconnect"))
        {
            poll_after_guard(NULL, 0);
            int_high = 0;
            tick = UINT32_MAX - 500;
            for (i = 0; i < 1000; ++i)
            {
                assert(poll_at(tick + i, payload, 512) == 0);
                assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_READY);
            }
            assert(poll_at(tick + 1000, payload, 512) == 0);
            assert_fault(WIFI_SPI_ASYNC_ERROR_SEND);
            assert(transaction_count == baseline);
            tick = now;
            poll_at(tick + 4999, NULL, 0);
            assert(reset_lows == 1 && wifi_spi_async_get_status()->reconnect_count == 0);
            poll_at(tick + 5000, NULL, 0);
            assert(reset_lows == 2 && wifi_spi_async_get_status()->reconnect_count == 1);
            assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_INITIALIZING);
            if (!strcmp(scenario, "reconnect"))
            {
                transaction_count = 0;
                int_high = 1;
                handshake_until(6);
                assert(wifi_spi_async_get_status()->error_count == 1);
                assert(wifi_spi_async_get_status()->last_error_phase == WIFI_SPI_ASYNC_ERROR_SEND);
                assert(poll_after_guard(payload, 7) == 7);
            }
        }
        else if (!strcmp(scenario, "chunks"))
        {
            assert(poll_after_guard(payload, 5000) == 4088);
            assert(transactions[6].length == 4092);
            assert(transactions[6].data[0] == 2 && transactions[6].data[2] == 0xf8 && transactions[6].data[3] == 0x0f);
            assert(memcmp(transactions[6].data + 4, payload, 4088) == 0);
            assert(poll_after_guard(payload + 4088, 512) == 512);
            assert(transactions[7].length == 516);
            assert(memcmp(transactions[7].data + 4, payload + 4088, 512) == 0);
        }
        else if (!strcmp(scenario, "continuous-data"))
        {
            assert(poll_after_guard(payload, 512) == 512);
            tick = now;
            for (i = 1; i < 5; ++i)
            {
                assert(poll_at(tick, payload + i * 512, 512) == 512);
                assert(transactions[6 + i].length == 516);
                assert(memcmp(transactions[6 + i].data + 4, payload + i * 512, 512) == 0);
            }
            /* 只有ready引脚决定能否继续，不凭空加入数据阶段的毫秒等待。 */
            int_high = 0; baseline = transaction_count;
            assert(poll_at(tick, payload, 512) == 0 && transaction_count == baseline);
            int_high = 1;
            assert(poll_at(tick, payload, 512) == 512);
        }
        else if (!strcmp(scenario, "whole-frame-six-chunks"))
        {
            uint32_t offset = poll_after_guard(payload, sizeof(payload));
            assert(offset == 4088);
            tick = now;
            while (offset < sizeof(payload)) offset += poll_at(tick, payload + offset, (uint32_t)sizeof(payload) - offset);
            assert(offset == sizeof(payload) && transaction_count == 12);
            for (i = 0; i < 6; ++i)
            {
                uint32_t size = i < 5 ? 4088U : 2496U;
                assert(transactions[6 + i].length == size + 4U);
                assert(memcmp(transactions[6 + i].data + 4, payload + i * 4088U, size) == 0);
            }
        }
        else if (!strcmp(scenario, "short-padding"))
        {
            assert(poll_after_guard(payload, 3) == 3);
            assert(transactions[baseline].length == 36 && transactions[baseline].data[2] == 3);
            assert(memcmp(transactions[baseline].data + 4, payload, 3) == 0);
            for (i = 7; i < 36; ++i) assert(transactions[baseline].data[i] == 0);
        }
        else if (!strcmp(scenario, "rx-budget"))
        {
            reply_command = 0x90; reply_length = 32;
            assert(poll_after_guard(payload, 512) == 512);
            for (i = 0; i < 20; ++i)
            {
                assert(poll_after_guard(payload + 512, 100) == 0);
                assert(transactions[baseline + 1 + i].length == 36);
                assert(transactions[baseline + 1 + i].data[2] == 0);
            }
            reply_command = 0x91; reply_length = 4;
            assert(poll_after_guard(NULL, 0) == 0);
            assert(poll_after_guard(payload + 512, 100) == 100);
        }
        else if (!strcmp(scenario, "rx-invalid"))
        {
            reply_command = 0x90; reply_length = 33;
            sent = poll_after_guard(payload, 512);
            assert(sent == 512);
            assert_fault(WIFI_SPI_ASYNC_ERROR_RECEIVE);
            assert(poll_at(now + 1, payload, 512) == 0 && transaction_count == baseline + 1);
        }
        else if (!strcmp(scenario, "idle-reply"))
        {
            static const uint8_t commands[] = {0, 0xff, 0x80, 0x33};
            for (i = 0; i < sizeof(commands); ++i)
            {
                reply_command = commands[i]; reply_length = 65535;
                assert(poll_after_guard(payload, 512) == 512);
                assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_READY);
                assert(wifi_spi_async_get_status()->error_count == 0);
            }
        }
        else if (!strcmp(scenario, "rx-timeout"))
        {
            reply_command = 0x90; reply_length = 32;
            assert(poll_after_guard(payload, 20) == 20);
            int_high = 0;
            poll_after_guard(NULL, 0);
            tick = now;
            poll_at(tick + 999, NULL, 0);
            assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_READY);
            poll_at(tick + 1000, NULL, 0);
            assert_fault(WIFI_SPI_ASYNC_ERROR_RECEIVE);
            assert(transaction_count == baseline + 1);
        }
        else if (!strcmp(scenario, "send-error"))
        {
            reply_command = 0x81; reply_length = 0;
            assert(poll_after_guard(payload, 512) == 512);
            assert_fault(WIFI_SPI_ASYNC_ERROR_SEND);
        }
        else if (!strcmp(scenario, "null-data"))
        {
            assert(poll_after_guard(NULL, 512) == 0);
            assert(transaction_count == baseline);
            assert_fault(WIFI_SPI_ASYNC_ERROR_SEND);
        }
        else if (!strcmp(scenario, "empty-no-timeout"))
        {
            int_high = 0;
            tick = now + 1;
            for (i = 0; i < 2000; ++i) poll_at(tick + i, NULL, 0);
            assert(wifi_spi_async_get_status()->state == WIFI_SPI_ASYNC_READY);
            assert(wifi_spi_async_get_status()->error_count == 0);
            assert(transaction_count == baseline);
        }
        else assert(0);
    }
passed:
    printf("PASS: %s\n", scenario);
    return 0;
}
