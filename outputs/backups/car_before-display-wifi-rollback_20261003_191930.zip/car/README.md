# Autocar RT1064 工程

打开 [autocar.uvprojx](autocar.uvprojx)，目标 `autocar`。

本工程用于C车模、逐飞MIMXRT1064DVL6B与RT1064 V3.0主板。当前MT9V034图像同时显示到普通IPS200 SPI屏，并通过Wi-Fi SPI传输到逐飞助手1.2.7；电机输出关闭；舵机默认无PWM，由主板S2启动小幅测试、S3撤销信号。

网络参数位于 [camera_debug_config.h](config/camera_debug_config.h)，已经配置本机2.4GHz热点及电脑目标192.168.137.1:8080。该文件含本机热点密码，不要贴入日志或公开报告。心跳诊断/DAP图传模式已删除；DAP用于SWD下载。电源对照确认仅电池带全部外设时各灯正常，当前按此方式运行。

在工作区根目录执行：

```powershell
.\car\scripts\build.ps1
.\car\scripts\test.ps1
```

- [构建与调试说明](../docs/environment-and-build.md)
- [硬件与引脚](../docs/hardware-and-pins.md)
- [逐飞助手图传使用说明](../docs/seekfree-assistant-debugging.md)
- [已知问题与验证边界](../docs/known-issues.md)
- [全部例程的使用说明](../docs/examples/README.md)
- [最终固件](../outputs/firmware/)

`src/` 为应用实现，`include/` 为接口，`config/` 为硬件配置，`library/` 为保留来源和许可的SDK与逐飞驱动。图像/PID来源于本地摄像头组参考工程并作了回归修复；中断框架和底层库来源于V3.11.2。尚未实现完整赛道元素处理和自动停车。

最新供电对照：用户确认仅电池供电、摄像头/屏幕/Wi-Fi全部接回后仍全亮。烧录后彻底断电并移除DAP排线，再以电池运行；详细依据见硬件文档。

本地屏幕优先，Wi-Fi初始化/重连/模块忙均按主循环短步骤推进，不等待网络。S-U400测试详情见 [舵机指南](../docs/servo-debugging.md)：6.0V、P16/C30、1520±40µs参考窗口，低/高脉宽的实际左右方向需观察。S3停止新信号不保证S-U400卸力。

吞吐版本参考14:32:41交付代码：连接后屏幕仍显示，Wi-Fi按4088字节块在6笔/16ms预算内连续发送，块间服务舵机；未连接时屏幕继续实时预览并后台建链。软件回归不等于已实测30FPS，烧录后请核对助手帧率。
