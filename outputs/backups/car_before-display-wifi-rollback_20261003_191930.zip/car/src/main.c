#include "main.h"

/* 图像预览与舵机按键测试在主循环优先执行。
 * Wi-Fi建链/重连按短步骤推进；数据就绪时有界连续发送，块间处理舵机按键。
 * 舵机1由servo_control独占；本测试不运行图像循迹打角，电机输出默认关闭。 */
uint8_t image[MT9V03X_H][MT9V03X_W];
short hist_gram[256];
uint8_t left_line[MT9V03X_H];
uint8_t mid_line[MT9V03X_H];
uint8_t right_line[MT9V03X_H];

static void app_init(void)
{
    camera_display_init();
    /* 上电只把舵机信号置低；S2启动小幅测试，S3停止新PWM指令。 */
    servo_control_init(app_uptime_ms);
    encoder_quad_init(ENCODER_1, ENCODER_1_A, ENCODER_1_B);
    encoder_quad_init(ENCODER_2, ENCODER_2_A, ENCODER_2_B);
    pwm_init(MOTOR1_PWM, 17000, 0);
    gpio_init(MOTOR1_DIR, GPO, GPIO_HIGH, GPO_PUSH_PULL);
    pwm_init(MOTOR2_PWM, 17000, 0);
    gpio_init(MOTOR2_DIR, GPO, GPIO_HIGH, GPO_PUSH_PULL);
    My_Pid_Init();
    /* 编码器控制仍为10ms；网络与舵机状态机使用独立1ms时钟。 */
    pit_ms_init(PIT_CH0, APP_CONTROL_PERIOD_MS);
    pit_ms_init(PIT_CH1, APP_SYSTEM_TICK_MS);
    interrupt_global_enable(0);

    while (mt9v03x_init())
    {
        camera_display_message("Camera init failed; check CSI/power");
        system_delay_ms(1000);
    }
    /* 只登记协议和网络参数，真正联网由后续poll完成。 */
    (void)camera_debug_init(left_line, mid_line, right_line);
}

static uint32_t app_clock_ms(void)
{
    return app_uptime_ms;
}

int main(void)
{
    clock_init(SYSTEM_CLOCK_600M);
    debug_init();
    system_delay_ms(300); // 启动时等待板上外设供电稳定，不用于运行期Wi-Fi等待。
    app_init();

    while (1)
    {
        servo_control_poll(app_uptime_ms);
        if (mt9v03x_finish_flag)
        {
            /* 先确认完成标志，再短时间复制供应商完成缓冲；后续模块只读应用副本。 */
            mt9v03x_finish_flag = 0;
            memcpy(image[0], mt9v03x_image[0], sizeof(image));
            camera_debug_capture_frame(image[0]); // 无论Wi-Fi状态如何，先显示当前灰度。
            servo_control_poll(app_uptime_ms);  // 完成一次刷屏后及时处理停止键。

            get_hist_gram(image[0], MT9V03X_H, MT9V03X_W, hist_gram);
            unsigned char threshold = get_threshold_otsu(hist_gram);
            binaryzation_process(image[0], MT9V03X_H, MT9V03X_W, threshold);
            auxiliary_process(image[0], MT9V03X_H, MT9V03X_W, 127, left_line, mid_line, right_line);
            camera_debug_send_frame(image[0]); // 仅序列化整帧，队列忙时跳过，不在此处发送。
        }
        /* 即使没有新图像，也持续处理按键、网络超时和重新连接。 */
        servo_control_poll(app_uptime_ms);
        camera_debug_service(app_clock_ms, servo_control_poll);
    }
}
