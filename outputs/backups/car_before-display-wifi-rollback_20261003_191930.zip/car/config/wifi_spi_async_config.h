#ifndef AUTOCAR_WIFI_SPI_ASYNC_CONFIG_H
#define AUTOCAR_WIFI_SPI_ASYNC_CONFIG_H

/* 每次底层poll至多一笔事务，采用供应商协议允许的4088字节分块。
 * 时钟与引脚直接沿用zf_device_wifi_spi.h的50MHz和P7定义，不在此重定义。 */
#ifndef WIFI_SPI_ASYNC_CHUNK_SIZE
#define WIFI_SPI_ASYNC_CHUNK_SIZE            (4088U)
#endif
#define WIFI_SPI_ASYNC_RESET_LOW_MS          (10U)
#define WIFI_SPI_ASYNC_BOOT_WAIT_MS          (100U)

/* 仅用于建链控制事务：CS结束后，下一poll先锚定最新tick，再跨两个tick。
 * 即使锚定紧邻tick边界，也至少等待一个完整毫秒，覆盖ACK后的20us。
 * 不得改为1；SPI耗时及ISR抢占不能抵扣这段保护时间。
 * 已连接的数据事务沿用14:32版本的INT就绪握手，不逐块等待毫秒tick。 */
#ifndef WIFI_SPI_ASYNC_TRANSACTION_GUARD_MS
#define WIFI_SPI_ASYNC_TRANSACTION_GUARD_MS  (2U)
#endif
#define WIFI_SPI_ASYNC_VERSION_TIMEOUT_MS   (1000U)
#define WIFI_SPI_ASYNC_JOIN_TIMEOUT_MS      (10000U)
#define WIFI_SPI_ASYNC_SOCKET_TIMEOUT_MS    (50000U)
#define WIFI_SPI_ASYNC_DATA_TIMEOUT_MS      (1000U)
#define WIFI_SPI_ASYNC_BACKOFF_MS           (5000U)

#endif
