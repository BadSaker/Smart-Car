#ifndef AUTOCAR_CAMERA_DEBUG_CONFIG_H
#define AUTOCAR_CAMERA_DEBUG_CONFIG_H

/* SeekFree Assistant 1.2.7. Default: official dual-mode DAP, PC COM7.
 * Port number is selected on the PC, not programmed into the MCU. */
#define CAMERA_DEBUG_DAP_UART        0
#define CAMERA_DEBUG_WIFI_UART       1
#define CAMERA_DEBUG_GRAY            0
#define CAMERA_DEBUG_BINARY          1
#define CAMERA_DEBUG_BOUNDARIES_ONLY 2

#ifndef CAMERA_DEBUG_ENABLED
#define CAMERA_DEBUG_ENABLED         1
#endif
#ifndef CAMERA_DEBUG_TRANSPORT
#define CAMERA_DEBUG_TRANSPORT       CAMERA_DEBUG_DAP_UART
#endif
#ifndef CAMERA_DEBUG_IMAGE_MODE
#define CAMERA_DEBUG_IMAGE_MODE      CAMERA_DEBUG_GRAY
#endif
#ifndef CAMERA_DEBUG_UART_BAUDRATE
#define CAMERA_DEBUG_UART_BAUDRATE   115200U
#endif
/* Send the first prepared frame, then one per N processed frames. Blocking TX
 * still takes about 2 s for a full gray frame at 115200. This is a debug mode. */
#ifndef CAMERA_DEBUG_FRAME_DIVIDER
#define CAMERA_DEBUG_FRAME_DIVIDER   1U
#endif

/* Used only with CAMERA_DEBUG_WIFI_UART: matching SeekFree Wi-Fi UART module,
 * station + TCP client; Assistant on the PC is TCP Server on the same port.
 * Fill in your network and PC LAN IPv4 before selecting this transport. */
#ifndef CAMERA_DEBUG_WIFI_SSID
#define CAMERA_DEBUG_WIFI_SSID       ""
#endif
#ifndef CAMERA_DEBUG_WIFI_PASSWORD
#define CAMERA_DEBUG_WIFI_PASSWORD   ""
#endif
#ifndef CAMERA_DEBUG_WIFI_SERVER_IP
#define CAMERA_DEBUG_WIFI_SERVER_IP  ""
#endif
#ifndef CAMERA_DEBUG_WIFI_SERVER_PORT
#define CAMERA_DEBUG_WIFI_SERVER_PORT "8080"
#endif

#if CAMERA_DEBUG_TRANSPORT != CAMERA_DEBUG_DAP_UART && CAMERA_DEBUG_TRANSPORT != CAMERA_DEBUG_WIFI_UART
#error "Unsupported camera debug transport"
#endif
#if CAMERA_DEBUG_IMAGE_MODE < CAMERA_DEBUG_GRAY || CAMERA_DEBUG_IMAGE_MODE > CAMERA_DEBUG_BOUNDARIES_ONLY
#error "Unsupported camera debug image mode"
#endif
#if CAMERA_DEBUG_FRAME_DIVIDER < 1
#error "CAMERA_DEBUG_FRAME_DIVIDER must be at least 1"
#endif

#endif
