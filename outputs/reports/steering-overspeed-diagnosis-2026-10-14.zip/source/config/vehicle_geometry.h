#ifndef AUTOCAR_VEHICLE_GEOMETRY_H
#define AUTOCAR_VEHICLE_GEOMETRY_H

/* 当前车模参数；190mm轴距沿用工程记录，180mm轮胎外宽沿用C1模型。
 * 满幅28度仍为未实测的机械映射假设，不能将仿真通过当成该角度已标定。 */
#define VEHICLE_WHEELBASE_MM          190.0f
#define VEHICLE_REAR_TRACK_MM        153.0f
#define VEHICLE_HALF_TIRE_OUTER_MM    90.0f
#define VEHICLE_MAX_STEER_RAD         (28.0f * 0.017453292519943295f)

#endif
