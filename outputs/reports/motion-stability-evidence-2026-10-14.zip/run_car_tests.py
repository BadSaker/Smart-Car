from pathlib import Path
import os,sys,unittest
r=Path.cwd();scratch=r/'tmp/motion-stability-20261014/car-tests'
os.environ['AUTOCAR_TEST_ROOT']=str(scratch)
os.environ['AUTOCAR_HOST_CC']=str(r/'simulation/toolchain/mingw64/bin/gcc.exe')
suite=unittest.defaultTestLoader.discover(str(r/'car/tests'))
for name,m in list(sys.modules.items()):
 if name.startswith('test_') and hasattr(m,'SCRATCH'):m.SCRATCH=scratch/name
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
