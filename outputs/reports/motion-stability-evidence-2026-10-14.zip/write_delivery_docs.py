from pathlib import Path
import json,csv,datetime
r=Path.cwd();t=r/'tmp/motion-stability-20261014'
report_name='motion-stability-2026-10-14.md'
summary='2026-10-14已修复转向模式跳变、差速绕过单轮加速度限制、PWM积分跟踪与仿真轮速耦合问题。主工程及仿真默认采用300/250/220/220mm/s、PWM400‰；自动舵机1330–1630µs，中位1480µs，实测前轮端点±34.74318°。新独立轮速模型下，中低速及800、分路段1000/1200档均双向通过；高档不是四档全相同。软件结果不代表实车已验证。'
def replace(path,old,new):
 p=r/path;s=p.read_text(encoding='utf-8');assert old in s,(path,old[:50]);p.write_text(s.replace(old,new),encoding='utf-8')
def insert_after_title(path,content):
 p=r/path;s=p.read_text(encoding='utf-8');i=s.index('\n');p.write_text(s[:i+1]+'\n'+content+'\n'+s[i+1:],encoding='utf-8')
# Replace only current-state introductions; keep explicitly labelled historical records.
p=r/'docs/project-overview.md';s=p.read_text(encoding='utf-8');a=s.index('2026-10-13现场优化');b=s.index('\n\n',a);s=s[:a]+summary+f'详见[本轮交付](../outputs/reports/{report_name})。'+s[b:];s=s.replace('中值1480µs；自动1350–1610µs、遥控1420–1540µs，机械余量待验','中位1480µs；自动1330–1630µs、端点±34.74318°已测；遥控1420–1540µs，中间段关系待标定');p.write_text(s,encoding='utf-8')
replace('docs/autonomous-driving.md','## 当前：800–1200mm/s模型条件软件验收','## 历史：2026-10-13旧动力模型软件验收')
insert_after_title('docs/autonomous-driving.md','## 当前：运动连续性修复与分路段提速（2026-10-14）\n\n'+summary+f' 参数、实测待办和复现见[交付报告](../outputs/reports/{report_name})。\n\n转向请求先经统一速度/加速度轨迹；每个轮速目标每10ms最多上升2、下降8mm/s，每个PWM每10ms最多上升3、下降12‰。保护停车仍立即撤输出。首个短时坏帧撤动力但保持已执行方向；连续坏帧仍停车。PWM最终限幅反馈到PID积分，trace增加原始计数、两轮速度、舵机服务时刻和故障前控制状态。')
p=r/'docs/known-issues.md';s=p.read_text(encoding='utf-8');a=s.index('用户反馈弯道');b=s.index('\n\n## 当前边界',a);s=s[:a]+summary+f' 详见[修复与验收](../outputs/reports/{report_name})。OVERSPEED实车触发时没有轮速记录，因此不能确认是车轮空转还是真实计数毛刺；保护阈值2500mm/s保留。四档全1000在一方向环岛出口仍短时失路，明确不采用；高档改为直道1000/1200、弯900、外侧/元素800。'+s[b:];s=s.replace('## 当前边界（2026-10-13）','## 历史边界（2026-10-13，旧模型）');p.write_text(s,encoding='utf-8')
replace('docs/hardware-and-pins.md','更新：2026-10-07。','更新：2026-10-14（舵机标定补充；其他项目保留原核实状态）。')
replace('docs/hardware-and-pins.md','2026-10-03用户确认中值1480µs；已按授权增至±60µs，实际扩大端点/限位待观察','中位1480µs、自动端点1330/1630µs已确认；左右前轮端点atan(21.5/31)=34.74318°基本相同；中间段脉宽—角度关系未测')
replace('docs/hardware-and-pins.md','50Hz，用户确认1480±60µs；由servo_control独占','50Hz，自动1480±150µs、遥控/独立测试±60µs；由servo_control独占')
insert_after_title('docs/servo-debugging.md','## 2026-10-14实测补充\n\n用户确认自动驾驶可用范围1330–1630µs、中位1480µs；前轮相对直行方向tanθ=21.5/31，左右基本相同，端点为±34.7431801583°。已同步servo_config.h、vehicle_geometry.h及当前仿真预设。自动控制20µs/20ms为软件脉宽步进上限，之前另有共同转向速度/加速度约束；端点内线性映射和80ms机械响应仍为模型假设。遥控与独立摆动测试保持±60µs。以下早期测试记录不代表当前自动行程。')
p=r/'simulation/README.md';s=p.read_text(encoding='utf-8');a=s.index('当前仿真默认与主工程');b=s.index('\n\n',a);s=s[:a]+summary+f'详见[本轮报告](../outputs/reports/{report_name})。选择参数后应用并重置，再启动。'+s[b:];s=s.replace('物理相机、PWM—速度、舵角和轮胎动力学尚未完成实测标定。','前轮端点已实测；物理相机、PWM—速度、舵机中间段及轮胎动力学尚未完成实测标定。');s=s.replace('四个配置头（含encoder_config.h和vehicle_geometry.h）','五个配置头（含encoder_config.h、vehicle_geometry.h和servo_config.h），共11份共享文件');s=s.replace('默认已同步800，模型条件下800–1200软件验收完成，实车尚待确认，见','当时默认800的旧模型结果仅作历史记录，当前版本以2026-10-14运动修复报告为准；历史实施记录见');p.write_text(s,encoding='utf-8')
p=r/'simulation/docs/control-tuning.md';s=p.read_text(encoding='utf-8');a=s.index('当前默认');b=s.index('\n\n',a);s=s[:a]+summary+f' [详细结果与复现](../../outputs/reports/{report_name})。\n\n当前完整验证_800为800/800/800/800；完整验证_1000为1000/900/800/800；完整验证_1200为1200/900/800/800。高档PWM1000‰、横向加速度限2400mm/s²；默认低档分别400‰、2000mm/s²。仿真选择不会回写固件参数。\n\n验收同时要求完整指定路线、实际里程0.8–1.1圈、全RUNNING阶段零撤PWM、无故障、四轮角点余量非负、路径Q裕量至少10。起步只豁免最低速度要求；正常最低速度采用min(800,四档最小值)的98%。另检查共同转向及单轮目标/PWM斜率。旧理想模型仅作对照，不能满足本轮独立轮速验收。'+s[b:];p.write_text(s,encoding='utf-8')
replace('simulation/docs/parameters-and-ui.md','当前模型条件验证，四档目标统一；未实车标定','新独立轮速模型条件验证：800四档相同；1000/1200仅提升直道，弯道900、外侧/元素800；未实车标定')
replace('simulation/docs/parameters-and-ui.md','当前800/800/800/800默认完整赛道基线','当前300/250/220/220、PWM400的默认完整赛道基线')
replace('simulation/docs/parameters-and-ui.md','用户编辑入口；目前与中速配置内容相同，可独立修改','用户编辑入口；保留原速度与相机数据，同步已确认舵机端点和新运动控制，可独立修改')
p=r/'simulation/docs/parameters-and-ui.md';s=p.read_text(encoding='utf-8');a=s.index('当前版本默认800');s=s[:a]+f'2026-10-14同步10份非历史活动预设的1330–1630µs、±34.74318°、20µs步进、共同运动约束及独立轮速模型；“实测基线_350_350_350_250”和archive内JSON原字节保持，历史预设不代表当前固件。新增“运动”“动力”页可调轨迹、单轮目标斜率、PID跟踪及未标定的动力参数。速度无500上限，仍拒绝非法或超出C float范围输入。图像延迟0–500ms、模糊0–3px保持。当前结果见[报告](../../outputs/reports/{report_name})。\n';p.write_text(s,encoding='utf-8')
p=r/'simulation/docs/architecture.md';s=p.read_text(encoding='utf-8');a=s.index('当前servo中心');b=s.index('\n\n',a);s=s[:a]+'当前舵机中位1480µs、自动摆幅150µs，前轮端点±34.74318°来自用户实测；中间段线性映射及80ms响应为模型假设。软件步进20µs/20ms，共同转向轨迹5000‰/s、50000‰/s²。编码器使用同一encoder_config.h：1024×68/30计数/轮圈，整数换算与固件一致。默认dynamics.py分别积分两轮转速，通过有限纵向接地力耦合底盘；轮速可与底盘速度分离，单轮空转不再被理想轮速覆盖。电机增益1.25、死区15、轮惯性比0.04、接地刚度60/s和附着0.9均为条件模型参数，未实测；横向仍为无侧滑自行车运动学，不能证明高速抓地极限。legacy保留旧平均PWM模型，仅用于显式对照。'+s[b:];s=s.replace('加autonomous_config、vision_config','加autonomous_config、vision_config、encoder_config、vehicle_geometry、servo_config五个配置头');p.write_text(s,encoding='utf-8')
# Report is independent of temporary paths; evidence paths are relative paths inside the ZIP.
rows=[]
for name,label in [('low-unified-topology','300/250/220/220'),('speed800-unified-topology','800/800/800/800'),('speed1000-staged','1000/900/800/800'),('speed1200-staged','1200/900/800/800')]:
 for d in ['AB','BA']:
  a=json.loads((t/name/d/'result.json').read_text(encoding='utf-8'));stats=a['stability_10ms'];data=list(csv.DictReader((t/name/d/'telemetry.csv').open(encoding='utf-8-sig')))
  vmax=max(float(q['speed_mm_s']) for q in data)
  rows.append(f"| {label} | {d} | {a['time_s']:.2f} | {stats['min_speed_mm_s']:.1f}–{vmax:.1f} | {stats['min_path_margin']} | {a['min_tire_corner_margin_mm']:.1f} | 通过 |")
fw=json.loads((t/'firmware.json').read_text(encoding='utf-8'))
report=f'''# 运动稳定性修复与分档验收 — 2026-10-14

{summary}

## 已完成与根因

1. 原来毫米目标和像素PID切换能产生大幅转向跳变；现正常道路/十字统一毫米目标，备用像素Kp按实测端点由36换算为29，所有控制模式共用二阶转向轨迹。环岛阶段禁止通用像素目标覆盖拓扑选支，仍由环岛轮廓路径判据负责。
2. 原来整车目标加速度不能约束差速后的单轮目标；现两轮各自上升≤200、下降≤800mm/s²，并避免两侧不同升降斜率制造无故减速。每轮最终PWM上升≤3、下降≤12‰/10ms。限的是目标与输出，不能宣称物理轮加速度绝不超限。
3. 速度前馈由0.8改0.5，执行量跟踪增益10/s，使PID积分响应实际输出限制；不回算PWM整数尾数，避免稳态偏低。单轮硬超速2500mm/s仍立即停车。
4. 首坏帧撤动力但保持最后执行转向，避免滑行时突回中；连续坏帧仍停车。trace补充原始左右计数、原始轮速、舵机脉宽/服务时刻及控制执行前状态，PID复位后诊断镜像同步清零。
5. 暂定远场十字在近场未确认、600mm内可由连续3帧完整环岛证据纠正，解决弱拓宽过早锁死CROSS。已确认近场十字不能被重判；没有放宽黑路、轮迹或路径品质拒绝条件。
6. 仿真默认分别积分双轮状态与有限接地力；编码器不再从理想底盘转弯几何重建。保留legacy作明确对照。验收增加指定路线距离/里程检查，起步期也统计失路和品质裕量。

## 参数事实与选择

- 用户确认：舵机中位1480µs、1330–1630µs；前轮左右端点基本一致，atan(21.5/31)=34.7431801583°。端点内脉宽—角度线性关系、机械80ms响应仍为假设。
- 编码器保持1024×68/30=2321.0667计数/轮圈、STEP上升沿×1；不再使用4352。64mm是名义轮径，滚动周长仍待实测。
- 相机高297mm、后轴前80mm、赛道内宽500mm沿用实测；俯角31.46896°/有效水平视场89.66951°为条件拟合。
- 主工程与仿真默认：300/250/220/220mm/s，PWM400‰，横向加速度限制2000mm/s²。
- 高档：800/800/800/800、1000/900/800/800、1200/900/800/800；均PWM1000‰、横向加速度限制2400mm/s²。横向限制根据请求与执行曲率中较大者限速，不保证整圈保持设定最高速度。
- 共同转向速度5000‰/s、加速度50000‰/s²；软件脉宽步进20µs/20ms。

## 完整路线结果

速度次序为直道/弯道/可靠外侧/元素（含低Q），单位mm/s。两方向均无故障、无轮胎出界、正常行驶零撤PWM，实际行程约29.8–30.15m、指定路线约30.021m。最低速度只排除有依据的起步加速段；Q裕量和撤PWM检查覆盖全部RUNNING阶段。验收允许2%速度闭环误差，表中保留实测模型值，不将789写成800。

| 四档设定 | 方向 | 时间s | 正常最低–全程最高mm/s | 最小Q裕量 | 最小轮胎角点余量mm | 结果 |
|---|---|---:|---:|---:|---:|---|
{chr(10).join(rows)}

1200直道档实际最高1047–1146mm/s，受路线与加速约束；单独固定直道闭环回归达到1180mm/s以上。各完整路线转向命令每10ms变化≤50‰、单轮目标上升≤2.001mm/s、PWM上升≤3‰。最高单轮速度约1151mm/s，未触发2500保护。品质裕量是本模型路径Q减实际门限，不等于实车环境鲁棒性概率。

## 明确不采用的结果

- 四档全1000：AB环岛出口一帧失路导致2个10ms周期撤PWM，最低速度降至176mm/s；虽最后完赛，验收失败。BA通过不能掩盖该方向失败。四档全1200未继续盲试，采用已通过的800元素速度与900弯道速度。
- low-metric-control：曾因通用毫米目标覆盖环岛分支而绕错路，行程53m、路线误差5.7m。旧pass_run错误已标无效，绝不计入通过；新增选支负例和完整路线验收。
- 单纯把十字宽行阈值6提高到20：一方向改善、另一方向破坏真实十字，隔离试验后放弃。

## 验证、评审与避免重复

- 本轮恢复先核对最后完成的low-unified-topology双向结果与11份源码快照，完全一致，未重跑该低速整圈。
- 工程完整回归145/145通过；评审后仅修复诊断镜像，不改控制输出，再跑10项运动（含1项新回归）与2项集成通过，共146项不同工程测试得到覆盖。仿真完整55/55通过。
- 独立评审指出起步段统计遗漏、PID诊断镜像陈旧，均用先失败后通过回归关闭。起步统计修正后只补查低速/800/1000两方向前2.92/6.12/7.40秒，每10ms检查，旧50ms控制与姿态记录逐点一致。六组均零撤PWM、品质裕量≥55；不重复整圈。1200整圈直接使用新统计。
- GUI：11份活动预设、参数往返、固定高度拟合、1100×720和1480×930、2D/3D/摄像头渲染及运行检查通过；新增运动/动力页显示正常。
- Keil ARM Compiler6.21全量0错误0警告；Code138936、RO13296、RW300、ZI110260字节。调用图最大可计算栈2492字节，另有工具标注Unknown，不能当成板上最坏栈/实时性保证。
- 本轮不再增加未标定的附着/角度/噪声大矩阵，不重复已合格整圈；保留直接复现已发现缺陷、独立轮速/卸载行为、完整路线、回归和构建检查。
- 冻结main/isr/camera_debug/camera_display、库与MDK、历史JSON和原始测量文件按基线SHA-256核对；不修改来源目录和原视频。10份非历史活动预设同步实测端点及新运动控制；“实测基线”和archive JSON保持原字节。用户其他速度、相机数据保留。

## 交付与复现

- 当前固件：[autocar.hex](../firmware/autocar.hex)、AXF/BIN同目录，采用上述中低速默认，未烧录/通电/操作车辆。Keil实际下载目录tmp/build-autocar/objects内三份文件与发布同哈希。
- HEX SHA-256：`{fw['autocar.hex']['sha256']}`。
- AXF SHA-256：`{fw['autocar.axf']['sha256']}`。
- BIN SHA-256：`{fw['autocar.bin']['sha256']}`。
- 源码/测试/必要试验及评审证据：[motion-stability-evidence-20261014.zip](motion-stability-evidence-20261014.zip)。ZIP内final-source为交付源码，experiments为原始试验快照与结果，startup-audit.json补足早期统计；source/trace诊断后修正不改变运动行为，旧结果与最终源码身份分别保留。
- 改前源码备份：[autocar_before-motion-stability_20261014_154539.zip](../backups/autocar_before-motion-stability_20261014_154539.zip)；改前发布/下载固件：[autocar_firmware_before-motion-stability_20261014.zip](../backups/autocar_firmware_before-motion-stability_20261014.zip)。
- 日志：[Keil](../../logs/motion-stability-build.log)、[工程](../../logs/motion-stability-car-tests.log)、[运动补充](../../logs/motion-stability-motion-tests.log)、[仿真](../../logs/motion-stability-simulation-tests.log)。

从Autodrive根目录运行（将python替换为本机解释器）：

```powershell
python -B simulation/tools/validate_control.py --config simulation/configs/完整验证_1200.json --output tmp/本次复现/1200 --directions AB BA
python -B -m unittest discover -s simulation/tests -p 'test_*.py' -v
```

仿真参数不会回写car；要形成高档固件，必须同步四个速度宏、PWM1000和横向加速度2400后重新构建，不能只把四档都设1200。当前先交付中低速固件符合已批准的“先中低速稳定，再逐步提速”。

## 剩余实测事项

本轮软件实现、针对性验证和构建已完成。实车修复效果仍需新场测：没有本次OVERSPEED瞬时左右轮速/原始计数，不能判定真实空转或计数毛刺；新增trace用于下次留下证据。PWM—轮速、舵机中间段/机械响应、滚动周长、相机俯角和有效视场未完整标定；独立纵向模型仍不模拟真实横向侧滑，800–1200不是实车完赛保证。中央270°道路仍可能以CURVE通过，360°环岛进出有对应状态链；3.6m/s未验证。冻结Wi-Fi同步阻塞边界未改。
'''
(r/'outputs/reports'/report_name).write_text(report,encoding='utf-8')
insert_after_title('docs/environment-and-build.md',f'## 2026-10-14当前运动稳定性固件\n\n{summary} 本轮隔离全量构建与主工程源文件/配置/库逐字节一致；Keil6.21为0错误0警告。已同步发布与实际下载路径AXF/HEX/BIN，未烧录。原下载/发布文件在outputs/backups内保留，参数、哈希及测试见[报告](../outputs/reports/{report_name})。')
print('Updated documentation and final report.')
