from pathlib import Path
import json,sys,os,math,csv,hashlib
r=Path.cwd();task=r/'tmp/motion-stability-20261014';sys.path.insert(0,str(r/'simulation'))
import parameters
parameters.ROOT=task/'startup-audit-workspace'
from engine import Simulation
from tools.validate_control import run_is_acceptable
reports=[]
for name in ['low-unified-topology','speed800-unified-topology','speed1000-staged']:
 for direction in ['AB','BA']:
  folder=task/name/direction;p=json.loads((folder/'parameters.json').read_text(encoding='utf-8'));s=Simulation(p);s.started=True
  until=1000+max(p[k] for k in ('cruise','curve_speed','outer_speed','element_speed'))*(1+s.native.motion['maximum_turn_ratio'])/p['accel']*1000
  while s.now<until:s.tick()
  old=list(csv.DictReader((folder/'telemetry.csv').open(encoding='utf-8-sig')));prefix={float(a['time_s']):a for a in old}
  for row in s.history:
   ref=prefix[row['time_s']]
   for key in ['speed_mm_s','x_m','y_m','command','left_pwm','right_pwm','Q','valid','element']:
    assert abs(float(row[key])-float(ref[key]))<1e-7,(name,direction,key,row['time_s'])
  result=json.loads((folder/'result.json').read_text(encoding='utf-8'));stats=result['stability_10ms']
  # last tick may overlap previous post-ramp statistics; pass/fail uses zero and minimum, not a tick sum.
  stats['zero_pwm_ticks']=max(stats['zero_pwm_ticks'],s.zero_pwm_ticks)
  stats['min_path_margin']=min(stats['min_path_margin'],s.min_path_margin)
  audit={'name':name,'direction':direction,'end_ms':s.now,'prefix_matches_trajectory_and_control':True,
         'startup_path_ticks':s.path_ticks,'startup_zero_pwm_ticks':s.zero_pwm_ticks,'startup_min_path_margin':s.min_path_margin,
         'combined_pass':run_is_acceptable(result,p),'combined_stability':stats}
  assert audit['combined_pass'],audit
  reports.append(audit);print(json.dumps(audit,ensure_ascii=True),flush=True)
(task/'startup-audit.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf-8')
