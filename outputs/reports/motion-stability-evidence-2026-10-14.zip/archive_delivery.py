from pathlib import Path
import hashlib,json,zipfile,re,datetime,shutil
r=Path.cwd();t=r/'tmp/motion-stability-20261014';base=json.loads((t/'baseline-sha256.json').read_text(encoding='utf-8'))['files']
protected=[]
for name,digest in base.items():
 if name.startswith(('car/library/','car/mdk/','simulation/assets/','simulation/configs/archive/')) or name in ['car/src/main.c','car/src/isr.c','car/src/camera_debug.c','car/src/camera_display.c','simulation/configs/实测基线_350_350_350_250.json']:
  p=r/name;assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==digest,name;protected.append(name)
# Previous qualified source snapshots differ only by post-review diagnostic reset assignments.
added=['    d->status.left_integral=d->status.right_integral=0;','    d->status.left_pid_request=d->status.right_pid_request=0;d->status.speed_limit_mm_s=0;','        d->status.left_integral=d->status.right_integral=0;','        d->status.left_pid_request=d->status.right_pid_request=0;']
for name in ['low-unified-topology','speed800-unified-topology','speed1000-staged']:
 for old in (t/name/'workspace/source').rglob('*'):
  if not old.is_file():continue
  p=r/'car'/old.relative_to(t/name/'workspace/source')
  a=p.read_text(encoding='utf-8');b=old.read_text(encoding='utf-8')
  if p.name=='autonomous_drive.c':
   a='\n'.join(line for line in a.split('\n') if line not in added)
  assert a==b,(name,p)
# Capture exact final source and all essential evidence; no private Wi-Fi header or build credentials.
archive=r/'outputs/reports/motion-stability-evidence-20261014.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 manifest={}
 def add(p,name):
  z.write(p,name);manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest()
 for folder in ['car/src','car/include','car/config','car/tests','car/scripts','simulation/tests','simulation/configs','simulation/docs']:
  for p in (r/folder).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.exe','.dll']:
    add(p,'final-source/'+p.relative_to(r).as_posix())
 for p in (r/'simulation').glob('*.py'):add(p,'final-source/'+p.relative_to(r).as_posix())
 for p in (r/'simulation/tools').glob('*.py'):add(p,'final-source/'+p.relative_to(r).as_posix())
 for name in ['car/autocar.uvprojx','car/autocar.uvoptx','simulation/native_bridge.c','simulation/README.md','simulation/toolchain/deployment.json']:
  p=r/name
  if p.is_file():add(p,'final-source/'+name)
 for experiment in ['low-unified-topology','speed800-unified-topology','speed1000-staged','speed1200-staged','speed1000-unified-topology']:
  for p in (t/experiment).rglob('*'):
   if p.is_file() and 'build' not in p.relative_to(t/experiment).parts:
    add(p,'experiments/'+p.relative_to(t).as_posix())
 # Preserve failed-route diagnosis without unnecessary massive full frame capture.
 for experiment in ['low-metric-control','ring-candidate-study']:
  for p in (t/experiment).rglob('*.json'):
   if 'workspace' not in p.parts:add(p,'rejected/'+p.relative_to(t).as_posix())
 for p in t.glob('*'):
  if p.is_file() and p.suffix in ['.log','.json','.md','.py']:add(p,p.name)
 for p in (t/'ui').glob('*'):
  if p.is_file():add(p,'ui/'+p.name)
 add(t/'keil/logs/keil-build.log','keil-build.log')
 # Application source hashes prove SDK unchanged without distributing tool outputs or local secrets.
 z.writestr('manifest-sha256.json',json.dumps(manifest,ensure_ascii=False,indent=2))
 z.writestr('protection-summary.json',json.dumps({'protected_files_verified':len(protected),'source_differences_for_reused_laps':'diagnostic reset assignments only; startup-statistics correction verified separately'},ensure_ascii=False,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 forbidden=[n for n in z.namelist() if 'camera_debug_local' in n or 'parameter_locations.local' in n]
 assert not forbidden,forbidden
 contents=json.loads(z.read('manifest-sha256.json'))
 for name,digest in contents.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
print('Protected files:',len(protected),'Archive entries:',len(contents),'Archive bytes:',archive.stat().st_size,'SHA256:',hashlib.sha256(archive.read_bytes()).hexdigest())
# Only local links added/used by current report are validated; old historical missing links are unrelated.
report=r/'outputs/reports/motion-stability-2026-10-14.md'
for link in re.findall(r'\]\(([^)]+)\)',report.read_text(encoding='utf-8')):
 if not re.match(r'https?://',link):assert (report.parent/link).is_file(),link
now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds')
entry=f'''\n[{now}] 任务：运动稳定性修复与分路段提速验收\n范围：car控制/视觉/trace/config与对应测试，simulation模型/统计/预设/界面，长期文档。\n变更：统一转向轨迹和普通/十字毫米目标；单轮目标200/800mm/s²及PWM3/12每10ms；PID执行跟踪与量化修正；暂定CROSS可由完整环证据纠正；独立轮动力学及路线/起步验收。舵机实测1330–1630us，中位1480，左右34.74318度。\n验证：145项工程全量通过，后续10项运动含新诊断回归、2项集成通过，共146项不同工程用例覆盖；55项仿真完整通过；GUI通过；Keil6.21全量0错0警告，Code138936/RO13296/RW300/ZI110260。中低速、800、1000/900/800/800及1200/900/800/800双向通过；复用低速整圈证据并补10ms起步检查，无无效重复。独立评审两项均关闭。\n产物：outputs/reports/motion-stability-2026-10-14.md及证据ZIP；outputs/firmware与tmp/build-autocar/objects三份固件同哈希；源码与原固件备份保留。当前发布300/250/220/220、PWM400。\n边界：全1000的AB出口短失路，未采用；旧错误路线结果明确作废。冻屏/Wi-Fi、SDK/MDK和原始测量/历史JSON的{len(protected)}份受保护文件哈希一致。未烧录、通电或操作车辆；实车PWM/轮速/镜头/响应仍待验证，3.6m/s未验证。\n收尾：证据ZIP逐项SHA-256/CRC通过、报告链接可达；仅清理本任务临时目录，保留原视频和其他任务。\n'''
with (r/'logs/2026-10-14.log').open('a',encoding='utf-8') as f:f.write(entry)
shutil.copy2(t/'trace-final.log',r/'logs/motion-stability-integration-tests.log')
