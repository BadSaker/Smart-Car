from pathlib import Path
import json, math
ROOT=Path(__file__).resolve().parent
DEFAULTS={
 'scenario':'full','direction':'A→B','controller':'native','show_ab':True,
 'length':0.27,'wheelbase':0.20,'track':0.16,'body_width':0.14,'tire_width':0.025,
 'wheel_diameter':0.064,'camera_offset':0.14,'height':0.27,'pitch':20.0,
 'hfov':130.0,'fy_ratio':1.0,'cx':93.0,'cy':59.5,'k1':0.0,'fps':50.0,'road_width':0.5,'edge_width':0.025,
 'radius':0.5,'steer_max_deg':28.0,'servo_center':1480.0,'servo_range':130.0,
 'servo_step':6.0,'servo_interval':0.02,'servo_tau':0.08,
 'motor_gain':1.25,'motor_deadzone':15.0,'motor_tau':0.18,'coast_tau':0.25,
 'cruise':180.0,'curve_speed':120.0,'outer_speed':80.0,'kp':28.0,'ki':0.0,'kd':0.5,
 'speed_kp':0.5,'speed_ki':0.15,'min_q':45,'outer_q':40,'outer_enabled':1,
 'width_top':44,'width_bottom':167,'offset':0.0,'heading_error':0.0,
 'gray_road':220,'gray_edge':20,'gray_background':45,'noise':0.0,'seed':42,
 'drop_camera':False,'drop_feedback':False,'blackout':False,
 'camera_mode':'two_point_fit','fitted_pitch':0.0,'fitted_hfov':0.0
}
def fit_camera(height=0.27,width=0.5,cy=59.5,top=44,bottom=167,fy_ratio=1.0):
    slope=(bottom-top)/86.0
    cosine=slope*height/width*fy_ratio
    if not 0<cosine<1: raise ValueError('两点宽度与高度/道路宽度不相容，无法按当前透视假设拟合。')
    pitch=math.acos(cosine)
    focal=(top*height/width-(30-cy)/fy_ratio*cosine)/math.sin(pitch)
    if focal<=0: raise ValueError('拟合焦距非正，请检查尺寸和主点。')
    return {'pitch':math.degrees(pitch),'hfov':math.degrees(2*math.atan(94/focal)),
            'focal':focal,'slope':slope,'assumptions':'平地、内沿宽度、fy/fx已知、cy已知、无畸变；条件拟合，非实测'}
def defaults():
    p=DEFAULTS.copy();fit=fit_camera()
    p['pitch']=fit['pitch'];p['hfov']=fit['hfov']
    p['fitted_pitch']=fit['pitch'];p['fitted_hfov']=fit['hfov']
    return p
def validate(p):
    ranges={'length':(.05,1),'wheelbase':(.05,.8),'track':(.05,.5),'body_width':(.05,.5),
      'tire_width':(.005,.1),'wheel_diameter':(.02,.2),'camera_offset':(-.3,1),
      'height':(.03,1),'pitch':(1,85),'hfov':(20,165),'fy_ratio':(.5,2),'cx':(60,125),'cy':(20,100),'k1':(-.01,.01),
      'fps':(1,100),'road_width':(.2,1),'edge_width':(.005,.08),'radius':(.3,2),
      'steer_max_deg':(2,60),'servo_center':(1000,2000),'servo_range':(10,300),'servo_step':(1,40),
      'servo_interval':(.01,.1),'servo_tau':(.01,1),'motor_gain':(.1,5),'motor_deadzone':(0,100),
      'motor_tau':(.02,2),'coast_tau':(.02,3),'cruise':(10,500),'curve_speed':(10,500),
      'outer_speed':(10,500),'kp':(0,100),'ki':(0,20),'kd':(0,10),'speed_kp':(0,5),'speed_ki':(0,5),
      'min_q':(1,100),'outer_q':(1,100),'width_top':(8,150),'width_bottom':(8,185),
      'offset':(-.5,.5),'heading_error':(-90,90),'noise':(0,50),'seed':(0,2147483647),
      'gray_road':(0,255),'gray_edge':(0,255),'gray_background':(0,255)}
    for key,(lo,hi) in ranges.items():
        if key not in p or not isinstance(p[key],(int,float)) or not math.isfinite(p[key]) or not lo<=p[key]<=hi:
            raise ValueError(f'{key} 必须在 {lo}～{hi} 之间')
    for key in ('seed','min_q','outer_q','width_top','width_bottom','outer_enabled'):
        if int(p[key])!=p[key]: raise ValueError(f'{key} 必须为整数')
    if p['width_top']>p['width_bottom']: raise ValueError('远端宽度不能大于近端宽度')
    if p['outer_q']>p['min_q']: raise ValueError('外侧Q门限不得高于普通Q门限')
    if p['outer_speed']>p['curve_speed']: raise ValueError('外侧速度不得高于弯道速度')
    if p['outer_enabled'] not in (0,1):raise ValueError('外侧补线开关必须为0或1')
    if p['body_width']>p['track']+p['tire_width']:raise ValueError('车身宽度不能超过当前轮胎外沿宽度')
    if p['scenario'] not in ('full','midterm','straight','circle'):raise ValueError('未知场景')
    if p['controller'] not in ('native','reference'):raise ValueError('未知控制模式')
    if p['direction'] not in ('A→B','B→A'):raise ValueError('未知方向')
    return p
def save(path,p):
    Path(path).write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
def load(path):
    p=defaults();p.update(json.loads(Path(path).read_text(encoding='utf-8')));return validate(p)
